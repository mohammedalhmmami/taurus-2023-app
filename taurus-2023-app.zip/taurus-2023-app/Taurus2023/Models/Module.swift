import Foundation

// MARK: - Module
/// وحدات السيارة كما تظهر في FORScan.
/// كل وحدة لها معرّف CAN (مثل APIM = 7D0) واسم عربي وأيقونة في الشريط الجانبي.
///
/// تحذير: عناوين BdyCM و IPC تختلف بين منصات فورد.
/// عنوان مؤكد لـ F-150 لا يعني أنه نفسه لتورس 2023 Mondeo — انظر FEATURES.md.
enum Module: String, CaseIterable, Identifiable {
    case pcm = "PCM"      // كمبيوتر المحرك — محظور من الكتابة نهائياً
    case tcm = "TCM"      // كمبيوتر القير — محظور من الكتابة نهائياً
    case apim = "APIM"    // الشاشة SYNC
    case ipc = "IPC"      // العدادات
    case bdyCM = "BdyCM"  // الجسم (الأنوار، النوافذ، القفل)
    case acm = "ACM"      // الصوت
    case abs = "ABS"      // الفرامل
    case rcm = "RCM"      // الإيرباق
    case pscm = "PSCM"    // الدركسون الكهربائي
    case sccm = "SCCM"    // عمود الدركسون
    case fcim = "FCIM"    // أزرار الواجهة الأمامية
    case fcdim = "FCDIM"  // شاشة الواجهة الأمامية
    case ocs = "OCS"      // حساس الراكب

    var id: String { rawValue }

    /// الاسم العربي للوحدة.
    var arabicName: String {
        switch self {
        case .pcm: return "كمبيوتر المحرك"
        case .tcm: return "كمبيوتر القير"
        case .apim: return "الشاشة"
        case .ipc: return "العدادات"
        case .bdyCM: return "الجسم"
        case .acm: return "الصوت"
        case .abs: return "الفرامل"
        case .rcm: return "الإيرباق"
        case .pscm: return "الدركسون"
        case .sccm: return "عمود الدركسون"
        case .fcim: return "أزرار الواجهة"
        case .fcdim: return "شاشة الواجهة"
        case .ocs: return "حساس الراكب"
        }
    }

    /// اسم أيقونة SF Symbol للشريط الجانبي.
    var iconName: String {
        switch self {
        case .pcm: return "engine.combustion"
        case .tcm: return "gearshape"
        case .apim: return "display"
        case .ipc: return "gauge.with.dots.needle.33percent"
        case .bdyCM: return "car.side"
        case .acm: return "speaker.wave.3"
        case .abs: return "circle.dashed"
        case .rcm: return "shield"
        case .pscm: return "steeringwheel"
        case .sccm: return "steeringwheel"
        case .fcim: return "button.horizontal.top.press"
        case .fcdim: return "display.2"
        case .ocs: return "person"
        }
    }

    /// معرّف CAN للوحدة (يُستخدم في أوامر ELM327).
    var canID: String {
        switch self {
        case .pcm: return "7E0"
        case .tcm: return "7E1"
        case .apim: return "7D0"
        case .ipc: return "720"
        case .bdyCM: return "726"
        case .acm: return "727"
        case .abs: return "760"
        case .rcm: return "737"
        case .pscm: return "730"
        case .sccm: return "724"
        case .fcim: return "7A7"
        case .fcdim: return "7A5"
        case .ocs: return "7C4"
        }
    }

    // MARK: - Write ban — أهم قاعدة أمان في التطبيق
    /// هل يُسمح بالكتابة في هذه الوحدة؟
    /// PCM و TCM: لا أبداً، ولا تظهرا في قائمة المزايا القابلة للكتابة.
    /// RCM (إيرباق) و ABS (فرامل): القراءة فقط في هذا الإصدار — لا كتابة.
    /// باقي الوحدات: الكتابة مشروطة بفحص التوافق والنسخة الاحتياطية.
    var isWritable: Bool {
        switch self {
        case .pcm, .tcm, .rcm, .abs:
            return false
        default:
            return true
        }
    }

    /// سبب الحظر (يُعرض في الواجهة إن حاول أحد الكتابة).
    var writeBanReason: String? {
        switch self {
        case .pcm: return "كمبيوتر المحرك محظور من الكتابة نهائياً"
        case .tcm: return "كمبيوتر القير محظور من الكتابة نهائياً"
        case .rcm: return "وحدة الإيرباق — قراءة فقط في هذا الإصدار"
        case .abs: return "وحدة الفرامل — قراءة فقط في هذا الإصدار"
        default: return nil
        }
    }
}

// MARK: - ModuleStatus
/// حالة وحدة بعد الفحص.
struct ModuleStatus: Identifiable {
    let id = UUID()
    let module: Module
    var found: Bool          // هل ظهرت الوحدة في الفحص؟
    var dtcCount: Int        // عدد الأعطال فيها
    var asBuiltLines: [AsBuiltLine] = []
}
