import Foundation

// MARK: - VerificationStatus
/// حالة التحقق من الكود — انظر FEATURES.md للتفصيل والمصادر.
/// لا يوجد كود في التطبيق إلا بهذه الحالة، ولا قيمة تخمينية أبداً.
enum VerificationStatus: Equatable {
    /// ✅ مؤكد في أكثر من مصدر موثوق لـ SYNC 4.
    case verified
    /// ⚠️ مؤكد لموديل فورد آخر أو متعارض بين المصادر — كتابة مشروطة بتحقق إضافي.
    case partiallyVerified(conflict: String)
    /// ❌ لم يوجد مصدر موثوق لتورس 2023 — قراءة وعرض فقط، لا كتابة.
    case unverified(reason: String)
}

// MARK: - FeatureChange
/// كيف يُنفَّذ التغيير. القاعدة: اقرأ القيمة الحالية أولاً، ثم عدّل بتاً واحداً فقط.
/// لا يوجد في التطبيق أي "اكتب هذا السطر الكامل من عندك".
enum FeatureChange: Equatable {
    /// تعديل نبل واحد في سطر As-Built موجود.
    /// - blockIndex / nibbleIndex: موضع النبل في السطر الحالي.
    /// - onNibble: قيمة النبل عند التفعيل (تُدمج مع البتات الحالية بـ OR، لا تستبدلها).
    /// - offNibble: قيمة النبل عند الإيقاف (تُمسح البتات المطلوبة فقط).
    case nibbleChange(address: String, blockIndex: Int, nibbleIndex: Int, onNibble: Character, offNibble: Character)
    /// تعديل بت واحد داخل نبل (الأدق).
    case bitChange(address: String, blockIndex: Int, nibbleIndex: Int, bit: Int)
    /// إعداد نصي في FORScan Configuration (وليس As-Built مباشرة).
    /// مثال: Bambi Mode — "Use front fog lights with high beam" Inhibited → Allowed.
    case plainEnglishSetting(module: Module, settingName: String, onValue: String, offValue: String)
    /// لا يوجد تغيير برمجي موثوق — قراءة وعرض فقط.
    case noneUnverified
}

// MARK: - Feature
/// ميزة واحدة من الـ18. كل ميزة تحمل مصدرها وحالتها وشرطها.
struct Feature: Identifiable {
    let id: Int                 // 1...18 كما في قائمة المبرمج
    let titleAr: String
    let descriptionAr: String
    let module: Module
    let change: FeatureChange
    let status: VerificationStatus
    let source: String          // المصدر — انظر FEATURES.md
    let conditionAr: String?    // شرط الهاردوير/الفئة، إن وجد
    let warningAr: String?      // تحذير سلامة/قانوني، إن وجد
    var isEnabled: Bool = false // الحالة الحالية في السيارة (تُقرأ منها، لا تُخمن)

    /// وصف المسار البرمجي للعرض — من البيانات الموثقة في FeatureDatabase فقط.
    /// لا يُخترع أي عنوان أو قيمة هنا: غير المؤكد يعرض "لا يوجد مسار موثوق".
    var pathAr: String {
        switch change {
        case .nibbleChange(let address, let blockIndex, let nibbleIndex, let onNibble, let offNibble):
            return "المسار: \(module.rawValue) \(address) — البلوك \(blockIndex + 1)، النبل \(nibbleIndex + 1) — التفعيل: \(onNibble)، الإيقاف: \(offNibble)"
        case .bitChange(let address, let blockIndex, let nibbleIndex, let bit):
            return "المسار: \(module.rawValue) \(address) — البلوك \(blockIndex + 1)، النبل \(nibbleIndex + 1)، البت \(bit) — يُدمج مع البتات الحالية (OR) ولا يستبدل القيمة"
        case .plainEnglishSetting(let mod, let settingName, let onValue, let offValue):
            return "المسار: \(mod.rawValue) Configuration — «\(settingName)» — التفعيل: \(onValue)، الإيقاف: \(offValue)"
        case .noneUnverified:
            return "لا يوجد مسار موثوق — يحتاج قراءة As-Built الفعلي من السيارة"
        }
    }

    /// هل يُسمح بمحاولة الكتابة لهذه الميزة؟
    /// المزايا غير المؤكدة لا تُكتب أبداً — زرها معطّل في الواجهة.
    /// والميزة التي تغييرها noneUnverified لا تُكتب أيضاً حتى لو كانت
    /// حالتها partiallyVerified (مثال: الميزة 7 — إعداد مؤكد الوجود
    /// لكن بلا عنوان As-Built موثوق ولا مسار Configuration موثق).
    var isWritable: Bool {
        if !module.isWritable { return false }
        if case .noneUnverified = change { return false }
        switch status {
        case .verified: return true
        case .partiallyVerified: return true // مع تأكيد إضافي يعرض التعارض
        case .unverified: return false
        }
    }
}

// MARK: - Feature list (titles only — التفاصيل الكاملة في FeatureDatabase)
/// عناوين المزايا الـ18 كما أرسلها المبرمج في الصورة.
enum FeatureTitles {
    static let all: [(Int, String)] = [
        (1, "تقوية سماعات التورس"),
        (2, "النمط الصامت"),
        (3, "إضافة عمر الزيت بالشاشة + إلغاء تنبيه الزيت"),
        (4, "إلغاء صوت البوري عند النزول"),
        (5, "تفعيل إعدادات التشغيل عن بعد في الشاشة"),
        (6, "إعدادات مفتاح التشغيل عن بعد"),
        (7, "قفل تلقائي عند النزول والابتعاد"),
        (8, "تغيير لون الإشارة الخلفية من برتقالي إلى أحمر"),
        (9, "السكن البرتقالي"),
        (10, "تقوية النور العالي"),
        (11, "تضعيف السكن / النعاس + إطفاء النور كاملاً"),
        (12, "تغيير وضع الشاشة إلى النهاري مع التحكم بين الأنماط"),
        (13, "إلغاء الأوتو ستارت ستوب"),
        (14, "قراءة عداد الطبلون لسرعة الشارع"),
        (15, "تغيير علامة الجنط إلى كلمة brake"),
        (16, "اللبد الداخلي أوف وايت + ألوان إضافية"),
        (17, "إلغاء صوت الحزام"),
        (18, "تكبيس العالي والواطي وأنت مسكن"),
    ]
}
