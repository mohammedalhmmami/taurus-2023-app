import Foundation

// MARK: - DTC
/// كود عطل تشخيصي (Diagnostic Trouble Code).
/// مثال من صور المبرمج (تورس 2015 — للتوضيح فقط، وليست أكواد 2023):
/// U3000:04-28 في APIM، و P1346:13-8A و U0159:00-0A في IPC.
/// هذه الأكواد في صور 2015 لا تُنسخ إلى 2023 ولا تُستخدم كمرجع لقيم 2023.
struct DTC: Identifiable, Equatable {
    let id = UUID()
    let code: String        // مثل "U3000"
    let status: String      // مثل "04-28"
    let module: Module
    let descriptionAr: String

    var displayString: String { "\(code):\(status)" }

    /// وصف عربي مختصر حسب أول حرف من الكود.
    static func arabicDescription(for code: String) -> String {
        switch code.first {
        case "P": return "عطل في نظام المحرك / القوة"
        case "B": return "عطل في نظام الجسم"
        case "C": return "عطل في نظام الشاصي / الفرامل"
        case "U": return "عطل في شبكة الاتصال بين الوحدات"
        default: return "كود عطل — راجع دليل فورد"
        }
    }
}

// MARK: - LiveData
/// قراءة حية واحدة (PID).
struct LiveDataPoint: Identifiable {
    let id = UUID()
    let nameAr: String
    let value: String
    let unit: String
}

// MARK: - SafetyReport
/// تقرير السلامة قبل الكتابة — كل الحقول يجب أن تكون خضراء.
struct SafetyReport {
    var batteryVoltage: Double = 0      // فولت — يجب أن يكون فوق 12.0
    var speedKmh: Double = 0            // يجب أن تكون 0 — لا كتابة أثناء القيادة
    var isConnected: Bool = false
    var hasBackup: Bool = false
    var vinValidated: Bool = false
    var adapterRecommended: Bool = false

    /// هل الكتابة مسموحة الآن؟ كل الشروط يجب أن تتحقق.
    var canWrite: Bool {
        isConnected && hasBackup && vinValidated && adapterRecommended
            && batteryVoltage >= 12.0 && speedKmh == 0
    }

    /// قائمة الفحوصات مع حالتها — تُعرض في SafetyReportView.
    var checks: [(String, Bool)] {
        [
            ("متصل بالقطعة", isConnected),
            ("رقم الشاصي تورس 2023", vinValidated),
            ("البطارية فوق 12.0V (\(String(format: "%.1f", batteryVoltage))V)", batteryVoltage >= 12.0),
            ("السيارة متوقفة (السرعة 0)", speedKmh == 0),
            ("نسخة احتياطية محفوظة", hasBackup),
            ("القطعة موصى بها (ليست ELM327 v1.5 رخيصة)", adapterRecommended),
        ]
    }
}
