import Foundation

// MARK: - AsBuiltLine
/// سطر As-Built واحد، كما يظهر في FORScan.
/// مثال: `7D0-10-01 0000 0000 00E8` — العنوان + 3 بلوكات + Checksum.
/// كل حرف Hex هو 4 بتات. حرف `x` في الجداول يعني "لا تغيّر هذا الموضع".
struct AsBuiltLine: Equatable, Identifiable {
    let id = UUID()
    let moduleID: String   // مثل "7D0"
    let address: String    // مثل "7D0-10-01"
    var blocks: [String]   // 3 بلوكات، كل بلوك 4 أحرف Hex، مثل ["0000", "0000", "00E8"]

    /// السطر الكامل للعرض.
    var displayString: String {
        "\(address) \(blocks.joined(separator: " "))"
    }

    /// إعادة حساب Checksum للسطر — خاص بـ APIM (7D0) فقط.
    /// القاعدة الموثقة لـ APIM في جداول FORScan: الـ Checksum (آخر بايت) هو مجموع
    /// بقية بايتات السطر. مصدر القاعدة: XDA / FORScan APIM programming —
    /// "The checksum (last byte), is the sum of all other bytes on that line".
    /// مثال: 7D0-01-02 0009 0604 806D → 6D + 04 = 71 عند تغيير البايت الأول.
    /// تحذير: هذه القاعدة لا تنطبق على كل الوحدات. مثال IPC 720-01-01
    /// 2A0A 14A3 091D (تورس 2015، للتوضيح فقط): مجموع البايتات لا يساوي 1D،
    /// أي أن IPC يستخدم حساباً مختلفاً. لذلك لا تُحسب Checksum لوحدة غير APIM
    /// بهذه الدالة — انظر withNibbleChanged أدناه.
    static func checksum(for blocks: [String]) -> UInt8 {
        // اجمع كل البايتات ما عدا آخر بايت (الـ Checksum نفسه).
        var bytes: [UInt8] = []
        for block in blocks {
            var hex = block
            // تجاهل البايت الأخير في البلوك الأخير (موضع الـ Checksum).
            if block == blocks.last {
                hex = String(block.prefix(2))
            }
            var index = hex.startIndex
            while index < hex.endIndex {
                let next = hex.index(index, offsetBy: 2, limitedBy: hex.endIndex) ?? hex.endIndex
                let byteString = String(hex[index..<next])
                if let byte = UInt8(byteString, radix: 16) { bytes.append(byte) }
                index = next
            }
        }
        let sum = bytes.reduce(0) { $0 + Int($1) }
        return UInt8(sum & 0xFF)
    }

    /// تطبيق تغيير نبل واحد على السطر الحالي — لا استبدال كامل.
    /// - Parameters:
    ///   - blockIndex: رقم البلوك (0...2)
    ///   - nibbleIndex: رقم النبل داخل البلوك (0...3)
    ///   - newNibble: القيمة الجديدة (حرف Hex واحد)
    /// - Returns: سطر جديد بالقيمة المعدلة و Checksum معاد حسابه.
    func withNibbleChanged(blockIndex: Int, nibbleIndex: Int, newNibble: Character) -> AsBuiltLine {
        var newBlocks = blocks
        guard blockIndex < newBlocks.count else { return self }
        var block = Array(newBlocks[blockIndex])
        guard nibbleIndex < block.count else { return self }
        block[nibbleIndex] = newNibble
        newBlocks[blockIndex] = String(block)
        // أعد حساب الـ Checksum بعد التغيير — لـ APIM فقط (قاعدة المجموع موثقة له).
        // للوحدات الأخرى (IPC / BdyCM / غيرها) لا تُخترع Checksum هنا:
        // تُترك القيمة الأصلية ويجب حسابها بطريقة الوحدة الصحيحة قبل الكتابة،
        // ويتحقق SafetyService من الـ Checksum بإعادة القراءة بعد الكتابة.
        if moduleID == "7D0" {
            let newChecksum = Self.checksum(for: newBlocks)
            var lastBlock = Array(newBlocks[newBlocks.count - 1])
            let hex = String(format: "%02X", newChecksum)
            lastBlock[lastBlock.count - 2] = hex[hex.startIndex]
            lastBlock[lastBlock.count - 1] = hex[hex.index(after: hex.startIndex)]
            newBlocks[newBlocks.count - 1] = String(lastBlock)
        }
        return AsBuiltLine(moduleID: moduleID, address: address, blocks: newBlocks)
    }
}

// MARK: - Bit change helper
/// تغيير بت واحد داخل نبل Hex مع الحفاظ على بقية البتات.
/// مثال: عمر الزيت — النبل `0` يصبح `8` (1000 ثنائي = بت Oil Life فقط).
/// إذا كان النبل الحالي `1` (0001) يصبح `9` (1001) — لا تُمحى البتات الأخرى.
enum NibbleBit {
    static func setBit(_ nibble: Character, bit: Int) -> Character {
        guard let value = Int(String(nibble), radix: 16) else { return nibble }
        let newValue = value | (1 << bit)
        return Character(String(format: "%X", newValue))
    }
    static func clearBit(_ nibble: Character, bit: Int) -> Character {
        guard let value = Int(String(nibble), radix: 16) else { return nibble }
        let newValue = value & ~(1 << bit)
        return Character(String(format: "%X", newValue))
    }
}
