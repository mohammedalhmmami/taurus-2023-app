import Foundation

// MARK: - AsBuiltLine
/// سطر As-Built واحد، كما يظهر في FORScan.
/// مثال: `7D0-10-01 0000 0000 00E8` — العنوان + 3 بلوكات + Checksum.
/// كل حرف Hex هو 4 بتات. حرف `x` في الجداول يعني "لا تغيّر هذا الموضع".
struct AsBuiltLine: Equatable, Identifiable {
    let id = UUID()
    let moduleID: String   // مثل "7D0"
    let address: String    // مثل "7D0-10-01"
    var blocks: [String]   // 3 بلوكات، كل بلوك 4 أحرف Hex، مثل ["0000", "0000", "00E8"]

    /// السطر الكامل للعرض.
    var displayString: String {
        "\(address) \(blocks.joined(separator: " "))"
    }

    /// إعادة حساب Checksum للسطر — الصيغة الموثقة من FordScan/FordDiag
    /// (AsBuilt.cs:114–122، مطابقة لصيغة consp/apim-asbuilt-decode):
    /// البايت المنخفض لمجموع: بايتي العنوان (العالي + المنخفض) + رقم البلوك
    /// + رقم السطر + مجموع بايتات البيانات (ما عدا بايت الـ Checksum نفسه).
    /// البلوك والسطر يُقرآن بالنظام الست عشري من العنوان (مثلاً 7D0-10-01:
    /// بلوك 0x10، سطر 0x01) — كما في AsBuiltKey.TryParse في FordScan.
    ///
    /// التحقق (أُجري 2026-11-16): الصيغة تعيد إنتاج Checksum كل أسطر
    /// اختبار FordScan الـ 12 (CodingTests.cs:13–24) — لا 34 كما يدّعي
    /// توثيق المشروع — وتعني أن 34 سطراً المدّعاة غير مثبوتة بالاختبارات.
    /// وتعيد إنتاج 5 من 6 أسطر IPC من صورة تورس 2015 (720-01-01/02،
    /// 720-02-01، 720-03-01/02)؛ السطر السادس (720-01-03 90EB 00FA 9D)
    /// تعطي الصيغة له A0 لا 9D — اختلاف غير محسوم، والمرجح خطأ نسخ من
    /// الصورة. لذلك يبقى التحقق بإعادة القراءة بعد الكتابة هو الحكم النهائي.
    ///
    /// تصحيح لخطأ سابق في هذا الملف: القاعدة القديمة (مجموع كل البايتات
    /// ما عدا الأخير) خاطئة — مثال 7D0-01-02 0009 0604 806D تعطي 93 لا 6D،
    /// بينما صيغة FordScan تعطي 6D الصحيحة. ولأن الصيغة عامة لكل وحدات
    /// فورد (مثبوتة على 720 و724 و7D0)، تُعاد حساب الـ Checksum لكل وحدة
    /// بعد أي تغيير، لا لـ APIM فقط.
    static func checksum(moduleID: String, address: String, blocks: [String]) -> UInt8 {
        // بايتا العنوان: "7D0" ← 0x07 + 0xD0.
        let moduleValue = Int(moduleID, radix: 16) ?? 0
        let moduleHi = (moduleValue >> 8) & 0xFF
        let moduleLo = moduleValue & 0xFF
        // البلوك والسطر من العنوان بالنظام الست عشري: "7D0-10-01" ← بلوك 0x10، سطر 0x01.
        let parts = address.split(separator: "-")
        let block = parts.count > 1 ? (Int(parts[1], radix: 16) ?? 0) : 0
        let line = parts.count > 2 ? (Int(parts[2], radix: 16) ?? 0) : 0
        // بايتات البيانات: كل بايتات السطر ما عدا بايت الـ Checksum نفسه (آخر بايت).
        // (المقارنة بالفهرس لا بالقيمة — بلوكان متطابقان مثل "0000" لا يُقصّان معاً.)
        var bytes: [UInt8] = []
        for (blockIndex, blockText) in blocks.enumerated() {
            var hex = blockText
            if blockIndex == blocks.count - 1 {
                hex = String(blockText.prefix(2))
            }
            var index = hex.startIndex
            while index < hex.endIndex {
                let next = hex.index(index, offsetBy: 2, limitedBy: hex.endIndex) ?? hex.endIndex
                let byteString = String(hex[index..<next])
                if let byte = UInt8(byteString, radix: 16) { bytes.append(byte) }
                index = next
            }
        }
        let sum = moduleHi + moduleLo + block + line + bytes.reduce(0) { $0 + Int($1) }
        return UInt8(sum & 0xFF)
    }

    /// تطبيق تغيير نبل واحد على السطر الحالي — لا استبدال كامل.
    /// - Parameters:
    ///   - blockIndex: رقم البلوك (0...2)
    ///   - nibbleIndex: رقم النبل داخل البلوك (0...3)
    ///   - newNibble: القيمة الجديدة (حرف Hex واحد)
    /// - Returns: سطر جديد بالقيمة المعدلة و Checksum معاد حسابه.
    func withNibbleChanged(blockIndex: Int, nibbleIndex: Int, newNibble: Character) -> AsBuiltLine {
        var newBlocks = blocks
        guard blockIndex < newBlocks.count else { return self }
        var block = Array(newBlocks[blockIndex])
        guard nibbleIndex < block.count else { return self }
        block[nibbleIndex] = newNibble
        newBlocks[blockIndex] = String(block)
        // أعد حساب الـ Checksum بعد التغيير — بصيغة FordScan الموثقة، لكل وحدة
        // (مثبوتة على 720 و724 و7D0؛ انظر checksum أعلاه). لا تُترك القيمة
        // القديمة: أي سطر يُكتب بـ Checksum قديم يرفضه FORScan والوحدة.
        // ويبقى التحقق بإعادة القراءة بعد الكتابة هو الحكم النهائي.
        let newChecksum = Self.checksum(moduleID: moduleID, address: address, blocks: newBlocks)
        var lastBlock = Array(newBlocks[newBlocks.count - 1])
        let hex = String(format: "%02X", newChecksum)
        lastBlock[lastBlock.count - 2] = hex[hex.startIndex]
        lastBlock[lastBlock.count - 1] = hex[hex.index(after: hex.startIndex)]
        newBlocks[newBlocks.count - 1] = String(lastBlock)
        return AsBuiltLine(moduleID: moduleID, address: address, blocks: newBlocks)
    }
}

// MARK: - Bit change helper
/// تغيير بت واحد داخل نبل Hex مع الحفاظ على بقية البتات.
/// مثال: عمر الزيت — النبل `0` يصبح `8` (1000 ثنائي = بت Oil Life فقط).
/// إذا كان النبل الحالي `1` (0001) يصبح `9` (1001) — لا تُمحى البتات الأخرى.
enum NibbleBit {
    static func setBit(_ nibble: Character, bit: Int) -> Character {
        guard let value = Int(String(nibble), radix: 16) else { return nibble }
        let newValue = value | (1 << bit)
        return Character(String(format: "%X", newValue))
    }
    static func clearBit(_ nibble: Character, bit: Int) -> Character {
        guard let value = Int(String(nibble), radix: 16) else { return nibble }
        let newValue = value & ~(1 << bit)
        return Character(String(format: "%X", newValue))
    }
}
