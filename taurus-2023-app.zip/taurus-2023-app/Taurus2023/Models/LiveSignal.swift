import Foundation
import SwiftUI // badgeColor — لون الشارة حسب درجة التحقق.

// MARK: - LiveSignalFormat
/// صيغة إشارة Mode 22 من OBDb — منسوخة حرفياً من ملف JSON المصدر.
/// القاعدة الموثقة (مرجع OBDb): القيمة = خام × mul ÷ div + add، ثم تُقص إلى [min, max].
/// nullmax: قيمة مفكوكة تعني "لا توجد بيانات" (تُرجع nil بدلاً من قيمة وهمية).
struct LiveSignalFormat {
    let len: Int            // طول الإشارة بالبت
    let bix: Int            // موضع البت الأول (MSB-first، 0 = أول بت في أول بايت)
    let div: Double
    let mul: Double
    let add: Double
    let min: Double?
    let max: Double?
    let sign: Bool          // مكمل ثنائي (two's complement) للقيم السالبة
    let unit: String        // وحدة OBDb الأصلية كما في الملف
    let nullmax: Double?    // قيمة تعني "لا بيانات"
}

// MARK: - LiveSignalVerification
/// حالة تحقق الإشارة على تورس 2023 (مونديو الجيل الخامس C2).
/// لا توجد إشارة واحدة «مؤكدة على 2023» في أي مصدر — كل الوسوم أدناه
/// درجات ثقة بالدليل المتوفر، وكلها تنتهي بـ «يحتاج تحقق على السيارة».
/// - crossConfirmed2021And2026: أقوى المرشحات — بردود مسجلة على مونديو 2021
///   وتورس 2026 معاً (0316، 0318، 033C، 03BC).
/// - taurus2026Confirmed: بردود مسجلة على تورس 2026 (OBDb/Ford-Taurus
///   test cases 2026) — وهي بالضرورة تورس الشرق الأوسط C2، لكن موديل 2026
///   لا 2023.
/// - experimental2022Plus: الإشارات السبع ABS الموسومة 2022+ في ملف المونديو —
///   سريانها يشمل 2022+ لكنها مصنفة تجريبية (dbgfilter) لتلك السنوات،
///   وتسجيلاتها الوحيدة من مونديو 2011 واقفة. كانت «موثقة لـ 2022+» في v1.2
///   خطأً، وصُححت هنا إلى تجريبية.
/// - experimental2022: إشارات PCM الـ 16 ذات dbgfilter-from-2022 في ملف المونديو —
///   تجريبية من 2022، مؤكدة على مونديو 2021 (جيل رابع CD4) لا على C2.
/// - needsVerification: من أجيال أقدم أو بلا سنة محددة — لا تُعرض أبداً كمؤكدة على 2023.
enum LiveSignalVerification {
    case crossConfirmed2021And2026
    case taurus2026Confirmed
    case experimental2022Plus
    case experimental2022
    case needsVerification

    var badgeAr: String {
        switch self {
        case .crossConfirmed2021And2026: return "مؤكد على مونديو 2021 وتورس 2026 — يحتاج تحقق على 2023"
        case .taurus2026Confirmed: return "مؤكد على تورس 2026 — يحتاج تحقق على 2023"
        case .experimental2022Plus: return "تجريبية — تحتاج تحقق على السيارة"
        case .experimental2022: return "تجريبية من 2022 — تحتاج تحقق"
        case .needsVerification: return "تحتاج تحقق على السيارة"
        }
    }

    /// لون الشارة: أخضر لأقوى المرشحات (ردود مسجلة على سيارتين)،
    /// برتقالي لكل ما هو تجريبي أو بلا دليل مباشر.
    var badgeColor: Color {
        switch self {
        case .crossConfirmed2021And2026, .taurus2026Confirmed: return .green
        case .experimental2022Plus, .experimental2022, .needsVerification: return .orange
        }
    }
}

// MARK: - LiveSignalReading
/// نتيجة قراءة إشارة واحدة: القيمة المفكوكة والرد الخام كما وصل من القطعة.
/// الرد الخام يُعرض دائماً بجانب القيمة حتى يكون أي خطأ في الفك ظاهراً.
struct LiveSignalReading {
    let value: Double?      // nil = الوحدة ردت لكن القيمة تعني "لا بيانات"
    let rawHex: String      // بايتات البيانات بعد "62 DID" بصيغة Hex
}

// MARK: - LiveSignal
/// إشارة بيانات حية Mode 22 (UDS ReadDataByIdentifier) — قراءة فقط.
/// كل القيم هنا من ملفي OBDb Ford-Mondeo و OBDb Ford-Taurus حرفياً — لا DID ولا
/// معامل تحويل مخترع. إن تعارض الملفان في نفس الـ DID، يُعرض التعارض في
/// conflictNote ولا يُختار أحدهما عشوائياً.
struct LiveSignal: Identifiable {
    let id: String              // معرّف OBDb (مثل MONDEO_FR_VSS)
    let nameAr: String
    let module: Module          // الوحدة (IPC 720 / BdyCM 726 / ABS 760)
    let did: String             // معرّف البيانات (أمر 22)
    let format: LiveSignalFormat
    let source: String          // المصدر حرفياً
    let verification: LiveSignalVerification
    let conflictNote: String?   // تعارض مسجل بين الملفين (إن وجد)
    let noteAr: String?         // ملاحظة إضافية من الملف (مثل علامة dbg)

    // MARK: - Decode
    /// فك بايتات البيانات (بعد "62 DID") حسب صيغة OBDb.
    /// استخراج البتات MSB-first، ثم خام × mul ÷ div + add، ثم قص إلى [min, max].
    /// ترتيب البايتات MSB-first حسب مرجع OBDb؛ يُتحقق على السيارة الفعلية.
    func decode(data: [UInt8]) -> Double? {
        guard format.len > 0, format.len <= 32,
              format.bix + format.len <= data.count * 8 else { return nil }
        var raw: UInt64 = 0
        for i in 0..<format.len {
            let bitIndex = format.bix + i
            let byteIndex = bitIndex / 8
            let bitInByte = 7 - (bitIndex % 8)
            raw = (raw << 1) | UInt64((data[byteIndex] >> bitInByte) & 1)
        }
        var value: Double
        if format.sign {
            let signBit: UInt64 = 1 << (format.len - 1)
            if raw & signBit != 0 {
                value = Double(Int64(raw) - Int64(1 << format.len))
            } else {
                value = Double(raw)
            }
        } else {
            value = Double(raw)
        }
        value = value * format.mul / format.div + format.add
        if let nullmax = format.nullmax, value >= nullmax { return nil }
        if let min = format.min { value = Swift.max(value, min) }
        if let max = format.max { value = Swift.min(value, max) }
        return value
    }

    // MARK: - Display
    /// الوحدة بالعربية.
    var unitAr: String {
        switch format.unit {
        case "kilometersPerHour": return "كم/س"
        case "kilometers": return "كم"
        case "percent": return "٪"
        case "psi": return "psi"
        case "volts": return "فولت"
        case "celsius": return "°م"
        case "kilopascal": return "كيلوباسكال"
        case "degrees": return "درجة"
        case "seconds": return "ثانية"
        case "hours": return "ساعة"
        case "offon": return ""
        case "scalar": return "قيمة خام"
        default: return format.unit
        }
    }

    /// نص معامل التحويل كما في الملف: "خام × 100 ÷ 255" أو "خام ÷ 10" أو "خام".
    /// يستخدم دقة كاملة (%.6g) لأن بعض المعاملات صغيرة جداً (مثل × 0.000488)
    /// فتظهر "× 0" خطأً إن قُصّت إلى منزلتين عشريتين.
    var formulaText: String {
        var parts = ["خام"]
        if format.mul != 1 { parts.append("× \(trimNumberFull(format.mul))") }
        if format.div != 1 { parts.append("÷ \(trimNumberFull(format.div))") }
        if format.add != 0 {
            parts.append(format.add > 0 ? "+ \(trimNumberFull(format.add))" : "− \(trimNumberFull(-format.add))")
        }
        if format.bix != 0 { parts.append("(من البت \(format.bix))") }
        if format.sign { parts.append("(بإشارة سالبة)") }
        return parts.joined(separator: " ")
    }

    /// تنسيق القيمة المفكوكة مع وحدتها.
    func formattedValue(_ value: Double) -> String {
        if format.unit == "offon" {
            return value >= 1 ? "1 — تحذير مفعّل" : "0 — لا تحذير"
        }
        let num: String
        if format.div == 1 && format.mul == 1 && format.add == 0 {
            num = "\(Int(value))"
        } else {
            num = trimNumber(value, decimals: 2)
        }
        return unitAr.isEmpty ? num : "\(num) \(unitAr)"
    }

    private func trimNumber(_ value: Double, decimals: Int = 2) -> String {
        var s = String(format: "%.\(decimals)f", value)
        while s.contains(".") && s.hasSuffix("0") { s.removeLast() }
        if s.hasSuffix(".") { s.removeLast() }
        return s
    }

    /// تنسيق بدقة كاملة لمعاملات التحويل (يحافظ على القيم الصغيرة مثل 0.000488).
    private func trimNumberFull(_ value: Double) -> String {
        String(format: "%.6g", value)
    }
}

// MARK: - Signal catalogue (from OBDb JSON files, verbatim)
extension LiveSignal {

    /// الإشارات السبع الموسومة 2022+ في ملف OBDb Ford-Mondeo — كلها من ABS 760.
    /// filter في الملف: {"to": 2012, "from": 2022} — لكن dbgfilter يصنفها
    /// تجريبية (debug) من 2012 فصاعداً، بما فيها 2022+.
    /// تصحيح v1.3: كانت «موثقة لـ 2022+» في v1.2 خطأً. الحقيقة من القراءة
    /// الحرفية لملفات الاختبار: تسجيلاتها الوحيدة من مونديو 2011 واقفة
    /// (كلها أصفار عدا 2B11)، وكانت غير مدعومة على مونديو 2015 و2017 و2018،
    /// ولم يعمل منها على مونديو 2019 إلا 2B11. فهي مرشحات تجريبية، لا موثقة.
    static let experimental2022Plus: [LiveSignal] = [
        LiveSignal(
            id: "MONDEO_FR_VSS", nameAr: "سرعة العجلة الأمامية اليمنى",
            module: .abs, did: "2B06",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 200, sign: false, unit: "kilometersPerHour", nullmax: nil),
            source: "OBDb Ford-Mondeo — filter يشمل 2022+، لكن dbgfilter تجريبية من 2012",
            verification: .experimental2022Plus, conflictNote: nil,
            noteAr: "تسجيلاتها الوحيدة من مونديو 2011 واقفة (صفر)؛ غير مدعومة على مونديو 2015/2017/2018."
        ),
        LiveSignal(
            id: "MONDEO_FL_VSS", nameAr: "سرعة العجلة الأمامية اليسرى",
            module: .abs, did: "2B07",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 200, sign: false, unit: "kilometersPerHour", nullmax: nil),
            source: "OBDb Ford-Mondeo — filter يشمل 2022+، لكن dbgfilter تجريبية من 2012",
            verification: .experimental2022Plus, conflictNote: nil,
            noteAr: "تسجيلاتها الوحيدة من مونديو 2011 واقفة (صفر)؛ غير مدعومة على مونديو 2015/2017/2018."
        ),
        LiveSignal(
            id: "MONDEO_RR_VSS", nameAr: "سرعة العجلة الخلفية اليمنى",
            module: .abs, did: "2B08",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 200, sign: false, unit: "kilometersPerHour", nullmax: nil),
            source: "OBDb Ford-Mondeo — filter يشمل 2022+، لكن dbgfilter تجريبية من 2012",
            verification: .experimental2022Plus, conflictNote: nil,
            noteAr: "تسجيلاتها الوحيدة من مونديو 2011 واقفة (صفر)؛ غير مدعومة على مونديو 2015/2017/2018."
        ),
        LiveSignal(
            id: "MONDEO_RL_VSS", nameAr: "سرعة العجلة الخلفية اليسرى",
            module: .abs, did: "2B09",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 200, sign: false, unit: "kilometersPerHour", nullmax: nil),
            source: "OBDb Ford-Mondeo — filter يشمل 2022+، لكن dbgfilter تجريبية من 2012",
            verification: .experimental2022Plus, conflictNote: nil,
            noteAr: "تسجيلاتها الوحيدة من مونديو 2011 واقفة (صفر)؛ غير مدعومة على مونديو 2015/2017/2018."
        ),
        LiveSignal(
            id: "MONDEO_LAT_ANG", nameAr: "زاوية الانحراف",
            module: .abs, did: "2B0C",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1, mul: 1, add: 0, min: -32768, max: 32767, sign: true, unit: "scalar", nullmax: nil),
            source: "OBDb Ford-Mondeo — filter يشمل 2022+، لكن dbgfilter تجريبية من 2012",
            verification: .experimental2022Plus, conflictNote: nil, noteAr: "تسجيلاتها الوحيدة من مونديو 2011 واقفة (صفر)؛ غير مدعومة على مونديو 2015/2017/2018. الملف لا يسمي وحدة فيزيائية — القيمة عدد خام."
        ),
        LiveSignal(
            id: "MONDEO_BRK_FL_P", nameAr: "ضغط الفرامل الهيدروليكي",
            module: .abs, did: "2B0D",
            // جرّب أولاً: صيغة التورس (8 بت، كيلوباسكال) — بيانات اختبار التورس
            // تؤيدها: الرد 0x0025 يُفك 0 بالبايت الأول، بينما صيغة المونديو
            // (16 بت) تعطي 37 لنفس الرد. صيغة المونديو مسجلة في التعارض أدناه.
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 255, sign: false, unit: "kilopascal", nullmax: nil),
            source: "OBDb Ford-Taurus (الصيغة المعروضة) + OBDb Ford-Mondeo (تعارض مسجل)",
            verification: .experimental2022Plus,
            conflictNote: "تعارض صيغة: ملف المونديو يعطي لنفس الـ DID طول 16 بت وقيمة خام (حد أقصى 65535)، بينما ملف التورس يعطي 8 بت وكيلوباسكال (حد أقصى 255). المعروض هنا صيغة التورس لأن بيانات اختبار التورس تؤيدها (الرد 0x0025 ← 0) — يُتحقق على السيارة الفعلية.",
            noteAr: "تسجيلاتها الوحيدة من مونديو 2011 واقفة (صفر)؛ غير مدعومة على مونديو 2015/2017/2018."
        ),
        LiveSignal(
            id: "MONDEO_LAT_G", nameAr: "التسارع الجانبي",
            module: .abs, did: "2B11",
            format: LiveSignalFormat(len: 16, bix: 0, div: 50, mul: 1, add: 0, min: -1, max: 1, sign: true, unit: "scalar", nullmax: nil),
            source: "OBDb Ford-Mondeo — filter يشمل 2022+، لكن dbgfilter تجريبية من 2012",
            verification: .experimental2022Plus, conflictNote: nil,
            noteAr: "الوحيدة من المجموعة التي أجابت على مونديو 2019؛ ولها قيم حقيقية في اختبارات التورس تؤكد القسمة على 50 (0x0010 ← 0.32). الملف لا يسمي وحدة فيزيائية — القيمة عدد خام."
        ),
    ]

    /// إشارات عامة من ملفي المونديو والتورس — تحتاج تحقق على السيارة.
    /// لا تُعرض أبداً كمؤكدة على 2023.
    static let general: [LiveSignal] = [
        LiveSignal(
            id: "MONDEO_ODO", nameAr: "العداد (المسافة المقطوعة)",
            module: .ipc, did: "404C",
            format: LiveSignalFormat(len: 24, bix: 0, div: 10, mul: 1, add: 0, min: nil, max: 1677721, sign: false, unit: "kilometers", nullmax: nil),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس الصيغة في الملفين",
            verification: .needsVerification, conflictNote: nil,
            noteAr: "موسومة تجريبية (dbg) في ملف المونديو. لم يجب عليها IPC أي سيارة مونديو اختُبرت (2011/2015/2017/2018/2019/2021) — بينما أجابت عليها التورس الأمريكية. على C2 جرّبها وتوقع عدم الإجابة؛ البديل 7E0 DD01 مؤكد على مونديو 2021 (220,294 كم)."
        ),
        LiveSignal(
            id: "MONDEO_FLI", nameAr: "مستوى الوقود في الخزان",
            module: .ipc, did: "6185",
            format: LiveSignalFormat(len: 8, bix: 0, div: 255, mul: 100, add: 0, min: nil, max: 100, sign: false, unit: "percent", nullmax: nil),
            source: "OBDb Ford-Mondeo فقط",
            verification: .needsVerification, conflictNote: nil,
            noteAr: "موسومة تجريبية (dbg) في ملف المونديو، وغير موجودة في ملف التورس. مرشح ضعيف على C2 — لم تجب على أي سيارة مونديو اختُبرت."
        ),
        LiveSignal(
            id: "MONDEO_TPMS_WARN", nameAr: "تحذير ضغط الإطارات",
            module: .ipc, did: "61A5",
            format: LiveSignalFormat(len: 1, bix: 2, div: 1, mul: 1, add: 0, min: nil, max: 1, sign: false, unit: "offon", nullmax: nil),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس الصيغة في الملفين",
            verification: .needsVerification, conflictNote: nil,
            noteAr: "موسومة تجريبية (dbg) في ملف المونديو. مرشح ضعيف على C2 — لم تجب على أي سيارة مونديو اختُبرت (غير مدعومة على 2011/2015/2017/2018/2019/2021)؛ أجابت عليها التورس الأمريكية."
        ),
        LiveSignal(
            id: "MONDEO_TP_FL", nameAr: "ضغط الإطار الأمامي الأيسر",
            module: .bdyCM, did: "2813",
            format: LiveSignalFormat(len: 16, bix: 0, div: 20, mul: 1, add: 0, min: nil, max: 150, sign: false, unit: "psi", nullmax: 150),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس القسمة والوحدة",
            verification: .needsVerification,
            conflictNote: "ملف OBDb Ford-Taurus يعطي لنفس الـ DID حداً أقصى 3276 بلا nullmax، بينما ملف المونديو يعطي 150 مع nullmax 150 (قيمة 150 تعني «لا بيانات»). المعروض هنا من المونديو (منصة السيارة) — يُتحقق على السيارة الفعلية.",
            noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_TP_FR", nameAr: "ضغط الإطار الأمامي الأيمن",
            module: .bdyCM, did: "2814",
            format: LiveSignalFormat(len: 16, bix: 0, div: 20, mul: 1, add: 0, min: nil, max: 150, sign: false, unit: "psi", nullmax: 150),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس القسمة والوحدة",
            verification: .needsVerification,
            conflictNote: "ملف OBDb Ford-Taurus يعطي لنفس الـ DID حداً أقصى 3276 بلا nullmax، بينما ملف المونديو يعطي 150 مع nullmax 150 (قيمة 150 تعني «لا بيانات»). المعروض هنا من المونديو (منصة السيارة) — يُتحقق على السيارة الفعلية.",
            noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_TP_RR", nameAr: "ضغط الإطار الخلفي الأيمن",
            module: .bdyCM, did: "2815",
            format: LiveSignalFormat(len: 16, bix: 0, div: 20, mul: 1, add: 0, min: nil, max: 150, sign: false, unit: "psi", nullmax: 150),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس القسمة والوحدة",
            verification: .needsVerification,
            conflictNote: "ملف OBDb Ford-Taurus يعطي لنفس الـ DID حداً أقصى 3276 بلا nullmax، بينما ملف المونديو يعطي 150 مع nullmax 150 (قيمة 150 تعني «لا بيانات»). المعروض هنا من المونديو (منصة السيارة) — يُتحقق على السيارة الفعلية.",
            noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_TP_RL", nameAr: "ضغط الإطار الخلفي الأيسر",
            module: .bdyCM, did: "2816",
            format: LiveSignalFormat(len: 16, bix: 0, div: 20, mul: 1, add: 0, min: nil, max: 150, sign: false, unit: "psi", nullmax: 150),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس القسمة والوحدة",
            verification: .needsVerification,
            conflictNote: "ملف OBDb Ford-Taurus يعطي لنفس الـ DID حداً أقصى 3276 بلا nullmax، بينما ملف المونديو يعطي 150 مع nullmax 150 (قيمة 150 تعني «لا بيانات»). المعروض هنا من المونديو (منصة السيارة) — يُتحقق على السيارة الفعلية.",
            noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_12V_SOC", nameAr: "شحن البطارية (12V)",
            module: .bdyCM, did: "4028",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 100, sign: false, unit: "percent", nullmax: nil),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس الصيغة في الملفين",
            verification: .needsVerification, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_12V_T", nameAr: "حرارة البطارية (12V)",
            module: .bdyCM, did: "4029",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: -40, min: -40, max: 100, sign: false, unit: "celsius", nullmax: nil),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس الصيغة في الملفين",
            verification: .needsVerification, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_12V_V", nameAr: "جهد البطارية (12V)",
            module: .bdyCM, did: "402A",
            format: LiveSignalFormat(len: 8, bix: 0, div: 20, mul: 1, add: 6, min: nil, max: 18.75, sign: false, unit: "volts", nullmax: nil),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس القسمة والإزاحة",
            verification: .needsVerification,
            conflictNote: "ملف OBDb Ford-Taurus يضيف حداً أدنى 6 للصيغة؛ النتيجة المفكوكة نفسها في الملفين لأن القيمة = خام ÷ 20 + 6 ولا تقل عن 6 أبداً.",
            noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_12V_AGE", nameAr: "عمر البطارية",
            module: .bdyCM, did: "4027",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1, mul: 24, add: 0, min: nil, max: 1572840, sign: false, unit: "hours", nullmax: nil),
            source: "OBDb Ford-Mondeo (الصيغة المعروضة) + OBDb Ford-Taurus (تعارض مسجل)",
            verification: .needsVerification,
            conflictNote: "تعارض صيغة: ملف المونديو يعطي عمر البطارية بالساعات (خام ×24، حد أقصى 1,572,840)، بينما ملف التورس يعطيه بالأيام (حد أقصى 1825). المعروض هنا صيغة المونديو (منصة السيارة) — يُتحقق على السيارة الفعلية.",
            noteAr: "اختبارات التورس تؤكد صيغة التورس على سيارتها (خام 4593 ← مقيّد إلى 1825)؛ واختبارات المونديو تؤكد صيغة المونديو (خام 4095 ← 98,280 ساعة)."
        ),
        LiveSignal(
            id: "MONDEO_INJ_IMPULSE_WIDTH", nameAr: "عرض نبضة الحقن",
            module: .pcm, did: "1141",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1, mul: 2.2e-05, add: 0, min: nil, max: 0.05, sign: false, unit: "seconds", nullmax: nil),
            source: "OBDb Ford-Mondeo (الصيغة المعروضة) + OBDb Ford-Taurus (تعارض مسجل)",
            verification: .needsVerification,
            conflictNote: "تعارض جوهري: إشارتان مختلفتان تماماً بنفس الـ DID — المونديو «عرض نبضة الحقن» بالثواني (×2.2e-05)، والتورس «عرض نبضة مضخة الوقود، البنك 1» عدد خام (÷5). لا اختيار قبل الاختبار على السيارة. المعروض هنا صيغة المونديو (منصة السيارة) مؤقتاً.",
            noteAr: "موسومة تجريبية (dbg) في كلا الملفين."
        ),
        LiveSignal(
            id: "MONDEO_TRANS_ODO", nameAr: "عداد ناقل الحركة",
            module: .tcm, did: "DD01",
            format: LiveSignalFormat(len: 24, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 16777215, sign: false, unit: "kilometers", nullmax: nil),
            source: "OBDb Ford-Mondeo (الصيغة المعروضة) + OBDb Ford-Taurus (تعارض مسجل)",
            verification: .needsVerification,
            conflictNote: "تعارض صيغة: ملف المونديو يعطي الوحدة kilometers، بينما ملف التورس يعطي celsius لعداد مسافة — خطأ صريح في ملف التورس. المعروض هنا صيغة المونديو. القراءة من TCM قراءة فقط — الكتابة في TCM محظورة نهائياً.",
            noteAr: "موسومة تجريبية (dbg) في ملف التورس."
        ),
    ]

    /// الأوامر الأربعة المؤكدة على مونديو 2021 وتورس 2026 معاً — أقوى المرشحات.
    /// كلها من PCM 7E0، بردود مسجلة في ملفات اختبار OBDb للسيارتين.
    static let crossConfirmed2021And2026: [LiveSignal] = [
        LiveSignal(
            id: "TAURUS_VCT_INT_DUTY", nameAr: "دورة ملف عمود الكامات (دخول)",
            module: .pcm, did: "0316",
            format: LiveSignalFormat(len: 16, bix: 0, div: 8192, mul: 25, add: 0, min: nil, max: 100, sign: false, unit: "percent", nullmax: nil),
            source: "OBDb Ford-Taurus + OBDb Ford-Mondeo — نفس الصيغة في الملفين",
            verification: .crossConfirmed2021And2026, conflictNote: nil, noteAr: "مؤكد بردود مسجلة على مونديو 2021 (جيل رابع CD4) وتورس 2026 معاً."
        ),
        LiveSignal(
            id: "MONDEO_VCT_INT_ACT", nameAr: "موضع عمود الكامات الفعلي (دخول)",
            module: .pcm, did: "0318",
            format: LiveSignalFormat(len: 16, bix: 0, div: 16, mul: 1, add: 0, min: -2048, max: 2047.93, sign: true, unit: "degrees", nullmax: nil),
            source: "OBDb Ford-Mondeo (الصيغة المعروضة) + OBDb Ford-Taurus (تعارض مسجل)",
            verification: .crossConfirmed2021And2026, conflictNote: "تعارض صيغة: ملف التورس يعطي لنفس الـ DID حداً أقصى 0 بلا إشارة — خطأ صريح في الملف (اختبارات التورس نفسها تتوقع 4080–4095 للقيم الكبيرة). المعروض هنا صيغة المونديو (موقّعة، حد أقصى 2047.93).", noteAr: "مؤكد بردود مسجلة على مونديو 2021 (جيل رابع CD4) وتورس 2026 معاً."
        ),
        LiveSignal(
            id: "TAURUS_TIP_V", nameAr: "جهد حساس ضغط مدخل الخانق",
            module: .pcm, did: "033C",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1024, mul: 5, add: 0, min: nil, max: 5, sign: false, unit: "volts", nullmax: nil),
            source: "OBDb Ford-Taurus + OBDb Ford-Mondeo — نفس الصيغة في الملفين",
            verification: .crossConfirmed2021And2026, conflictNote: nil, noteAr: "مؤكد بردود مسجلة على مونديو 2021 (جيل رابع CD4) وتورس 2026 معاً."
        ),
        LiveSignal(
            id: "TAURUS_VCT_INT_DES", nameAr: "موضع عمود الكامات المطلوب (دخول)",
            module: .pcm, did: "03BC",
            format: LiveSignalFormat(len: 16, bix: 0, div: 16, mul: 1, add: 0, min: -2047, max: 2047, sign: true, unit: "degrees", nullmax: nil),
            source: "OBDb Ford-Taurus + OBDb Ford-Mondeo — نفس الصيغة في الملفين",
            verification: .crossConfirmed2021And2026, conflictNote: nil, noteAr: "مؤكد بردود مسجلة على مونديو 2021 (جيل رابع CD4) وتورس 2026 معاً."
        ),
    ]

    /// أوامر PCM الـ 23 المتبقية المؤكدة بردود مسجلة على تورس 2026 + فرامل اليد.
    /// المصدر: OBDb/Ford-Taurus tests/test_cases/2026 (التزام #486، 2026-11-13).
    /// تورس 2026 لا يمكن أن تكون إلا تورس الشرق الأوسط C2 (الإنتاج الأمريكي انتهى 2019).
    /// لا يُعرض 2203F3 — غير مدعوم على تورس 2026.
    static let taurus2026Confirmed: [LiveSignal] = [
        LiveSignal(
            id: "TAURUS_MAP_V", nameAr: "جهد حساس ضغط المنوع",
            module: .pcm, did: "0301",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1024, mul: 1, add: 0, min: nil, max: 5, sign: false, unit: "volts", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_CMD_GEN_V", nameAr: "جهد المولد المطلوب",
            module: .pcm, did: "0304",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1, mul: 0.000488, add: 0, min: nil, max: 16, sign: false, unit: "volts", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_VCT_EXH_DUTY", nameAr: "دورة ملف عمود الكامات (خروج)",
            module: .pcm, did: "0317",
            format: LiveSignalFormat(len: 16, bix: 0, div: 8192, mul: 25, add: 0, min: nil, max: 100, sign: false, unit: "percent", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: "موسومة تجريبية (dbg) في ملف المونديو، لكنها مؤكدة بردود مسجلة على تورس 2026."
        ),
        LiveSignal(
            id: "TAURUS_VCT_INT_ERR", nameAr: "خطأ موضع عمود الكامات (دخول)",
            module: .pcm, did: "031A",
            format: LiveSignalFormat(len: 16, bix: 0, div: 16, mul: 1, add: 0, min: -50, max: 50, sign: true, unit: "degrees", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_VCT_EXH_ERR", nameAr: "خطأ موضع عمود الكامات (خروج)",
            module: .pcm, did: "031B",
            format: LiveSignalFormat(len: 16, bix: 0, div: 16, mul: 1, add: 0, min: nil, max: 50, sign: false, unit: "degrees", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: "موسومة تجريبية (dbg) في ملف المونديو، لكنها مؤكدة بردود مسجلة على تورس 2026."
        ),
        LiveSignal(
            id: "TAURUS_PCM_MISF_EVENTS_LATEST_CYC", nameAr: "أحداث الإخفاق في آخر دورة",
            module: .pcm, did: "0345",
            format: LiveSignalFormat(len: 32, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 4294967295, sign: false, unit: "scalar", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_MAP_HIRES", nameAr: "ضغط المنوع عالي الدقة",
            module: .pcm, did: "0370",
            format: LiveSignalFormat(len: 16, bix: 0, div: 4, mul: 1, add: 0, min: nil, max: 16383.75, sign: false, unit: "kilopascal", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_PCM_MISF_ACCEL_CYL4_NORM", nameAr: "تسارع الإخفاق للأسطوانة 4",
            module: .pcm, did: "038B",
            format: LiveSignalFormat(len: 8, bix: 0, div: 64, mul: 1, add: 0, min: -2, max: 1.98, sign: true, unit: "scalar", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_EVAP_V", nameAr: "جهد حساس ضغط التبخير",
            module: .pcm, did: "038E",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1000, mul: 1, add: 0, min: nil, max: 65.535, sign: false, unit: "volts", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: "تعارض صيغة: ملف المونديو يعطي لنفس الـ DID عدداً خاماً (حد أقصى 65535، بلا وحدة)، بينما ملف التورس يعطي فولت (÷1000). المعروض هنا صيغة التورس لأنها من اختبارات تورس 2026 — يُتحقق على السيارة الفعلية.", noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_KS1_RAW", nameAr: "حساس الطرق 1 (خام)",
            module: .pcm, did: "0403",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 65535, sign: false, unit: "scalar", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_LPFP_DES", nameAr: "ضغط مضخة الوقود منخفض الضغط المطلوب",
            module: .pcm, did: "041F",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1000, mul: 435, add: 0, min: nil, max: 110, sign: false, unit: "psi", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_LPFP_ACT", nameAr: "ضغط مضخة الوقود منخفض الضغط الفعلي",
            module: .pcm, did: "0548",
            format: LiveSignalFormat(len: 16, bix: 0, div: 137892, mul: 10000, add: 0, min: nil, max: 200, sign: true, unit: "psi", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_PCM_ENG_OIL_LIFE_REM", nameAr: "عمر الزيت المتبقي",
            module: .pcm, did: "054B",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 100, sign: false, unit: "percent", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: "أقوى قراءة حية لعمر الزيت: رد مسجل على تورس 2026 هو 71% (7E80462054B47). قراءة فقط — لا علاقة لها بميزة إظهار عمر الزيت في الشاشة (#3) التي تكتب في APIM."
        ),
        LiveSignal(
            id: "TAURUS_ETC_ANG_DES", nameAr: "زاوية الخانق الإلكتروني المطلوبة",
            module: .pcm, did: "091A",
            format: LiveSignalFormat(len: 16, bix: 0, div: 512, mul: 1, add: 0, min: nil, max: 127.99, sign: false, unit: "degrees", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_EVAP_PURGE_CMD", nameAr: "أمر تطهير التبخير",
            module: .pcm, did: "1166",
            format: LiveSignalFormat(len: 16, bix: 0, div: 32768, mul: 100, add: 0, min: nil, max: 100, sign: false, unit: "percent", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_IGN_TIM_CYL1", nameAr: "توقيت الإشعال للأسطوانة 1",
            module: .pcm, did: "116B",
            format: LiveSignalFormat(len: 16, bix: 0, div: 4, mul: 1, add: 0, min: -80, max: 80, sign: true, unit: "degrees", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_IAT_SENS_V", nameAr: "جهد حساس حرارة الهواء الداخل",
            module: .pcm, did: "1279",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1023, mul: 5, add: 0, min: nil, max: 5, sign: false, unit: "volts", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_ENG_LOAD_PCT", nameAr: "حمل المحرك",
            module: .pcm, did: "F404",
            format: LiveSignalFormat(len: 8, bix: 0, div: 255, mul: 100, add: 0, min: nil, max: 100, sign: false, unit: "percent", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_STFT", nameAr: "تصحيح الوقود قصير المدى",
            module: .pcm, did: "F406",
            format: LiveSignalFormat(len: 8, bix: 0, div: 128, mul: 100, add: -100, min: -100, max: 99.2, sign: false, unit: "percent", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_LTFT", nameAr: "تصحيح الوقود طويل المدى",
            module: .pcm, did: "F407",
            format: LiveSignalFormat(len: 8, bix: 0, div: 128, mul: 100, add: -100, min: -100, max: 99.2, sign: false, unit: "percent", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_MAP", nameAr: "ضغط المنوع",
            module: .pcm, did: "F40B",
            format: LiveSignalFormat(len: 8, bix: 0, div: 68947, mul: 10000, add: 0, min: nil, max: 36, sign: false, unit: "psi", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_MIL_DIST", nameAr: "المسافة منذ إضاءة لمبة الأعطال",
            module: .pcm, did: "F421",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 65535, sign: false, unit: "kilometers", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_CAT_TEMP", nameAr: "حرارة المحفز",
            module: .pcm, did: "F43C",
            format: LiveSignalFormat(len: 16, bix: 0, div: 10, mul: 1, add: -40, min: -40, max: 6513.5, sign: false, unit: "celsius", nullmax: nil),
            source: "OBDb Ford-Taurus — اختبار تورس 2026 (رد مسجل)",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "TAURUS_PARK_BRK", nameAr: "حالة فرامل اليد",
            module: .abs, did: "2B00",
            format: LiveSignalFormat(len: 1, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 1, sign: false, unit: "offon", nullmax: nil),
            source: "OBDb Ford-Taurus — في قائمة دعم تورس 2026 بلا ملف رد مسجل",
            verification: .taurus2026Confirmed, conflictNote: nil, noteAr: "مرشح ضعيف — متذبذبة بين السيارات: مدعومة على تورس 2026 ومونديو 2017، وغير مدعومة على مونديو 2021 و2015 و2018 و2019. موضع البت افتراضي 0 — غير متحقق من أي اختبار."
        ),
    ]

    /// إشارات PCM الـ 12 المتبقية ذات dbgfilter-from-2022 في ملف المونديو.
    /// تجريبية من 2022؛ مؤكدة بردود مسجلة على مونديو 2021 (جيل رابع CD4) لا على C2.
    /// (الأربعة المتقاطعة مع تورس 2026 — 0316 و0318 و033C و03BC — في crossConfirmed2021And2026 أعلاه.)
    static let experimental2022: [LiveSignal] = [
        LiveSignal(
            id: "MONDEO_LPFP_DUTY", nameAr: "دورة مضخة الوقود منخفض الضغط",
            module: .pcm, did: "0307",
            format: LiveSignalFormat(len: 16, bix: 0, div: 8192, mul: 25, add: 0, min: nil, max: 100, sign: false, unit: "percent", nullmax: nil),
            source: "OBDb Ford-Mondeo — dbgfilter تجريبية من 2022؛ مؤكدة على مونديو 2021 (CD4) لا على C2",
            verification: .experimental2022, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_HPFP_V", nameAr: "جهد حساس ضغط الوقود العالي",
            module: .pcm, did: "0324",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1023, mul: 5, add: 0, min: nil, max: 5, sign: false, unit: "volts", nullmax: nil),
            source: "OBDb Ford-Mondeo — dbgfilter تجريبية من 2022؛ مؤكدة على مونديو 2021 (CD4) لا على C2",
            verification: .experimental2022, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_BARO_V", nameAr: "جهد حساس الضغط الجوي",
            module: .pcm, did: "035A",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1023, mul: 5, add: 0, min: nil, max: 5, sign: false, unit: "volts", nullmax: nil),
            source: "OBDb Ford-Mondeo — dbgfilter تجريبية من 2022؛ مؤكدة على مونديو 2021 (CD4) لا على C2",
            verification: .experimental2022, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_RO2_V", nameAr: "جهد حساس الأكسجين الخلفي",
            module: .pcm, did: "035F",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1024, mul: 1, add: 0, min: nil, max: 1, sign: false, unit: "volts", nullmax: nil),
            source: "OBDb Ford-Mondeo — dbgfilter تجريبية من 2022؛ مؤكدة على مونديو 2021 (CD4) لا على C2",
            verification: .experimental2022, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_ECT", nameAr: "حرارة سائل التبريد",
            module: .pcm, did: "038F",
            format: LiveSignalFormat(len: 16, bix: 0, div: 64, mul: 1, add: 0, min: -512, max: 511, sign: true, unit: "celsius", nullmax: nil),
            source: "OBDb Ford-Mondeo — dbgfilter تجريبية من 2022؛ مؤكدة على مونديو 2021 (CD4) لا على C2",
            verification: .experimental2022, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_VCT_EXH_DES", nameAr: "موضع عمود الكامات المطلوب (خروج)",
            module: .pcm, did: "03BB",
            format: LiveSignalFormat(len: 16, bix: 0, div: 16, mul: 1, add: 0, min: -2047, max: 2047, sign: true, unit: "degrees", nullmax: nil),
            source: "OBDb Ford-Mondeo — dbgfilter تجريبية من 2022؛ مؤكدة على مونديو 2021 (CD4) لا على C2",
            verification: .experimental2022, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_CL_LC", nameAr: "تصحيح لامدا",
            module: .pcm, did: "03BD",
            format: LiveSignalFormat(len: 16, bix: 0, div: 8192, mul: 1, add: 0, min: -4, max: 3.9, sign: true, unit: "scalar", nullmax: nil),
            source: "OBDb Ford-Mondeo — dbgfilter تجريبية من 2022؛ مؤكدة على مونديو 2021 (CD4) لا على C2",
            verification: .experimental2022, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_MCT", nameAr: "حرارة المنوع",
            module: .pcm, did: "03CA",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 148.889, sign: false, unit: "celsius", nullmax: nil),
            source: "OBDb Ford-Mondeo — dbgfilter تجريبية من 2022؛ مؤكدة على مونديو 2021 (CD4) لا على C2",
            verification: .experimental2022, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_HPFP_DES", nameAr: "ضغط الوقود العالي المطلوب",
            module: .pcm, did: "03DC",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1, mul: 10, add: 0, min: nil, max: 655350, sign: false, unit: "kilopascal", nullmax: nil),
            source: "OBDb Ford-Mondeo — dbgfilter تجريبية من 2022؛ مؤكدة على مونديو 2021 (CD4) لا على C2",
            verification: .experimental2022, conflictNote: "تعارض صيغة: ملف المونديو يعطي كيلوباسكال (×10، حد أقصى 655350)، بينما ملف التورس يعطي psi (×1.45، حد أقصى 3500). المعروض هنا صيغة المونديو (منصة السيارة) — يُتحقق على السيارة الفعلية.", noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_OAR", nameAr: "تعديل الأوكتان",
            module: .pcm, did: "03E8",
            format: LiveSignalFormat(len: 16, bix: 0, div: 16384, mul: 1, add: 0, min: -1, max: 1, sign: true, unit: "scalar", nullmax: nil),
            source: "OBDb Ford-Mondeo — dbgfilter تجريبية من 2022؛ مؤكدة على مونديو 2021 (CD4) لا على C2",
            verification: .experimental2022, conflictNote: "تعارض صيغة: ملف المونديو يسمح بالقيم السالبة (حد أدنى −1)، بينما ملف التورس بلا حد أدنى — واختبارات المونديو تتوقع قيماً سالبة (−0.36، −0.25، −0.49، −0.96) بينما اختبارات التورس تتوقع 0.0 لكل خام سالب. المعروض هنا صيغة المونديو لأنها متسقة مع اختباراتها.", noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_ODO_7E0", nameAr: "العداد (من كمبيوتر المحرك)",
            module: .pcm, did: "DD01",
            format: LiveSignalFormat(len: 24, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 16777215, sign: false, unit: "kilometers", nullmax: nil),
            source: "OBDb Ford-Mondeo — dbgfilter تجريبية من 2022؛ مؤكدة على مونديو 2021 (CD4) لا على C2",
            verification: .experimental2022, conflictNote: nil, noteAr: "مؤكد بردود مسجلة على مونديو 2021: 220,294 كم."
        ),
        LiveSignal(
            id: "MONDEO_FLI_7E0", nameAr: "مستوى الوقود (من كمبيوتر المحرك)",
            module: .pcm, did: "F42F",
            format: LiveSignalFormat(len: 8, bix: 0, div: 255, mul: 100, add: 0, min: nil, max: 100, sign: false, unit: "percent", nullmax: nil),
            source: "OBDb Ford-Mondeo — dbgfilter تجريبية من 2022؛ مؤكدة على مونديو 2021 (CD4) لا على C2",
            verification: .experimental2022, conflictNote: nil, noteAr: "الوحيدة من الـ 16 بلا ملف اختبار على مونديو 2021 — أُضيفت هنا لأن dbgfilter يشملها من 2022."
        ),
    ]

    /// كل الإشارات — مرتبة بقوة الدليل: الأقوى أولاً (مؤكدة على سيارتين)،
    /// ثم مؤكدة على تورس 2026، ثم التجريبية (ABS ثم PCM 2022)، ثم العامة.
    /// المجموع: 4 + 24 + 7 + 12 + 13 = 60 إشارة.
    static let all: [LiveSignal] = crossConfirmed2021And2026 + taurus2026Confirmed
        + experimental2022Plus + experimental2022 + general
}
