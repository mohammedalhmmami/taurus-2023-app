import Foundation

// MARK: - Vehicle
/// تمثيل السيارة المتصلة. التحقق هنا هو بوابة الأمان الأولى:
/// لا تُعرض أي ميزة قابلة للكتابة إلا بعد أن يثبت أن السيارة تورس 2023.
struct Vehicle: Equatable {
    let vin: String
    let modelYear: Int
    let modelName: String      // مثال: "Ford Taurus"
    let market: String         // مثال: "Saudi Arabia"
    let engine: String         // مثال: "2.0 EcoBoost"
    let syncVersion: String    // مثال: "SYNC 4 — 23151"
    let trim: Trim

    enum Trim: String, Equatable {
        case ambient = "Ambient"
        case trend = "Trend"
        case titanium = "Titanium"
        case unknown = "غير معروف"
    }
}

// MARK: - VIN Validation
/// فحص VIN — لا تنسخ أكواد تورس 2015 إلى 2023 أبداً.
///
/// صور المبرمج تُظهر تورس 2015 TiVCT 3.5L برقم شاصي ينتهي 78923.
/// تلك السيارة: سنة الموديل 2015 (الحرف العاشر في VIN = F)، ومحرك 3.5L.
/// تورس 2023 السعودية: سنة الموديل 2023 (الحرف العاشر = P)، ومحرك 2.0 EcoBoost.
/// أي VIN لا يحقق شروط 2023 يُرفض، ولا تُعرض له مزايا قابلة للكتابة.
enum VINValidator {

    /// الحرف العاشر في VIN يرمز لسنة الموديل (معيار ISO 3779).
    /// F = 2015، P = 2023. انظر: https://www.motorcraftservice.com/AsBuilt
    static func modelYear(from vin: String) -> Int? {
        guard vin.count == 17 else { return nil }
        let yearChar = vin[vin.index(vin.startIndex, offsetBy: 9)]
        // جدول السنوات: ... F=2015 ... P=2023 ...
        let map: [Character: Int] = [
            "F": 2015, "G": 2016, "H": 2017, "J": 2018, "K": 2019,
            "L": 2020, "M": 2021, "N": 2022, "P": 2023, "R": 2024
        ]
        return map[yearChar]
    }

    /// هل هذا VIN لتورس 2023؟ شرط صارم: 17 حرفاً + سنة 2023.
    /// لا نتحقق من بادئة المصنع هنا لأن تورس 2023 السعودية (Changan Ford)
    /// قد تختلف بادئتها عن تورس الأمريكية — التحقق من السنة + إصدار SYNC
    /// + قراءة الوحدات هو التحقق الحقيقي، والبادئة وحدها لا تكفي للرفض أو القبول.
    static func isTaurus2023(vin: String, syncVersion: String) -> ValidationResult {
        guard vin.count == 17 else {
            return .rejected("رقم الشاصي ليس 17 حرفاً — تحقق من القراءة")
        }
        guard let year = modelYear(from: vin) else {
            return .rejected("تعذر تحديد سنة الموديل من رقم الشاصي")
        }
        if year == 2015 {
            // تحذير صريح: هذه سيارة صور المبرمج، وليست 2023.
            return .rejected("هذه تورس 2015 (TiVCT 3.5L) — أكوادها لا تنطبق على تورس 2023 أبداً ولا تُنسخ إليها")
        }
        if year != 2023 {
            return .rejected("السيارة موديل \(year) وليست 2023 — التطبيق يدعم تورس 2023 فقط")
        }
        // SYNC 4 مطلوب. إصدار 22012 أو أعلى مطلوب لثيم Unreal (الميزة 12).
        if !syncVersion.contains("SYNC 4") && !syncVersion.contains("Sync 4") {
            return .rejected("إصدار SYNC غير معروف — التطبيق يدعم SYNC 4 فقط")
        }
        return .accepted
    }

    enum ValidationResult: Equatable {
        case accepted
        case rejected(String)
    }
}
