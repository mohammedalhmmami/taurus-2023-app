import Foundation

// MARK: - FordPlatform
/// منصة السيارة المتصلة — التطبيق عام، يتعرف على السيارة تلقائياً من VIN.
/// القاعدة الملزمة: لا يُنسخ كود من منصة إلى أخرى أبداً.
/// أكواد APIM (SYNC 4) هي الأكثر قابلية للنقل بين سيارات SYNC 4،
/// أما أكواد BdyCM و IPC فتختلف بين المنصات والأجيال (انظر FEATURES.md).
///
/// ملاحظة منهجية صريحة: VIN وحده لا يحدد الموديل بدقة كاملة لكل سيارات فورد.
/// الاستدلال هنا يستخدم WMI (أول 3 أحرف) + سنة الموديل + إصدار SYNC،
/// ويعيد المنصة بثقة `probable` (مرجحة) أو `unknown` (غير معروفة).
/// المنصة تُؤكَّد نهائياً من قراءة الوحدات (أرقام قطع APIM/BdyCM)،
/// والمزايا القابلة للكتابة تبقى معطلة حتى تُؤكَّد المنصة.
enum FordPlatform: String, Equatable, CaseIterable {
    case taurus2023C2  // تورس 2023 السعودية — مونديو الجيل الخامس (2022+، Changan Ford، منصة C2)
    case f150Gen14     // F-150 الجيل 14 (2021+)
    case bronco        // Bronco (2021+)
    case ranger        // Ranger (2019+)
    case maverick      // Maverick (2022+)
    case mustang       // Mustang (2015+)
    case explorer      // Explorer (2020+)
    case edge          // Edge
    case focusMk4C2    // Focus Mk4 (2019+، منصة C2 — أقرب قريب لتورس 2023)
    case unknown       // منصة غير معروفة — فحص قراءة فقط، لا كتابة

    var arabicName: String {
        switch self {
        case .taurus2023C2: return "تورس 2023 — مونديو الجيل الخامس (C2)"
        case .f150Gen14: return "F-150 (2021+)"
        case .bronco: return "Bronco"
        case .ranger: return "Ranger"
        case .maverick: return "Maverick"
        case .mustang: return "Mustang"
        case .explorer: return "Explorer"
        case .edge: return "Edge"
        case .focusMk4C2: return "Focus Mk4 (C2)"
        case .unknown: return "منصة غير معروفة"
        }
    }

    /// هل هذه المنصة من عائلة SYNC 4؟ أكواد APIM 7D0 تنتقل فيها أكثر من غيرها.
    var isSYNC4Family: Bool {
        switch self {
        case .taurus2023C2, .f150Gen14, .bronco, .ranger, .maverick, .mustang, .explorer, .focusMk4C2:
            return true
        case .edge, .unknown:
            return false
        }
    }

    /// هل هذه المنصة على منصة C2؟ (تورس 2023 و Focus Mk4 — الأقرب لبعضهما)
    var isC2: Bool {
        self == .taurus2023C2 || self == .focusMk4C2
    }
}

// MARK: - PlatformConfidence
/// ثقة الاستدلال على المنصة من VIN.
enum PlatformConfidence: Equatable {
    case probable   // مرجحة: WMI + السنة يطابقان منصة معروفة
    case unknown    // غير معروفة: لا يُستدل على المنصة من VIN وحده
}

// MARK: - Vehicle
/// تمثيل السيارة المتصلة. التحقق هنا هو بوابة الأمان الأولى:
/// لا تُعرض أي ميزة قابلة للكتابة إلا بعد التعرف على السيارة ومنصتها.
struct Vehicle: Equatable {
    let vin: String
    let modelYear: Int
    let modelName: String      // مثال: "Ford Taurus" أو "Ford F-150" أو "غير معروف"
    let platform: FordPlatform
    let platformConfidence: PlatformConfidence
    let market: String         // مثال: "Saudi Arabia" أو "غير معروف"
    let engine: String         // مثال: "2.0 EcoBoost" أو "غير معروف"
    let syncVersion: String    // مثال: "SYNC 4 — 23151"
    let trim: Trim

    enum Trim: String, Equatable {
        case ambient = "Ambient"
        case trend = "Trend"
        case titanium = "Titanium"
        case unknown = "غير معروف"
    }
}

// MARK: - VIN Decoding
/// فك تشفير VIN (معيار ISO 3779) + استدلال المنصة.
/// لا تنسخ أكواد تورس 2015 إلى أي سيارة أخرى أبداً.
///
/// صور المبرمج تُظهر تورس 2015 TiVCT 3.5L برقم شاصي ينتهي 78923.
/// تلك السيارة: سنة الموديل 2015 (الحرف العاشر في VIN = F)، ومحرك 3.5L،
/// منصة CD4 (مونديو الجيل الرابع / Fusion). أكوادها لا تنطبق على
/// تورس 2023 (مونديو الجيل الخامس، منصة C2) ولا على أي منصة أخرى.
///
/// تصحيح مهم (بحث عميق 2026-11-15): تورس 2023 السعودية ليست مونديو Mk5،
/// بل مونديو الجيل الخامس (2022+، Changan Ford، الصين)، منصة C2،
/// قريبة من Evos و Lincoln Z. جداول Mk5/Fusion لا تنطبق عليها مباشرة.
enum VINValidator {

    /// الحرف العاشر في VIN يرمز لسنة الموديل (معيار ISO 3779).
    /// الجدول الكامل 2001–2030: 1–9 = 2001–2009، A–Y (عدا I و O و Q و U و Z) = 2010–2030.
    /// F = 2015، P = 2023.
    static func modelYear(from vin: String) -> Int? {
        guard vin.count == 17 else { return nil }
        let yearChar = vin[vin.index(vin.startIndex, offsetBy: 9)]
        let map: [Character: Int] = [
            "1": 2001, "2": 2002, "3": 2003, "4": 2004, "5": 2005,
            "6": 2006, "7": 2007, "8": 2008, "9": 2009,
            "A": 2010, "B": 2011, "C": 2012, "D": 2013, "E": 2014,
            "F": 2015, "G": 2016, "H": 2017, "J": 2018, "K": 2019,
            "L": 2020, "M": 2021, "N": 2022, "P": 2023, "R": 2024,
            "S": 2025, "T": 2026, "V": 2027, "W": 2028, "X": 2029, "Y": 2030
        ]
        return map[yearChar]
    }

    /// بادئات WMI المعروفة لفورد (أول 3 أحرف من VIN).
    /// USA: 1FA/1FB/1FC/1FM/1FT — المكسيك: 3FA/3FT — ألمانيا: WF0/WF1 —
    /// الصين (Changan Ford): LSG/LFP — أستراليا: 6FP — تركيا: NM0.
    /// هذه القائمة للتحقق من أن السيارة فورد أصلاً، وليست لتحديد الموديل.
    static let fordWMIs: Set<String> = [
        "1FA", "1FB", "1FC", "1FD", "1FM", "1FT", "1FZ",
        "3FA", "3FC", "3FT",
        "WF0", "WF1", "WFO",
        "LSG", "LFP", "LVS",
        "6FP", "MAJ", "NM0"
    ]

    /// استدلال المنصة من VIN + إصدار SYNC.
    /// يعيد المنصة المرجحة أو .unknown — لا يخمن منصة أبداً.
    static func inferPlatform(vin: String, syncVersion: String) -> (FordPlatform, PlatformConfidence) {
        guard vin.count == 17 else { return (.unknown, .unknown) }
        let wmi = String(vin.prefix(3))
        let year = modelYear(from: vin)

        // تورس 2023 السعودية: Changan Ford (LSG/LFP)، موديل 2022+، منصة C2.
        // نفس المنصة تشمل Evos و Mondeo Sport — لذلك الثقة "مرجحة" لا "مؤكدة".
        if (wmi == "LSG" || wmi == "LFP"), let year, year >= 2022 {
            return (.taurus2023C2, .probable)
        }
        // Focus Mk4 الأوروبي: ألمانيا (WF0/WF1)، موديل 2019+، منصة C2.
        if (wmi == "WF0" || wmi == "WF1"), let year, year >= 2019 {
            return (.focusMk4C2, .probable)
        }
        // F-150 الجيل 14: أمريكا (1FT/1FM)، موديل 2021+.
        // ملاحظة: WMI نفسه يُستخدم لأجيال سابقة — السنة هي الفيصل.
        if (wmi == "1FT" || wmi == "1FM"), let year, year >= 2021 {
            return (.f150Gen14, .probable)
        }
        // Bronco و Ranger و Maverick و Mustang و Explorer و Edge:
        // لا تُميَّز بدقة من WMI + السنة وحدهما (WMI مشترك بين موديلات).
        // المنصة تُؤكَّد من قراءة الوحدات (أرقام قطع APIM/BdyCM) — انظر DiagnosticsService.
        // حتى ذلك الحين: منصة غير معروفة، فحص قراءة فقط، لا كتابة.
        _ = syncVersion
        return (.unknown, .unknown)
    }

    /// التعرف الكامل على السيارة من VIN.
    /// يقبل أي سيارة فورد بـ VIN صحيح (17 حرفاً). يرفض:
    ///  - VIN غير مكتمل أو غير فورد.
    ///  - تورس 2015 تحديداً كمرجع أكواد (رسالة تحذير صريحة — أكوادها لا تُنسخ).
    /// السيارة ذات المنصة غير المعروفة تُقبل للفحص (قراءة فقط) ولا تُعرض
    /// لها أي ميزة قابلة للكتابة حتى تُؤكَّد منصتها من قراءة الوحدات.
    static func identify(vin: String, syncVersion: String) -> ValidationResult {
        guard vin.count == 17 else {
            return .rejected("رقم الشاصي ليس 17 حرفاً — تحقق من القراءة")
        }
        let wmi = String(vin.prefix(3))
        guard fordWMIs.contains(wmi) else {
            return .rejected("رقم الشاصي ليس لسيارة فورد معروفة (WMI: \(wmi)) — التطبيق يدعم سيارات فورد فقط")
        }
        guard let year = modelYear(from: vin) else {
            return .rejected("تعذر تحديد سنة الموديل من رقم الشاصي")
        }
        if year == 2015 && wmi == "1FA" {
            // تحذير صريح: هذه سيارة صور المبرمج (تورس 2015 TiVCT 3.5L).
            // تُقبل للفحص فقط — أكوادها لا تنطبق على أي سيارة أخرى ولا تُنسخ إليها.
            let (platform, confidence) = inferPlatform(vin: vin, syncVersion: syncVersion)
            let vehicle = Vehicle(vin: vin, modelYear: 2015, modelName: "Ford Taurus 2015",
                                  platform: platform, platformConfidence: confidence,
                                  market: "غير معروف", engine: "3.5L TiVCT",
                                  syncVersion: syncVersion, trim: .unknown)
            return .acceptedWarning(vehicle, "هذه تورس 2015 (TiVCT 3.5L) — أكوادها لا تنطبق على أي سيارة أخرى أبداً ولا تُنسخ إليها. الفحص فقط، لا كتابة.")
        }
        let (platform, confidence) = inferPlatform(vin: vin, syncVersion: syncVersion)
        let modelName: String
        switch platform {
        case .taurus2023C2: modelName = "Ford Taurus (Mondeo 5th-gen, C2)"
        case .f150Gen14: modelName = "Ford F-150"
        case .focusMk4C2: modelName = "Ford Focus Mk4 (C2)"
        default: modelName = "Ford (الموديل يُحدد من قراءة الوحدات)"
        }
        let vehicle = Vehicle(vin: vin, modelYear: year, modelName: modelName,
                              platform: platform, platformConfidence: confidence,
                              market: platform == .taurus2023C2 ? "Saudi Arabia" : "غير معروف",
                              engine: platform == .taurus2023C2 ? "2.0 EcoBoost" : "غير معروف",
                              syncVersion: syncVersion, trim: .unknown)
        return .accepted(vehicle)
    }

    /// توافق قديم: هل هذه تورس 2023؟ يُستخدم فقط كاختصار في الشاشات القديمة.
    /// لا تستخدمه كبوابة كتابة — بوابة الكتابة هي PlatformSupport + SafetyService.
    static func isTaurus2023(vin: String, syncVersion: String) -> ValidationResult {
        switch identify(vin: vin, syncVersion: syncVersion) {
        case .accepted(let vehicle):
            if vehicle.platform == .taurus2023C2 { return .accepted(vehicle) }
            return .rejected("السيارة ليست تورس 2023 — المنصة: \(vehicle.platform.arabicName)")
        case .acceptedWarning(let vehicle, let warning):
            return .acceptedWarning(vehicle, warning)
        case .rejected(let reason):
            return .rejected(reason)
        }
    }

    enum ValidationResult: Equatable {
        case accepted(Vehicle)
        case acceptedWarning(Vehicle, String)  // مقبولة للفحص مع تحذير — لا كتابة
        case rejected(String)
    }
}
