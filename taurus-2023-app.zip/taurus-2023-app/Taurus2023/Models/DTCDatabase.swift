import Foundation

// MARK: - DTCDatabase
/// قاعدة بيانات أكواد الأعطال (DTC) — الوصف العربي لكل كود.
///
/// المصدر: Wal33D/dtc-database (https://github.com/Wal33D/dtc-database)
/// الترخيص: MIT — Copyright (c) 2024 Wal33D (انظر ملف LICENSE-Wal33D-MIT.txt
/// في مجلد العمل، ورأس ملف dtc_database.json).
/// المحتوى: 2,323 كوداً — 1,913 كوداً عاماً (GENERIC: P0/C0/B0/U0 حسب معيار
/// SAE J2012) + 410 أكواد خاصة بفورد (FORD: P1/B1/C1/U1).
/// الوصف الإنجليزي منسوخ حرفياً من المصدر (وتُحقّق منه آلياً حقلاً بحقل
/// قبل الحزم)؛ الوصف العربي ترجمة عرضية للوصف الموثق نفسه — ليست وصفاً
/// مخترعاً. الأسباب المحتملة غير موثقة في المصدر إطلاقاً، فلا تُعرض أسباب
/// لأي كود؛ الواجهة تقول ذلك صراحة بدل التخمين.
///
/// قواعد الاختيار (موثقة في FEATURES.md):
/// - GENERIC: P0000–P0899، وU0000–U0499 + U3000–U3019، وB0000–B0099،
///   وC0000–C0099، وP2096–P2499 (P2000–P2095 ديزل/NOx مستبعدة).
/// - FORD: كل الصفوف السليمة من ford_codes.txt (416 سطراً ناقص 3 صفوف
///   مدموجة التعريف P1106 وP1107 وP1443 و3 صفوف مكررة = 410).
/// - P1346: لا يوجد له صف فورد في المصدر إطلاقاً (له صفوف BMW/GM وغيرها
///   فقط) — فيُعرض في التطبيق «غير موثّق لفورد» ولا يُخترع له معنى.
///
/// الخطورة (قاعدة بيانات، موثقة في رأس الملف):
/// - حرج: أكواد الإيرباق (B00) والفرامل (C00) ووحدات التحكم (P06xx)
///   وضغط الزيت (P0520–P0524) وP0217 وP0219 وU0100 وU0121 وU0151 وU3000.
/// - معلومة: P1000 وP1111 فقط (P0000 في القاعدة كشبكة أمان رغم عدم وجوده
///   في قاعدة المصدر الحالية).
/// - مهم: كل ما عداهما.
/// الإجراء: قالب عام حسب النظام والخطورة — ليس إجراءً خاصاً بكود معين،
/// لأن المصدر لا يوثق إجراءات خاصة بالأكواد.

// MARK: - DTCEntry
/// سطر واحد في قاعدة البيانات — كما في ملف dtc_database.json.
struct DTCEntry: Decodable, Equatable {
    /// الكود مثل "P0171" أو "U3000".
    let code: String
    /// الوصف الإنجليزي الأصلي من المصدر (حرفي).
    let en: String
    /// الوصف العربي (ترجمة الوصف الموثق نفسه).
    let ar: String
    /// "GENERIC" أو "FORD".
    let mfr: String
    /// النظام: "مجموعة القوة" / "الجسم" / "الشاصي" / "الشبكة".
    let system: String
    /// الخطورة: "حرج" / "مهم" / "معلومة".
    let severity: String
    /// الإجراء المقترح (قالب عام حسب النظام والخطورة).
    let action: String

    /// هل الكود خاص بفورد؟ (تُفضَّل قراءته على العام عند التعارض).
    var isFordSpecific: Bool { mfr == "FORD" }

    /// هل الخطورة حرجة؟
    var isCritical: Bool { severity == "حرج" }

    /// هل مسح الكود آمن تقنياً؟ المسح (Mode 04) يمسح الكود المخزن فقط
    /// ولا يغير أي برمجة ولا يلمس PCM/TCM؛ لكن مسح كود حرج لا يصلح العطل
    /// وسيعود الكود إن لم يُصلح السبب — فالواجهة تعرض هذا التحذير.
    var clearAdvice: String {
        if isCritical {
            return "المسح آمن تقنياً (يمسح الكود فقط ولا يغير برمجة)، لكنه لا يصلح العطل — الكود سيعود إن لم يُصلح السبب. راجع الورشة أولاً."
        }
        return "آمن — المسح يمسح الكود المخزن فقط ولا يغير أي برمجة في السيارة."
    }
}

// MARK: - DTCDatabase
/// محمّل قاعدة البيانات — يُحمّل ملف dtc_database.json من الحزمة مرة واحدة.
final class DTCDatabase {
    static let shared = DTCDatabase()

    /// كل الإدخالات كما في الملف.
    private(set) var entries: [DTCEntry] = []
    /// خطأ التحميل إن وُجد (يُعرض في الواجهة بدل إخفائه).
    private(set) var loadError: String?

    /// عدد الأكواد في قاعدة البيانات (2,323).
    var count: Int { entries.count }
    /// عدد الأكواد العامة (1,913).
    var genericCount: Int { entries.filter { $0.mfr == "GENERIC" }.count }
    /// عدد أكواد فورد الخاصة (410).
    var fordCount: Int { entries.filter { $0.mfr == "FORD" }.count }

    private init() { load() }

    private func load() {
        guard let url = Bundle.main.url(forResource: "dtc_database", withExtension: "json") else {
            loadError = "ملف قاعدة الأعطال dtc_database.json غير موجود في الحزمة"
            return
        }
        do {
            let data = try Data(contentsOf: url)
            entries = try JSONDecoder().decode([DTCEntry].self, from: data)
        } catch {
            loadError = "تعذر تحميل قاعدة الأعطال: \(error.localizedDescription)"
        }
    }

    /// البحث عن كود — يُفضَّل الصف الخاص بفورد على العام عند وجودهما معاً.
    func entry(for code: String) -> DTCEntry? {
        let matches = entries.filter { $0.code == code }
        return matches.first(where: { $0.isFordSpecific }) ?? matches.first
    }

    /// هل الكود موثق في قاعدة البيانات؟
    func isDocumented(_ code: String) -> Bool { entry(for: code) != nil }

    /// وصف عربي للكود — أو رسالة «غير موثّق» الصريحة إن لم يكن في القاعدة.
    /// لا يُخترع وصف لأي كود: غير الموثق يُعرض ببنية الكود المعروفة فقط.
    func arabicDescription(for code: String) -> String {
        if let e = entry(for: code) { return e.ar }
        let system: String
        switch code.first {
        case "P": system = "مجموعة القوة"
        case "B": system = "الجسم"
        case "C": system = "الشاصي"
        case "U": system = "الشبكة"
        default: system = "غير معروف"
        }
        return "غير موثّق — بنية الكود معروفة فقط (نظام \(system)، الرقم \(code.dropFirst()))"
    }
}
