import Foundation
import Network
import CoreBluetooth

// MARK: - OBDConnection
/// حالة الاتصال بالقطعة.
enum OBDConnection: Equatable {
    case disconnected
    case connecting
    case connected(adapter: AdapterInfo)
    case failed(String)

    var isConnected: Bool {
        if case .connected = self { return true }
        return false
    }
}

/// معلومات القطعة المتصلة — تُعرض في التشخيص مع تحذير إن كانت غير موصى بها.
struct AdapterInfo: Equatable {
    let name: String           // مثال: "vLinker FS"
    let transport: Transport
    let isRecommended: Bool
    let warningAr: String?

    enum Transport: String {
        case wifi = "WiFi"
        case ble = "Bluetooth LE"
        case classic = "Bluetooth Classic"
    }

    /// القطع الموصى بها. ELM327 v1.5 الرخيص غير موصى به — FORScan نفسه يقول NOT recommended.
    static func info(for name: String, transport: Transport) -> AdapterInfo {
        let lower = name.lowercased()
        if lower.contains("vlinker") {
            return AdapterInfo(name: name, transport: transport, isRecommended: true, warningAr: nil)
        }
        if lower.contains("obdlink") {
            return AdapterInfo(name: name, transport: transport, isRecommended: true, warningAr: nil)
        }
        if lower.contains("elm327") && lower.contains("v1.5") {
            return AdapterInfo(name: name, transport: transport, isRecommended: false,
                               warningAr: "هذه القطعة غير موصى بها — FORScan يقول NOT recommended. بعض الوظائف قد تفشل. استبدلها بـ vLinker FS قبل أي كتابة.")
        }
        return AdapterInfo(name: name, transport: transport, isRecommended: false,
                           warningAr: "قطعة غير معروفة — تحقق من التوافق قبل أي كتابة.")
    }
}

// MARK: - OBDTransport
/// طبقة النقل المجردة — WiFi أو BLE. ELM327Service لا يعرف أي نقل يستخدم.
/// هذا يسهل اختبار المنطق بدون قطعة حقيقية (MockTransport في الاختبارات).
protocol OBDTransport: AnyObject {
    var isConnected: Bool { get }
    /// حجم كتلة الاستقبال بالبايت — الافتراضي 4096. عند خطأ BUFFER FULL يُنصَّف
    /// (نموذج FordScan) حتى يستقر الاستقبال على القطع البطيئة.
    var receiveBlockSize: Int { get set }
    func connect() async throws
    func disconnect()
    func send(_ data: Data) async throws -> Data
    func sendLine(_ line: String) async throws -> String
}

// MARK: - WiFiTransport
/// نقل WiFi لـ ELM327 WiFi — العنوان الافتراضي 192.168.0.10:35000 (الأكثر شيوعاً).
/// إذا كانت قطعتك على عنوان آخر، غيّره من الإعدادات قبل الاتصال.
final class WiFiTransport: OBDTransport {
    let host: String
    let port: UInt16
    private var connection: NWConnection?
    var isConnected: Bool { connection?.state == .ready }
    var receiveBlockSize = 4096

    init(host: String = "192.168.0.10", port: UInt16 = 35000) {
        self.host = host; self.port = port
    }

    func connect() async throws {
        let connection = NWConnection(host: NWEndpoint.Host(host), port: NWEndpoint.Port(rawValue: port)!, using: .tcp)
        self.connection = connection
        connection.start(queue: .global())
        // انتظار بسيط حتى يصبح الاتصال جاهزاً (مهلة 5 ثوانٍ).
        try await Task.sleep(nanoseconds: 2_000_000_000)
        guard isConnected else { throw OBDTransportError.connectionFailed }
    }

    func disconnect() { connection?.cancel(); connection = nil }

    func send(_ data: Data) async throws -> Data {
        guard let connection else { throw OBDTransportError.notConnected }
        return try await withCheckedThrowingContinuation { cont in
            connection.send(content: data, completion: .contentProcessed { error in
                if let error { cont.resume(throwing: error); return }
                connection.receive(minimumIncompleteLength: 1, maximumLength: receiveBlockSize) { data, _, _, error in
                    if let error { cont.resume(throwing: error); return }
                    cont.resume(returning: data ?? Data())
                }
            })
        }
    }

    func sendLine(_ line: String) async throws -> String {
        let data = try await send(Data((line + "\r").utf8))
        return String(data: data, encoding: .utf8) ?? ""
    }
}

// MARK: - BLETransport (skeleton — CoreBluetooth)
/// نقل BLE لـ vLinker FS / OBDLink MX+.
/// ملاحظة: أسماء الخدمات والخصائص تختلف بين القطع. هذا الهيكل يفحص الأجهزة
/// التي تعلن خدمة ELM327، ويُكمل التفاصيل بعد اختبار القطعة الفعلية.
/// لا تُخترع UUIDs هنا — تُقرأ من القطعة عند الفحص الأول.
final class BLETransport: NSObject, OBDTransport, CBCentralManagerDelegate, CBPeripheralDelegate {
    private var central: CBCentralManager?
    private var peripheral: CBPeripheral?
    var isConnected: Bool { peripheral?.state == .connected }
    /// مخزّن فقط — هيكل BLE لم يُنفذ بعد، فلا يُستخدم في الاستقبال.
    var receiveBlockSize = 4096

    func connect() async throws {
        // يُنفذ عبر CBCentralManager — يتطلب إذن Bluetooth في Info.plist.
        // التنفيذ الكامل في ELM327Service بعد اختبار القطعة الفعلية.
        throw OBDTransportError.notImplemented("اتصال BLE — أكمل التفاصيل بعد اختبار قطعة vLinker FS الفعلية")
    }
    func disconnect() {
        if let peripheral, let central { central.cancelPeripheralConnection(peripheral) }
    }
    func send(_ data: Data) async throws -> Data { throw OBDTransportError.notImplemented("BLE send") }
    func sendLine(_ line: String) async throws -> String { throw OBDTransportError.notImplemented("BLE sendLine") }

    // MARK: CBCentralManagerDelegate (حد أدنى — لا منطق وهمي)
    func centralManagerDidUpdateState(_ central: CBCentralManager) { self.central = central }
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String: Any], rssi RSSI: NSNumber) {}
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) { self.peripheral = peripheral }
}

enum OBDTransportError: Error, LocalizedError {
    case notConnected
    case connectionFailed
    case notImplemented(String)
    var errorDescription: String? {
        switch self {
        case .notConnected: return "غير متصل بالقطعة"
        case .connectionFailed: return "فشل الاتصال بالقطعة — تحقق من WiFi / Bluetooth والعنوان"
        case .notImplemented(let what): return "غير منفذ بعد: \(what) — يحتاج اختبار القطعة الفعلية"
        }
    }
}
