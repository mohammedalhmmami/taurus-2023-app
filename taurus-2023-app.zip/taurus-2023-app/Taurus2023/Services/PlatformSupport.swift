import Foundation

// MARK: - PlatformSupport
/// ربط كل ميزة بالمنصات الموثقة لها فعلاً — انظر FEATURES.md.
/// القاعدة الملزمة: لا يُنسخ كود من منصة إلى أخرى أبداً.
/// الميزة تُعرض قابلة للكتابة لمنصة ما فقط إذا كان مصدرها موثقاً لتلك المنصة.
/// لمنصة غير معروفة: لا ميزة قابلة للكتابة إطلاقاً — فحص قراءة فقط.
///
/// ملخص المصادر (بدون أي قيمة جديدة مخترعة):
///  - ميزتا APIM ‏(3 عمر الزيت، 12 ثيم Unreal)‏: قيم SYNC 4 العامة 7D0،
///    الأكثر قابلية للنقل بين سيارات SYNC 4 — لكنها تبقى مشروطة بقراءة
///    القيمة الحالية وتعديل بت واحد فقط + تحقق بإعادة القراءة + إصدار SYNC.
///  - ‏(4 البوري)‏: مؤكد لـ F-150 / Bronco / Ranger بالعنوان 726-41-02.
///    تنبيه: البحث العميق وجد أن F-150 موديل 2021+ يستخدم 726-63-02 بدلاً منه —
///    انظر FEATURES.md §4. التطبيق يقرأ العنوان الموجود في الـ dump أولاً.
///  - ‏(10 Bambi)‏: مؤكد لـ F-150 / Bronco كإعداد نصي.
///  - ‏(13 الأوتو ستارت ستوب)‏: مؤكد لـ F-150 / Ranger بالعنوان 726-48-02.
///  - ‏(17 الحزام)‏: طريقتان مختلفتان حسب الجيل — F-150 القديم (720-01-01)
///    و Maverick/Bronco الحديث (720-13/14). المنصة تحدد الطريقة.
///  - ‏(7 القفل عند الابتعاد)‏: بلا عنوان As-Built موثوق لأي منصة — معطل للجميع.
///  - باقي المزايا: غير مؤكدة لأي منصة — معطلة للجميع حتى يوجد مصدر موثوق.
enum PlatformSupport {

    /// المنصات الموثقة لهذه الميزة (حسب رقمها 1...18).
    /// قائمة فارغة = غير موثقة لأي منصة = قراءة وعرض فقط.
    static func writablePlatforms(for featureId: Int) -> Set<FordPlatform> {
        switch featureId {
        case 3, 12:
            // APIM SYNC 4 عام (7D0-10-01 و 7D0-02-03) — كل منصات SYNC 4.
            return [.taurus2023C2, .f150Gen14, .bronco, .ranger, .maverick, .mustang, .explorer, .focusMk4C2]
        case 4:
            // Double Honk — Ranger5G + FORScan Forum.
            return [.f150Gen14, .bronco, .ranger]
        case 10:
            // Bambi Mode — GarageSee + Oregon Programming.
            return [.f150Gen14, .bronco]
        case 13:
            // Auto Start-Stop 726-48-02 — Ranger5G + FORScan Forum + Livnitup.
            return [.f150Gen14, .ranger]
        case 17:
            // Seatbelt — طريقتان حسب الجيل.
            return [.f150Gen14, .maverick, .bronco]
        default:
            return []
        }
    }

    /// هل هذه الميزة قابلة للكتابة على منصة هذه السيارة؟
    /// ثلاثة شروط مجتمعة: الميزة نفسها قابلة للكتابة + المنصة موثقة لها +
    /// المنصة معروفة (ليست .unknown). أي شرط فاشل = معطلة مع سبب واضح.
    static func isFeatureWritable(feature: Feature, platform: FordPlatform) -> Bool {
        guard platform != .unknown else { return false }
        guard feature.isWritable else { return false }
        return writablePlatforms(for: feature.id).contains(platform)
    }

    /// سبب التعطيل — يُعرض في الواجهة بدلاً من زر صامت.
    static func disabledReason(feature: Feature, platform: FordPlatform) -> String {
        if platform == .unknown {
            return "منصة السيارة غير معروفة من VIN وحده — تُؤكَّد من قراءة الوحدات أولاً، وحتى ذلك الحين فحص قراءة فقط."
        }
        if !feature.isWritable {
            return "غير مؤكد — يحتاج قراءة As-Built الفعلي من السيارة قبل الكتابة."
        }
        if !writablePlatforms(for: feature.id).contains(platform) {
            return "هذه الميزة موثقة لمنصات أخرى وليست موثقة لمنصة \(platform.arabicName) — لا يُنسخ كود من منصة إلى أخرى."
        }
        return "غير قابلة للكتابة على هذه المنصة."
    }

    /// ملاحظة المنصة — تُعرض في الرئيسية بعد التعرف على السيارة.
    static func platformNote(for platform: FordPlatform, confidence: PlatformConfidence) -> String {
        switch (platform, confidence) {
        case (.unknown, _):
            return "تعذر تحديد موديل السيارة بدقة من رقم الشاصي وحده. التطبيق يعرض الفحص فقط، وتُؤكَّد المنصة من قراءة الوحدات (أرقام قطع APIM/BdyCM)."
        case (_, .probable):
            return "المنصة مستدل عليها من رقم الشاصي (مرجحة). تُؤكَّد نهائياً من قراءة الوحدات قبل أي كتابة."
        default:
            return ""
        }
    }
}
