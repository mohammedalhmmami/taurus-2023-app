import Foundation

// MARK: - BackupSet
/// نسخة احتياطية كاملة — كل أسطر As-Built قبل أول تغيير.
/// تُحفظ محلياً على الآيفون فقط (UserDefaults / ملف)، ولا تُرسل لأي خادم.
struct BackupSet: Codable {
    let vin: String
    let date: Date
    let lines: [BackupLine]

    struct BackupLine: Codable {
        let address: String
        let blocks: [String]
    }

    init(vin: String, date: Date, lines: [AsBuiltLine]) {
        self.vin = vin
        self.date = date
        self.lines = lines.map { BackupLine(address: $0.address, blocks: $0.blocks) }
    }
}

// MARK: - BackupStore
/// حفظ واسترجاع النسخ الاحتياطية — محلياً فقط.
final class BackupStore {
    private let key = "taurus2023.backup.latest"
    private let defaults = UserDefaults.standard

    func save(_ set: BackupSet) throws {
        let data = try JSONEncoder().encode(set)
        defaults.set(data, forKey: key)
    }

    func loadLatest() -> BackupSet? {
        guard let data = defaults.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(BackupSet.self, from: data)
    }

    func hasBackup() -> Bool { loadLatest() != nil }
}
