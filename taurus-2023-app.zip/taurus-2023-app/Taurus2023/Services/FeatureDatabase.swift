import Foundation

// MARK: - FeatureDatabase
/// قاعدة بيانات المزايا الـ18.
/// القاعدة الوحيدة للكتابة: كل ميزة هنا لها مصدر مذكور في FEATURES.md.
/// أي ميزة بلا مصدر موثوق واضح مصنفة `unverified` ولا تُكتب أبداً.
///
/// التعارضات المسجلة (لا تختار واحدة عشوائياً — انظر FEATURES.md):
///  1. APIM 7D0-02-02: قيم 2 و 3 و 6 و 7 ظهرت لنفس العنوان (شريط تكييف / Powerflow / Blackbox).
///     الحل: قراءة القيمة الحالية وتعديل بت شريط التكييف فقط.
///  2. APIM 7D0-03-01: 5753 يفعّل الملاحة أثناء الحركة لكنه يحذف دليل المالك ويعطل مساعد فورد.
///  3. IPC 720-01-01: قيم مختلفة تماماً بين السنوات والموديلات، بما فيها قيم تورس 2015.
///     لا يُستخدم أي سطر كامل من مصدر آخر — تعديل بت واحد فقط على السطر الحالي.
final class FeatureDatabase {

    // MARK: - All 18 features
    /// القائمة الكاملة. `isEnabled` الافتراضي false — الحالة الحقيقية تُقرأ من السيارة.
    static func allFeatures() -> [Feature] {
        [
            // 1 — تقوية السماعات: غير مؤكد. مصادر ACM EQ متعارضة ولا تنطبق على تورس 2023.
            // المصدر: Mustang6G FORScan EQ + Bronco6G Audio Mods — انظر FEATURES.md §1.
            Feature(id: 1, titleAr: "تقوية سماعات التورس",
                    descriptionAr: "تعديل معالجة الصوت في ACM. لا يوجد عنوان موثوق لتورس 2023 — المصادر المتوفرة (727-01-02 EQ Flat) متعارضة في الأثر ولا تنطبق مباشرة على SYNC 4.",
                    module: .acm, change: .noneUnverified,
                    status: .unverified(reason: "لم يوجد مصدر موثوق يربط «تقوية سماعات تورس 2023» بعنوان وقيمة محددين. مصادر ACM EQ (727-01-02) من Mustang/Bronco متعارضة في الأثر السمعي."),
                    source: "Mustang6G FORScan EQ + Bronco6G Audio Mods — انظر FEATURES.md §1",
                    conditionAr: "نظام 6 سماعات (غير B&O) — يختلف عن B&O", warningAr: nil),

            // 2 — النمط الصامت: غير مؤكد — الوصف غامض بلا مقابل موثق.
            Feature(id: 2, titleAr: "النمط الصامت",
                    descriptionAr: "وصف تجاري من المبرمج بلا مقابل موثق في جداول FORScan. هل هو كتم التنبيهات؟ أم وضع Valet؟ أم إيقاف الصوت الاصطناعي؟ كل تفسير له عنوان مختلف.",
                    module: .apim, change: .noneUnverified,
                    status: .unverified(reason: "لم يوجد مصدر موثوق. يحتاج تحديد المقصود بدقة قبل أي بحث إضافي."),
                    source: "لا يوجد — انظر FEATURES.md §2",
                    conditionAr: nil, warningAr: nil),

            // 3 — عمر الزيت: مؤكد (الإظهار). APIM 7D0-10-01 x8xx — Livnitup + F150Gen14 Primer.
            // النبل: 8 = Oil Life Enabled. تعديل بت واحد فقط مع الحفاظ على بقية البتات.
            // إلغاء تنبيه الزيت كعنوان منفصل: غير مؤكد.
            Feature(id: 3, titleAr: "إضافة عمر الزيت بالشاشة + إلغاء تنبيه الزيت",
                    descriptionAr: "إظهار عمر الزيت في الإعدادات ← المركبة. العنوان مؤكد. إلغاء تنبيه الزيت كعنوان منفصل غير مؤكد — الإظهار لا يلغي التنبيه تلقائياً.",
                    module: .apim,
                    // بت واحد فقط: القيمة 8 = 1000 ثنائي = بت Oil Life. يُدمج مع البتات الحالية بـ OR
                    // (مثال: النبل الحالي 1 يصبح 9، لا 8) — لا تُستبدل القيمة كاملة.
                    change: .bitChange(address: "7D0-10-01", blockIndex: 0, nibbleIndex: 1, bit: 3),
                    status: .verified,
                    source: "Livnitup 2021-24 F-150 Common + F150Gen14 Primer (8 = OL Enabled) — FEATURES.md §3",
                    conditionAr: "SYNC 4", warningAr: "بعض المستخدمين أبلغوا أن عمر الزيت لم يعمل حتى تحديث SYNC 3.5.3 — تحقق بعد الكتابة."),

            // 4 — البوري عند النزول: مؤكد جزئياً. BdyCM 726-41-02 xxx0 — Ranger5G + FORScan Forum.
            // مؤكد لـ F-150/Bronco، غير مؤكد مباشرة لتورس 2023 Mondeo.
            Feature(id: 4, titleAr: "إلغاء صوت البوري عند النزول",
                    descriptionAr: "إلغاء Double Honk عند إغلاق الباب والمحرك يعمل. العنوان مؤكد لمنصة أخرى، ويحتاج تحققاً من BdyCM الفعلي لتورس 2023.",
                    module: .bdyCM,
                    change: .nibbleChange(address: "726-41-02", blockIndex: 0, nibbleIndex: 3, onNibble: "0", offNibble: "1"),
                    status: .partiallyVerified(conflict: "العنوان 726-41-02 مؤكد لـ F-150 / Bronco / Ranger (Ranger5G + FORScan Forum). لا يوجد مصدر مباشر لتورس 2023 Mondeo — عناوين BdyCM تختلف بين المنصات."),
                    source: "Ranger5G Wiki + FORScan Forum 2022 Super Duty — FEATURES.md §4",
                    conditionAr: nil, warningAr: nil),

            // 5 — إعدادات التشغيل عن بعد في الشاشة: غير مؤكد.
            Feature(id: 5, titleAr: "تفعيل إعدادات التشغيل عن بعد في الشاشة",
                    descriptionAr: "لم يوجد عنوان As-Built موثوق لتورس 2023. في كثير من سيارات Mondeo تظهر الإعدادات في قائمة SYNC نفسها إذا كان الهاردوير موجوداً.",
                    module: .apim, change: .noneUnverified,
                    status: .unverified(reason: "لم يوجد مصدر موثوق لعنوان As-Built لتورس 2023."),
                    source: "لا يوجد — انظر FEATURES.md §5",
                    conditionAr: "يحتاج هاردوير التشغيل عن بعد (ريموت + وحدة استقبال)", warningAr: nil),

            // 6 — مفتاح التشغيل عن بعد: هاردوير — التطبيق لا يصنع مفتاحاً.
            Feature(id: 6, titleAr: "إعدادات مفتاح التشغيل عن بعد",
                    descriptionAr: "المفتاح الفيزيائي نفسه قطعة تُشترى (150 ريال حسب قائمة المبرمج) وتُبرمج PATS عند مختص. التطبيق يفعّل الإعدادات في الشاشة فقط (الميزة 5) ولا يصنع مفتاحاً ولا يعطي ضماناً.",
                    module: .bdyCM, change: .noneUnverified,
                    status: .unverified(reason: "المفتاح الفيزيائي وبرمجة PATS خارج التطبيق. لا يوجد كود يصنع مفتاحاً."),
                    source: "قائمة المبرمج (150 ريال + ضمان سنة) — FEATURES.md §6",
                    conditionAr: "يحتاج مفتاحاً فيزيائياً + برمجة PATS عند مختص", warningAr: nil),

            // 7 — قفل تلقائي عند الابتعاد: مؤكد جزئياً كإعداد، غير مؤكد كعنوان As-Built.
            Feature(id: 7, titleAr: "قفل تلقائي عند النزول والابتعاد",
                    descriptionAr: "Autolock يظهر كإعداد في بعض موديلات Mondeo Mk5. لا يوجد عنوان As-Built موثوق لتورس 2023. «القفل عند الابتعاد» يختلف عن Autolock عند السرعة.",
                    module: .bdyCM, change: .noneUnverified,
                    status: .partiallyVerified(conflict: "Autolock موجود كإعداد في FORScan Configuration لبعض موديلات Mondeo Mk5 (Otoideal + Mondeo Forum)، لكن لا يوجد عنوان As-Built موثوق لتورس 2023."),
                    source: "Otoideal Mondeo Mk5 + Mondeo Mk5 Forum — FEATURES.md §7",
                    conditionAr: nil, warningAr: nil),

            // 8 — لون الإشارة برتقالي→أحمر: غير مؤكد + هاردوير.
            Feature(id: 8, titleAr: "تغيير لون الإشارة الخلفية من برتقالي إلى أحمر",
                    descriptionAr: "لون الإشارة يحدده لون اللمبة فيزيائياً. إذا كانت اللمبة برتقالية كلون قطعة فلا كود يغير لون ضوئها إلى أحمر.",
                    module: .bdyCM, change: .noneUnverified,
                    status: .unverified(reason: "لم يوجد مصدر موثوق. يحتاج فحص نوع اللمبة (أحادية اللون أم ثنائية) + قراءة As-Built الفعلي."),
                    source: "لا يوجد — انظر FEATURES.md §8",
                    conditionAr: "يعتمد على نوع لمبة الإشارة الخلفية", warningAr: nil),

            // 9 — السكن البرتقالي: غير مؤكد.
            Feature(id: 9, titleAr: "السكن البرتقالي",
                    descriptionAr: "لم يوجد عنوان As-Built موثوق لتورس 2023. سعر خدمة المبرمج (80 ريال / 50 في البكج) ليس قيمة برمجية.",
                    module: .bdyCM, change: .noneUnverified,
                    status: .unverified(reason: "لم يوجد مصدر موثوق لعنوان As-Built لتورس 2023."),
                    source: "لا يوجد — انظر FEATURES.md §9",
                    conditionAr: nil, warningAr: nil),

            // 10 — تقوية النور العالي (Bambi): مؤكد جزئياً كإعداد نصي.
            // BdyCM Configuration: "Use front fog lights with high beam" Inhibited → Allowed.
            // لا يوجد عنوان As-Built موثوق لتورس 2023 — لا تكتب عنواناً تخمينياً.
            Feature(id: 10, titleAr: "تقوية النور العالي",
                    descriptionAr: "الاسم الدقيق: الكشافات مع العالي (Bambi Mode) — يُبقي كشافات الضباب مع العالي. لا «يقوّي» شدة النور نفسه كقيمة As-Built موثقة.",
                    module: .bdyCM,
                    change: .plainEnglishSetting(module: .bdyCM, settingName: "Use front fog lights with high beam", onValue: "Allowed", offValue: "Inhibited"),
                    status: .partiallyVerified(conflict: "الإعداد النصي مؤكد في GarageSee + Oregon Programming، لكن لا يوجد عنوان As-Built موثوق لتورس 2023. يُستخدم مسار Configuration فقط."),
                    source: "GarageSee Bambi Mode + Oregon Vehicle Programming — FEATURES.md §10",
                    conditionAr: "يحتاج كشافات ضباب أمامية", warningAr: "في بعض الدول يُمنع تشغيل أكثر من 4 أنوار أمامية معاً — تحقق من نظام المرور السعودي."),

            // 11 — تضعيف السكن/النعاس + إطفاء النور كاملاً: غير مؤكد.
            Feature(id: 11, titleAr: "تضعيف السكن / النعاس + إطفاء النور كاملاً",
                    descriptionAr: "لم يوجد عنوان As-Built موثوق لتورس 2023 يضعّف السكن أو يطفئ النور كاملاً.",
                    module: .bdyCM, change: .noneUnverified,
                    status: .unverified(reason: "لم يوجد مصدر موثوق."),
                    source: "لا يوجد — انظر FEATURES.md §11",
                    conditionAr: nil, warningAr: "إطفاء النور كاملاً أثناء القيادة غير آمن وقد يكون غير قانوني — التطبيق يمنع التفعيل أثناء القيادة."),

            // 12 — وضع الشاشة النهاري: مؤكد جزئياً (Unreal مؤكد، VDV متعارض).
            // Unreal: APIM 7D0-02-03 xxxx xxx1 — يتطلب SYNC 22012+.
            // VDV: APIM 7D0-03-01 xxxx xxxx **-- (05=Lincoln 13.2"، 06=Ford 13.2") — لا تُكتب تخميناً.
            Feature(id: 12, titleAr: "تغيير وضع الشاشة إلى النهاري مع التحكم بين الأنماط",
                    descriptionAr: "تفعيل ثيم Unreal يفتح التحكم بين الأنماط من الشاشة. قيم VDV تختلف بين الموديلات — تُقرأ ولا تُكتب تخميناً.",
                    module: .apim,
                    // بت واحد فقط: xxx1 = بت Unreal. يُدمج مع البتات الحالية، لا يستبدل النبل كاملاً.
                    change: .bitChange(address: "7D0-02-03", blockIndex: 1, nibbleIndex: 3, bit: 0),
                    status: .verified,
                    source: "Livnitup + MaverickTruckClub (Unreal 7D0-02-03 xxxx xxx1) + Bronco sheet VDV 05/06 — FEATURES.md §12",
                    conditionAr: "SYNC 4 إصدار 22012 أو أعلى", warningAr: "بعد الكتابة: إعادة ضبط APIM (زر الطاقة + التقديم 10 ثوانٍ)."),

            // 13 — الأوتو ستارت ستوب: مؤكد النمط، غير مؤكد العنوان لتورس 2023 تحديداً.
            // BdyCM 726-48-02 x0xx — Ranger5G + FORScan Forum + Livnitup (F-150/Ranger).
            // لا يمس PCM ولا TCM أبداً.
            Feature(id: 13, titleAr: "إلغاء الأوتو ستارت ستوب",
                    descriptionAr: "تعطيل نظام إدارة البطارية BMS عبر BdyCM. لا يمس المحرك ولا القير. دليل سلبي: موضوع في منتدى FORScan (2023-10-29) عن تورس 2023 — المستخدم لم يجد بلوك BCM 726-48-02 في سيارته إطلاقاً. البديل الموثق بالفيديو فصل موصّل حساس البطارية — معلومة فقط، وليس إجراءً داخل التطبيق.",
                    module: .bdyCM,
                    change: .nibbleChange(address: "726-48-02", blockIndex: 0, nibbleIndex: 1, onNibble: "0", offNibble: "1"),
                    status: .partiallyVerified(conflict: "العنوان 726-48-02 x0xx مؤكد في Ranger5G + FORScan Forum + Livnitup لـ F-150/Ranger/Super Duty، لكن لا يوجد مصدر مباشر لتورس 2023 Mondeo — بل دليل سلبي: مستخدم تورس 2023 لم يجد البلوك في سيارته إطلاقاً (منتدى FORScan 2023-10-29). يُقرأ السطر الحالي أولاً وإذا لم يكن x1xx يُرفض الكتابة. البديل الموثق بالفيديو (فصل موصّل حساس البطارية) معلومة فقط لا إجراء داخل التطبيق."),
                    source: "Ranger5G Wiki + FORScan Forum + Livnitup — FEATURES.md §13",
                    conditionAr: nil, warningAr: nil),

            // 14 — سرعة الشارع (TSR): غير مؤكد + كاميرا.
            Feature(id: 14, titleAr: "قراءة عداد الطبلون لسرعة الشارع",
                    descriptionAr: "تتطلب كاميرا التعرف على الإشارات (IPMA). الميزات التي تحتاج كاميرا لا تُبرمج — المصدر 10 صريح في ذلك.",
                    module: .ipc, change: .noneUnverified,
                    status: .unverified(reason: "لم يوجد عنوان IPC/IPMA موثوق لتورس 2023. يحتاج كاميرا IPMA مثبتة."),
                    source: "Otoideal: Features needing a camera cannot be coded in — FEATURES.md §14",
                    conditionAr: "يحتاج كاميرا التعرف على الإشارات (IPMA)", warningAr: nil),

            // 15 — علامة الجنط إلى brake: غير مؤكد.
            Feature(id: 15, titleAr: "تغيير علامة الجنط إلى كلمة brake",
                    descriptionAr: "لم يوجد مصدر يربط أيقونة TPMS في IPC لتورس 2023 بكلمة «brake». عنوان BdyCM 726-40-01 يتعلق بضغط الإطارات PSI وليس بالأيقونة.",
                    module: .ipc, change: .noneUnverified,
                    status: .unverified(reason: "لم يوجد مصدر موثوق."),
                    source: "لا يوجد — انظر FEATURES.md §15",
                    conditionAr: nil, warningAr: nil),

            // 16 — اللبد أوف وايت: غير مؤكد + فئة تيتانيوم فقط.
            Feature(id: 16, titleAr: "اللبد الداخلي أوف وايت + ألوان إضافية",
                    descriptionAr: "الإضاءة المحيطية موجودة كقائمة في إعدادات SYNC، لكن لا يوجد عنوان As-Built موثوق. الفئات الأدنى لا تحتوي الهاردوير.",
                    module: .bdyCM, change: .noneUnverified,
                    status: .unverified(reason: "لم يوجد عنوان As-Built موثوق. الشرط من قائمة المبرمج نفسه: تيتانيوم فقط."),
                    source: "Ford Jordan Taurus SYNC 4 Help (قائمة ambient lighting بلا عنوان) — FEATURES.md §16",
                    conditionAr: "فئة تيتانيوم فقط", warningAr: nil),

            // 17 — صوت الحزام: تعارض مسجل — لا تكتب القيمة القديمة عمياء.
            // IPC 720-01-01 xxxx xx0x في جداول قديمة، لكن SYNC 4 الحديث يستخدم IPC Configuration
            // (Seatbelt Warning Market USA→Europe / Belt Monitor Chime Enabled→Disabled) ويغير
            // عدة متغيرات في 720-01-01 و 720-01-02. انظر FEATURES.md §17.
            Feature(id: 17, titleAr: "إلغاء صوت الحزام",
                    descriptionAr: "تعارض مسجل: القيمة القديمة xx0x لموديلات قديمة، وSYNC 4 الحديث يستخدم IPC Configuration ويغير سطرين. لا تُكتب القيمة القديمة عمياء.",
                    module: .ipc,
                    change: .plainEnglishSetting(module: .ipc, settingName: "Belt Monitor Chime", onValue: "Disabled", offValue: "Enabled"),
                    status: .partiallyVerified(conflict: "قيم 0/2/4/6 موثقة لموديلات قديمة (2005 F-150). مصادر SYNC 4 الحديثة (Mach-E/Bronco) تقول إن التعطيل عبر IPC Configuration ويغير 720-01-01 و 720-01-02 معاً. يُستخدم مسار Configuration إن توفر."),
                    source: "FORScan Forum + F150Gen14 Seatbelt + Mach-E Forum — FEATURES.md §17",
                    conditionAr: nil, warningAr: "إلغاء صوت الحزام لا يلغي أهمية الحزام — تحذير سلامة قبل التفعيل."),

            // 18 — تكبيس العالي والواطي وأنت مسكن: غير مؤكد.
            Feature(id: 18, titleAr: "تكبيس العالي والواطي وأنت مسكن",
                    descriptionAr: "لم يوجد عنوان As-Built موثوق لتورس 2023. مرتبط وظيفياً بـ Bambi Mode (الميزة 10) لكن كوظيفة مستقلة لم توثق.",
                    module: .bdyCM, change: .noneUnverified,
                    status: .unverified(reason: "لم يوجد مصدر موثوق."),
                    source: "لا يوجد — انظر FEATURES.md §18",
                    conditionAr: nil, warningAr: nil),
        ]
    }

    // MARK: - Apply (read-modify-write)
    /// تطبيق ميزة: يقرأ السطر الحالي أولاً، ثم يعدّل البت المطلوب فقط.
    /// - Returns: السطر الجديد، أو nil إذا كانت الميزة غير قابلة للكتابة.
    /// هذه الدالة لا تكتب في السيارة بنفسها — الكتابة تتم في SafetyService بعد كل الفحوصات.
    static func newLine(for feature: Feature, enable: Bool, current: AsBuiltLine) -> AsBuiltLine? {
        switch feature.change {
        case .nibbleChange(let address, let blockIndex, let nibbleIndex, let onNibble, let offNibble):
            // حارس العنوان: لا يُطبَّق التغيير إلا على السطر المقصود نفسه —
            // سطر آخر بعنوان مختلف يعني أن البلوك غير موجود أو مختلف في هذه السيارة
            // (كما حدث مع 726-48-02 في تورس 2023: البلوك غير موجود أصلاً).
            guard current.address == address else { return nil }
            // استبدال النبل كاملاً — صحيح هنا فقط لأن المصدر يعرّف النبل كاملاً
            // كقيمة الإعداد نفسه (مثال: 726-41-02 xxx0/xxx1 و 726-48-02 x0xx/x1xx).
            // للبتات المركبة (عمر الزيت، Unreal) لا تُستخدم هذه الحالة إطلاقاً،
            // بل bitChange الذي يدمج البت مع البتات الحالية بـ OR.
            let target = enable ? onNibble : offNibble
            return current.withNibbleChanged(blockIndex: blockIndex, nibbleIndex: nibbleIndex, newNibble: target)
        case .bitChange(let address, let blockIndex, let nibbleIndex, let bit):
            guard current.address == address else { return nil }
            var line = current
            let block = Array(line.blocks[blockIndex])
            let currentNibble = block[nibbleIndex]
            let newNibble: Character = enable
                ? NibbleBit.setBit(currentNibble, bit: bit)
                : NibbleBit.clearBit(currentNibble, bit: bit)
            line = line.withNibbleChanged(blockIndex: blockIndex, nibbleIndex: nibbleIndex, newNibble: newNibble)
            return line
        case .plainEnglishSetting, .noneUnverified:
            // الإعدادات النصية تُنفذ عبر مسار Configuration في FORScan، وليس عبر سطر As-Built مباشر.
            // والميزات غير المؤكدة لا تُكتب أبداً — ترجع nil.
            return nil
        }
    }
}
