import Foundation

// MARK: - DTCMode
/// نوع قراءة الأعطال — Mode 03 مؤكدة، Mode 07 معلّقة، Mode 0A دائمة.
enum DTCMode: String {
    case confirmed = "03"   // Stored / Confirmed — أعطال مؤكدة
    case pending = "07"     // Pending — أعطال معلّقة (ظهرت مرة ولم تُؤكَّد)
    case permanent = "0A"   // Permanent — أعطال دائمة (لا تُمسح إلا بعد الإصلاح)

    /// بايت الرد الإيجابي: Mode + 0x40.
    var responseByte: UInt8 {
        switch self {
        case .confirmed: return 0x43
        case .pending: return 0x47
        case .permanent: return 0x4A
        }
    }

    var nameAr: String {
        switch self {
        case .confirmed: return "مؤكدة"
        case .pending: return "معلّقة"
        case .permanent: return "دائمة"
        }
    }
}

// MARK: - DecodedDTC
/// كود عطل مفكوك من رد خام — مع بايت نوع العطل (FTB) وبايت الحالة إن وُجدا.
struct DecodedDTC: Identifiable, Equatable {
    let id = UUID()
    /// الكود مثل "U3000" أو "P1346".
    let code: String
    /// نوع قراءته: مؤكدة / معلّقة / دائمة.
    let mode: DTCMode
    /// بايت نوع العطل (Failure Type Byte) — من صيغة FORScan "U3000:04-28".
    /// nil إن لم يكن في الرد (ردود Mode 03/07/0A العادية بلا FTB).
    let failureTypeByte: UInt8?
    /// بايت الحالة (Status byte) — من صيغة FORScan "U3000:04-28".
    let statusByte: UInt8?
    /// البايتان الخام للكود (للعرض والتحقق).
    let rawBytes: (UInt8, UInt8)

    static func == (lhs: DecodedDTC, rhs: DecodedDTC) -> Bool {
        lhs.code == rhs.code && lhs.mode == rhs.mode
            && lhs.failureTypeByte == rhs.failureTypeByte
            && lhs.statusByte == rhs.statusByte
    }

    /// العرض بأسلوب FORScan: "U3000:04-28" أو "P0133" إن لم يكن هناك FTB.
    var displayString: String {
        if let ftb = failureTypeByte, let st = statusByte {
            return "\(code):\(String(format: "%02X", ftb))-\(String(format: "%02X", st))"
        }
        if let ftb = failureTypeByte {
            return "\(code):\(String(format: "%02X", ftb))"
        }
        return code
    }

    /// وصف بايت نوع العطل بالعربية — حسب ISO 15031-6 / SAE J2012-DA.
    /// القيم 0x0A–0x0E محجوزة، و0x0F و0x10 غير موثقة، و0x1C فأعلى غير موثقة
    /// في المصادر المتاحة — فتُعرض «غير موثق» بدل التخمين.
    var failureTypeDescription: String? {
        guard let ftb = failureTypeByte else { return nil }
        return Self.failureTypeDescription(for: ftb)
    }

    static func failureTypeDescription(for ftb: UInt8) -> String {
        switch ftb {
        case 0x00: return "لا معلومات عن النوع الفرعي"
        case 0x01: return "عطل كهربائي عام"
        case 0x02: return "عطل إشارة عام"
        case 0x03: return "عطل في التضمين الترددي/عرض النبضة (FM/PWM)"
        case 0x04: return "عطل داخلي في النظام"
        case 0x05: return "عطل في برمجة النظام"
        case 0x06: return "عطل في الخوارزمية"
        case 0x07: return "عطل ميكانيكي"
        case 0x08: return "عطل في إشارة/رسالة الناقل"
        case 0x09: return "عطل في المكوّن"
        case 0x0A...0x0E: return "محجوز (ISO/SAE)"
        case 0x11: return "قصر الدائرة إلى الأرضي"
        case 0x12: return "قصر الدائرة إلى البطارية"
        case 0x13: return "الدائرة مفتوحة"
        case 0x14: return "قصر الدائرة إلى الأرضي أو مفتوحة"
        case 0x15: return "قصر الدائرة إلى البطارية أو مفتوحة"
        case 0x16: return "جهد الدائرة أقل من الحد"
        case 0x17: return "جهد الدائرة أعلى من الحد"
        case 0x18: return "تيار الدائرة أقل من الحد"
        case 0x19: return "تيار الدائرة أعلى من الحد"
        case 0x1A: return "مقاومة الدائرة أقل من الحد"
        case 0x1B: return "مقاومة الدائرة أعلى من الحد"
        default: return "نوع عطل غير موثق (0x\(String(format: "%02X", ftb)))"
        }
    }

    /// أوصاف بتات بايت الحالة — حسب ISO 14229-1:2020.
    /// بت 0 testFailed، بت 1 testFailedThisOperationCycle، بت 2 pending،
    /// بت 3 confirmed، بت 4 testNotCompletedSinceLastClear،
    /// بت 5 testFailedSinceLastClear، بت 6 testNotCompletedThisOperationCycle،
    /// بت 7 warningIndicatorRequested.
    var statusDescriptions: [String] {
        guard let st = statusByte else { return [] }
        var out: [String] = []
        if st & 0x01 != 0 { out.append("الاختبار فشل") }
        if st & 0x02 != 0 { out.append("فشل في دورة التشغيل الحالية") }
        if st & 0x04 != 0 { out.append("معلّق (لم يُؤكَّد بعد)") }
        if st & 0x08 != 0 { out.append("مؤكد") }
        if st & 0x10 != 0 { out.append("الاختبار لم يكتمل منذ آخر مسح") }
        if st & 0x20 != 0 { out.append("فشل منذ آخر مسح") }
        if st & 0x40 != 0 { out.append("الاختبار لم يكتمل في هذه الدورة") }
        if st & 0x80 != 0 { out.append("طُلب إضاءة مؤشر التحذير") }
        return out
    }
}

// MARK: - SmartModuleDTCs
/// نتيجة قراءة الأعطال من وحدة واحدة (الأنواع الثلاثة معاً).
struct SmartModuleDTCs: Identifiable {
    let id = UUID()
    let module: Module
    /// هل ردت الوحدة أصلاً؟ false تعني «لا ترد» — لا تُخترع لها أعطال.
    var responded: Bool
    var confirmed: [DecodedDTC] = []
    var pending: [DecodedDTC] = []
    var permanent: [DecodedDTC] = []
    /// نص الخطأ إن لم ترد الوحدة (يُعرض كما هو).
    var errorText: String?

    var all: [DecodedDTC] { confirmed + pending + permanent }
    var count: Int { all.count }
    var criticalCount: Int {
        all.filter { DTCDatabase.shared.entry(for: $0.code)?.isCritical == true }.count
    }
}

// MARK: - DTCDecoder
/// فك ترميز استجابات الأعطال — SAE J2012.
///
/// كل كود بايتان:
/// - البتّان الأعلى من البايت الأول يحددان الحرف: 00=P، 01=C، 10=B، 11=U.
/// - البتّان التاليان: الرقم الأول؛ والنبل الأدنى: الرقم الثاني.
/// - البايت الثاني: نبلاه هما الرقمان الثالث والرابع.
/// أمثلة موثقة (تُختبر في DTCDecoderTests أسفل الملف):
/// - U3000 = F0 00، وP1346 = 13 46، وU0159 = C1 59، وP0171 = 01 71.
/// رد Mode 03: "43" ثم أزواج الأكواد؛ الزوج 00 00 حشو ويُتجاهل.
/// رد Mode 07: "47" ثم الأزواج. رد Mode 0A: "4A" ثم الأزواج.
/// الرد قد يحمل رؤوس CAN (ATH1) — يُبحث عن بايت الرد أولاً ثم تُقرأ الأزواج.
/// "NO DATA" تعني الوحدة لم ترد — تُرجع قائمة فارغة، والخدمة هي التي
/// تميّز «لا ترد» عن «ردت بلا أعطال» (انظر DiagnosticsService).
enum DTCDecoder {

    /// فك كود واحد من بايتين إلى نص SAE J2012.
    static func decodeCode(bytes: (UInt8, UInt8)) -> String {
        let (b1, b2) = bytes
        let letter: String
        switch b1 >> 6 {
        case 0: letter = "P"
        case 1: letter = "C"
        case 2: letter = "B"
        default: letter = "U"
        }
        let d1 = (b1 >> 4) & 0x03
        let d2 = b1 & 0x0F
        let d3 = b2 >> 4
        let d4 = b2 & 0x0F
        return "\(letter)\(d1)\(d2)\(d3)\(d4)"
    }

    /// فك رد Mode 03/07/0A كاملاً إلى أكواد.
    /// - Parameters:
    ///   - response: الرد الخام من القطعة (نص Hex، قد يحمل رؤوساً).
    ///   - mode: نوع القراءة (يحدد بايت الرد المتوقع والتصنيف).
    static func decodeResponse(_ response: String, mode: DTCMode) -> [DecodedDTC] {
        if response.contains("NO DATA") || response.contains("UNABLE") { return [] }
        let tokens = response.components(separatedBy: .whitespaces).filter { !$0.isEmpty }
        var bytes: [UInt8] = []
        for token in tokens where token.count == 2 {
            if let b = UInt8(token, radix: 16) { bytes.append(b) }
        }
        // ابحث عن بايت الرد (43/47/4A) — ما قبله رؤوس CAN تُتجاهل.
        guard let start = bytes.firstIndex(of: mode.responseByte) else { return [] }
        let payload = Array(bytes[(start + 1)...])
        var out: [DecodedDTC] = []
        var i = 0
        while i + 1 < payload.count {
            let b1 = payload[i], b2 = payload[i + 1]
            i += 2
            if b1 == 0x00 && b2 == 0x00 { continue } // حشو — ليس كوداً
            let code = decodeCode(bytes: (b1, b2))
            out.append(DecodedDTC(code: code, mode: mode, failureTypeByte: nil,
                                   statusByte: nil, rawBytes: (b1, b2)))
        }
        return out
    }

    /// فك صيغة FORScan "U3000:04-28" — كود + بايت نوع العطل + بايت الحالة.
    /// الصيغة: CODE:FTB-STATUS حيث FTB وSTATUS بايتان Hex.
    /// تُقبل أيضاً "U3000:04" (بلا حالة) و"U3000" (بلا FTB).
    static func parseFORScanStyle(_ text: String, mode: DTCMode = .confirmed) -> DecodedDTC? {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let parts = trimmed.split(separator: ":", maxSplits: 1).map(String.init)
        guard let codePart = parts.first, codePart.count == 5,
              let first = codePart.first, "PCBU".contains(first),
              codePart.dropFirst().allSatisfy({ $0.isNumber }) else { return nil }
        // تحقق أن البايتين يعيدان إنتاج الكود نفسه (منعاً لقبول نص خاطئ).
        guard let (b1, b2) = bytes(for: codePart) else { return nil }
        var ftb: UInt8?
        var status: UInt8?
        if parts.count == 2 {
            let rest = parts[1].split(separator: "-", maxSplits: 1).map(String.init)
            if let f = rest.first, f.count == 2, let v = UInt8(f, radix: 16) { ftb = v }
            if rest.count == 2, rest[1].count == 2, let v = UInt8(rest[1], radix: 16) { status = v }
        }
        return DecodedDTC(code: codePart, mode: mode, failureTypeByte: ftb,
                           statusByte: status, rawBytes: (b1, b2))
    }

    /// البايتان المقابلان لكود نصي (عكس decodeCode) — للتحقق الداخلي.
    static func bytes(for code: String) -> (UInt8, UInt8)? {
        guard code.count == 5,
              let first = code.first,
              let d1 = Int(String(code.dropFirst(1).prefix(1))),
              let d2 = Int(String(code.dropFirst(2).prefix(1))),
              let d3 = Int(String(code.dropFirst(3).prefix(1))),
              let d4 = Int(String(code.dropFirst(4).prefix(1))) else { return nil }
        let letterBits: UInt8
        switch first {
        case "P": letterBits = 0
        case "C": letterBits = 1
        case "B": letterBits = 2
        case "U": letterBits = 3
        default: return nil
        }
        let b1 = (letterBits << 6) | (UInt8(d1) << 4) | UInt8(d2)
        let b2 = (UInt8(d3) << 4) | UInt8(d4)
        return (b1, b2)
    }
}

// MARK: - DTCDecoderTests (اختبارات يدوية موثقة — تُنفَّذ من SmartDiagnosticsView في الوضع التجريبي)
/// أمثلة الاختبار (من صور المبرمج 2015 ومن معيار SAE J2012):
/// - "43 01 33 00 00" → [P0133] (مثال Brief).
/// - "43 F0 00 13 46 C1 59" → [U3000, P1346, U0159] (أكواد صورة 2015).
/// - "47 01 71" → معلّقة [P0171]. "4A 01 71" → دائمة [P0171].
/// - "43 00 00" → [] (بلا أعطال — زوج الحشو فقط).
/// - "U3000:04-28" → كود U3000 + FTB 0x04 (عطل داخلي) + status 0x28
///   (مؤكد + فشل منذ آخر مسح). "P1346:13-8A" → FTB 0x13 (دائرة مفتوحة)
///   + status 0x8A. "U0159:00-0A" → FTB 0x00 + status 0x0A.
/// تُنفَّذ هذه الأمثلة عند فتح الشاشة في الوضع التجريبي وتُعرض نتيجتها
/// في السجل (AppState.addLog) — فإن فشل أي مثال يُسجَّل خطأ ولا يُخفى.
enum DTCDecoderTests {
    static func runAll() -> [(name: String, passed: Bool, detail: String)] {
        var results: [(name: String, passed: Bool, detail: String)] = []
        func check(_ name: String, _ actual: [String], _ expected: [String]) {
            let ok = actual == expected
            results.append((name, ok, ok ? actual.joined(separator: ", ") : "حصلنا على: \(actual.joined(separator: ", ")) — المتوقع: \(expected.joined(separator: ", "))"))
        }
        check("Mode 03 مثال Brief",
              DTCDecoder.decodeResponse("43 01 33 00 00", mode: .confirmed).map { $0.code },
              ["P0133"])
        check("Mode 03 أكواد صورة 2015",
              DTCDecoder.decodeResponse("43 F0 00 13 46 C1 59", mode: .confirmed).map { $0.code },
              ["U3000", "P1346", "U0159"])
        check("Mode 07 معلّقة",
              DTCDecoder.decodeResponse("47 01 71", mode: .pending).map { $0.code },
              ["P0171"])
        check("Mode 0A دائمة",
              DTCDecoder.decodeResponse("4A 01 71", mode: .permanent).map { $0.code },
              ["P0171"])
        check("Mode 03 بلا أعطال",
              DTCDecoder.decodeResponse("43 00 00", mode: .confirmed).map { $0.code },
              [])
        check("Mode 03 مع رؤوس CAN",
              DTCDecoder.decodeResponse("7E8 06 43 F0 00 13 46", mode: .confirmed).map { $0.code },
              ["U3000", "P1346"])
        check("NO DATA",
              DTCDecoder.decodeResponse("NO DATA", mode: .confirmed).map { $0.code },
              [])
        // صيغة FORScan
        if let d = DTCDecoder.parseFORScanStyle("U3000:04-28") {
            let ok = d.code == "U3000" && d.failureTypeByte == 0x04 && d.statusByte == 0x28
                && d.failureTypeDescription == "عطل داخلي في النظام"
                && d.statusDescriptions.contains("مؤكد")
            results.append(("FORScan U3000:04-28", ok, d.displayString))
        } else {
            results.append(("FORScan U3000:04-28", false, "لم يُفك"))
        }
        if let d = DTCDecoder.parseFORScanStyle("P1346:13-8A") {
            let ok = d.code == "P1346" && d.failureTypeByte == 0x13 && d.statusByte == 0x8A
                && d.failureTypeDescription == "الدائرة مفتوحة"
            results.append(("FORScan P1346:13-8A", ok, d.displayString))
        } else {
            results.append(("FORScan P1346:13-8A", false, "لم يُفك"))
        }
        if let d = DTCDecoder.parseFORScanStyle("U0159:00-0A") {
            let ok = d.code == "U0159" && d.failureTypeByte == 0x00 && d.statusByte == 0x0A
            results.append(("FORScan U0159:00-0A", ok, d.displayString))
        } else {
            results.append(("FORScan U0159:00-0A", false, "لم يُفك"))
        }
        // عكس الاتجاه: الكود → البايتان → الكود
        if let (b1, b2) = DTCDecoder.bytes(for: "U3000") {
            let ok = b1 == 0xF0 && b2 == 0x00
                && DTCDecoder.decodeCode(bytes: (b1, b2)) == "U3000"
            results.append(("عكس U3000", ok, "F0 00"))
        } else {
            results.append(("عكس U3000", false, "لم يُفك"))
        }
        return results
    }
}
