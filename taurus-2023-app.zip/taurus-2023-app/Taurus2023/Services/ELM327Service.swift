import Foundation

// MARK: - ELM327Service
/// خدمة الاتصال بقطعة ELM327 — أوامر AT و OBD-II القياسية.
/// الأوامر هنا قياسية وموثقة في دليل ELM327، وليست قيماً مخترعة.
/// كتابة As-Built تتم عبر SafetyService فقط، وليس من هنا مباشرة.
final class ELM327Service {
    var transport: OBDTransport?
    private(set) var adapter: AdapterInfo?

    // MARK: - Init
    /// تهيئة القطعة بعد الاتصال: إعادة ضبط، إيقاف الصدى، إيقاف الأسطر، إظهار الرؤوس.
    func initialize(transport: OBDTransport, adapterName: String, adapterTransport: AdapterInfo.Transport) async throws {
        self.transport = transport
        self.adapter = AdapterInfo.info(for: adapterName, transport: adapterTransport)
        // أوامر AT القياسية — انظر دليل ELM327:
        _ = try await sendAT("ATZ")   // إعادة ضبط
        _ = try await sendAT("ATE0")  // إيقاف صدى الأوامر
        _ = try await sendAT("ATL0")  // إيقاف تغذية الأسطر
        _ = try await sendAT("ATS0")  // إيقاف المسافات
        _ = try await sendAT("ATH1")  // إظهار الرؤوس (لقراءة معرّف الوحدة)
        _ = try await sendAT("ATSP6") // بروتوكول CAN 11-bit 500k (HS-CAN)
    }

    /// إرسال أمر AT واحد وإرجاع الرد كنص.
    @discardableResult
    func sendAT(_ command: String) async throws -> String {
        guard let transport else { throw OBDTransportError.notConnected }
        let response = try await transport.sendLine(command)
        if response.contains("?") {
            throw ELM327Error.invalidCommand(command)
        }
        return response
    }

    /// إرسال أمر OBD (مثل "0902" لقراءة VIN) وإرجاع الرد الخام.
    func sendOBD(_ command: String) async throws -> String {
        guard let transport else { throw OBDTransportError.notConnected }
        return try await transport.sendLine(command)
    }

    // MARK: - VIN (Mode 09 PID 02)
    /// قراءة VIN عبر Mode 09 PID 02 — أمر OBD-II قياسي.
    /// الرد يكون إطارات Hex تُمزج ثم تُحوّل إلى ASCII.
    func readVIN() async throws -> String {
        let response = try await sendOBD("0902")
        // تحليل مبسط: استخراج بايتات Hex من الرد وتحويلها إلى ASCII.
        // التنفيذ الكامل يتعامل مع إطارات متعددة (ISO-TP) — يُختبر على السيارة.
        let hexBytes = response
            .components(separatedBy: CharacterSet(charactersIn: " \r\n>"))
            .filter { !$0.isEmpty && $0.count == 2 && Int($0, radix: 16) != nil }
        var chars: [Character] = []
        for byte in hexBytes {
            if let value = UInt8(byte, radix: 16), value >= 32 && value < 127 {
                chars.append(Character(UnicodeScalar(value)))
            }
        }
        // VIN هو 17 حرفاً أبجدياً رقمياً — ابحث عنه في النص المستخرج.
        let text = String(chars)
        // ابحث عن تسلسل 17 حرفاً صالحاً لـ VIN.
        let pattern = "[A-HJ-NPR-Z0-9]{17}"
        if let range = text.range(of: pattern, options: .regularExpression) {
            return String(text[range])
        }
        throw ELM327Error.vinNotFound("لم يُقرأ VIN من الرد: \(response)")
    }

    // MARK: - DTCs (Mode 03)
    /// قراءة أكواد الأعطال المخزنة — Mode 03 القياسي.
    func readDTCs() async throws -> [String] {
        let response = try await sendOBD("03")
        // الرد: "43 XX XX ..." — كل كود بايتان. التحليل الكامل في DiagnosticsService.
        // هنا نرجع الرموز الخام ليحللها DiagnosticsService.
        return response.components(separatedBy: .whitespaces).filter { !$0.isEmpty }
    }

    // MARK: - Live PID (Mode 01)
    /// قراءة PID حي واحد — مثال: "010D" للسرعة، "010C" لـ RPM، "0142" للجهد.
    func readPID(_ pid: String) async throws -> String {
        try await sendOBD("01" + pid)
    }
}

enum ELM327Error: Error, LocalizedError {
    case invalidCommand(String)
    case vinNotFound(String)
    var errorDescription: String? {
        switch self {
        case .invalidCommand(let cmd): return "أمر غير صالح: \(cmd)"
        case .vinNotFound(let msg): return msg
        }
    }
}
