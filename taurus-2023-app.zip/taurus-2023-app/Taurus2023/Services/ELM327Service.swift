import Foundation

// MARK: - ELM327Service
/// خدمة الاتصال بقطعة ELM327 — أوامر AT و OBD-II القياسية.
/// الأوامر هنا قياسية وموثقة في دليل ELM327، وليست قيماً مخترعة.
/// كتابة As-Built تتم عبر SafetyService فقط، وليس من هنا مباشرة.
final class ELM327Service {
    var transport: OBDTransport?
    private(set) var adapter: AdapterInfo?

    // MARK: - Init
    /// تهيئة القطعة بعد الاتصال: إعادة ضبط، إيقاف الصدى، إيقاف الأسطر، إظهار الرؤوس.
    func initialize(transport: OBDTransport, adapterName: String, adapterTransport: AdapterInfo.Transport) async throws {
        self.transport = transport
        self.adapter = AdapterInfo.info(for: adapterName, transport: adapterTransport)
        // أوامر AT القياسية — انظر دليل ELM327:
        _ = try await sendAT("ATZ")   // إعادة ضبط
        _ = try await sendAT("ATE0")  // إيقاف صدى الأوامر
        _ = try await sendAT("ATL0")  // إيقاف تغذية الأسطر
        _ = try await sendAT("ATS0")  // إيقاف المسافات
        _ = try await sendAT("ATH1")  // إظهار الرؤوس (لقراءة معرّف الوحدة)
        _ = try await sendAT("ATSP6") // بروتوكول CAN 11-bit 500k (HS-CAN)
    }

    /// إرسال أمر AT واحد وإرجاع الرد كنص.
    @discardableResult
    func sendAT(_ command: String) async throws -> String {
        guard let transport else { throw OBDTransportError.notConnected }
        let response = try await transport.sendLine(command)
        if response.contains("?") {
            throw ELM327Error.invalidCommand(command)
        }
        return response
    }

    /// الأخطاء العابرة في رد ELM327 — تُعاد محاولتها (نموذج FordScan الموثق).
    /// NO DATA وUNABLE TO CONNECT ليست عابرة — لا تُعاد محاولتها أبداً، بل تُرفع
    /// فوراً لأنها تعني «الوحدة لا ترد» أو «الاتصال انقطع».
    static let transientErrorMarkers = [
        "BUFFER FULL", "CAN ERROR", "RX ERROR", "DATA ERROR",
        "BUS BUSY", "FB ERROR", "BUS ERROR",
    ]

    /// هل الرد خطأ عابر يستحق إعادة المحاولة؟ "؟" وحدها (رد غير مفهوم من القطعة)
    /// تُعامل كعابرة أيضاً — حسب نموذج FordScan.
    static func isTransientError(_ response: String) -> Bool {
        if response.trimmingCharacters(in: .whitespacesAndNewlines) == "?" { return true }
        return transientErrorMarkers.contains { response.contains($0) }
    }

    /// إرسال أمر OBD (مثل "0902" لقراءة VIN) وإرجاع الرد الخام.
    /// الرد الذي يحتوي خطأً عابراً يُعاد إرساله حتى 3 محاولات بفاصل ~300ms؛
    /// وعند BUFFER FULL يُنصَّف حجم كتلة الاستقبال قبل المحاولة التالية
    /// (بحد أدنى 256 بايت). بعد 3 محاولات يُرجع آخر رد كما هو — والمحلل
    /// (مثل parseMode22Response) يقرر رفضه، لا تُخفى المشكلة.
    func sendOBD(_ command: String) async throws -> String {
        guard let transport else { throw OBDTransportError.notConnected }
        var lastResponse = ""
        for attempt in 1...3 {
            let response = try await transport.sendLine(command)
            lastResponse = response
            guard Self.isTransientError(response) else { return response }
            if response.contains("BUFFER FULL") {
                transport.receiveBlockSize = max(256, transport.receiveBlockSize / 2)
            }
            if attempt < 3 {
                try await Task.sleep(nanoseconds: 300_000_000)
            }
        }
        return lastResponse
    }

    // MARK: - VIN (Mode 09 PID 02)
    /// قراءة VIN عبر Mode 09 PID 02 — أمر OBD-II قياسي.
    /// الرد يكون إطارات Hex تُمزج ثم تُحوّل إلى ASCII.
    func readVIN() async throws -> String {
        let response = try await sendOBD("0902")
        // تحليل مبسط: استخراج بايتات Hex من الرد وتحويلها إلى ASCII.
        // التنفيذ الكامل يتعامل مع إطارات متعددة (ISO-TP) — يُختبر على السيارة.
        let hexBytes = response
            .components(separatedBy: CharacterSet(charactersIn: " \r\n>"))
            .filter { !$0.isEmpty && $0.count == 2 && Int($0, radix: 16) != nil }
        var chars: [Character] = []
        for byte in hexBytes {
            if let value = UInt8(byte, radix: 16), value >= 32 && value < 127 {
                chars.append(Character(UnicodeScalar(value)))
            }
        }
        // VIN هو 17 حرفاً أبجدياً رقمياً — ابحث عنه في النص المستخرج.
        let text = String(chars)
        // ابحث عن تسلسل 17 حرفاً صالحاً لـ VIN.
        let pattern = "[A-HJ-NPR-Z0-9]{17}"
        if let range = text.range(of: pattern, options: .regularExpression) {
            return String(text[range])
        }
        throw ELM327Error.vinNotFound("لم يُقرأ VIN من الرد: \(response)")
    }

    // MARK: - DTCs (Mode 03)
    /// قراءة أكواد الأعطال المخزنة — Mode 03 القياسي.
    func readDTCs() async throws -> [String] {
        let response = try await sendOBD("03")
        // الرد: "43 XX XX ..." — كل كود بايتان. التحليل الكامل في DiagnosticsService.
        // هنا نرجع الرموز الخام ليحللها DiagnosticsService.
        return response.components(separatedBy: .whitespaces).filter { !$0.isEmpty }
    }

    // MARK: - Live PID (Mode 01)
    /// قراءة PID حي واحد — مثال: "010D" للسرعة، "010C" لـ RPM، "0142" للجهد.
    func readPID(_ pid: String) async throws -> String {
        try await sendOBD("01" + pid)
    }

    // MARK: - Mode 22 (UDS ReadDataByIdentifier)
    /// قراءة DID واحد من وحدة معينة — قراءة فقط، لا تكتب شيئاً.
    /// يضبط الرأس ATSH<module> ثم يرسل 22<DID>، ويعيد بايتات البيانات بعد "62 DID".
    /// يعيد الرأس إلى 7DF بعد القراءة حتى لا تتأثر قراءات Mode 01 اللاحقة.
    /// الرد متعدد الإطارات (ISO-TP) غير مدعوم بعد — هذه الـ DIDs ردودها قصيرة
    /// (بايت إلى 3 بايتات بيانات) فتكفي إطاراً واحداً.
    func readMode22(moduleHeader: String, did: String) async throws -> [UInt8] {
        _ = try await sendAT("ATSH" + moduleHeader)
        let response: String
        do {
            response = try await sendOBD("22" + did)
        } catch {
            _ = try? await sendAT("ATSH7DF")
            throw error
        }
        _ = try? await sendAT("ATSH7DF")
        return try Self.parseMode22Response(response, did: did)
    }

    /// تحليل رد Mode 22: ابحث عن تسلسل 62 + DID، والباقي بايتات البيانات.
    /// يقبل الرد مع الرؤوس (ATH1) أو بدونها.
    static func parseMode22Response(_ response: String, did: String) throws -> [UInt8] {
        if response.contains("NO DATA") || response.contains("UNABLE") || response.contains("?") {
            throw ELM327Error.mode22NoData(did)
        }
        let tokens = response.components(separatedBy: .whitespaces).filter { !$0.isEmpty }
        var bytes: [UInt8] = []
        for token in tokens where token.count == 2 {
            if let b = UInt8(token, radix: 16) { bytes.append(b) }
        }
        guard did.count == 4,
              let didHi = UInt8(String(did.prefix(2)), radix: 16),
              let didLo = UInt8(String(did.suffix(2)), radix: 16),
              bytes.count >= 3 else {
            throw ELM327Error.mode22NoData(did)
        }
        for i in 0...(bytes.count - 3) {
            if bytes[i] == 0x62 && bytes[i + 1] == didHi && bytes[i + 2] == didLo {
                return Array(bytes[(i + 3)...])
            }
        }
        throw ELM327Error.mode22NoData(did)
    }
}

enum ELM327Error: Error, LocalizedError {
    case invalidCommand(String)
    case vinNotFound(String)
    case mode22NoData(String)
    var errorDescription: String? {
        switch self {
        case .invalidCommand(let cmd): return "أمر غير صالح: \(cmd)"
        case .vinNotFound(let msg): return msg
        case .mode22NoData(let did): return "لا توجد بيانات Mode 22 للـ DID \(did) — الوحدة لم ترد أو لا تدعم هذا المعرف"
        }
    }
}
