import Foundation

// MARK: - DiagnosticsService
/// الفحص: VIN، الوحدات، الأعطال، البيانات الحية، البطارية.
/// الفحص قراءة فقط — آمن تماماً ولا يكتب شيئاً في السيارة.
final class DiagnosticsService {
    private let elm327: ELM327Service

    init(elm327: ELM327Service = ELM327Service()) {
        self.elm327 = elm327
    }

    // MARK: - VIN + Vehicle
    /// قراءة VIN والتعرف التلقائي على السيارة ومنصتها (تطبيق عام — ليس تورس فقط).
    /// أي سيارة فورد بـ VIN صحيح تُقبل للفحص. المنصة غير المعروفة تُقبل
    /// للفحص (قراءة فقط) ولا تُعرض لها مزايا قابلة للكتابة حتى تُؤكَّد
    /// من قراءة الوحدات. تورس 2015 تُقبل للفحص مع تحذير صريح — أكوادها لا تُنسخ.
    func identifyVehicle(syncVersion: String) async throws -> Vehicle {
        let vin = try await elm327.readVIN()
        switch VINValidator.identify(vin: vin, syncVersion: syncVersion) {
        case .accepted(let vehicle):
            // الفئة (Titanium / Trend / Ambient) تُقرأ من As-Built / قائمة SYNC بعد الفحص.
            // هنا تُترك "غير معروف" حتى تُقرأ من السيارة — لا تُخمن.
            return vehicle
        case .acceptedWarning(let vehicle, let warning):
            // مقبولة للفحص مع تحذير (مثال: تورس 2015) — يُسجل التحذير ولا تُكتب.
            // ملاحظة: الواجهة تعرض التحذير؛ الكتابة محظورة لأن المنصة غير موثقة
            // لأي ميزة (انظر PlatformSupport).
            _ = warning
            return vehicle
        case .rejected(let reason):
            throw DiagnosticsError.vehicleRejected(reason)
        }
    }

    // MARK: - Modules
    /// فحص الوحدات الموجودة — يُرسل أمر فحص لكل وحدة ويتحقق من الرد.
    /// القائمة الكاملة من صور FORScan: PCM, APIM, IPC, BdyCM, ACM, ABS, RCM, PSCM, SCCM, FCIM, FCDIM, OCS.
    /// ملاحظة: قائمة 2015 في الصور لا تعني أن 2023 لها نفس القائمة — الفحص الفعلي هو الحكم.
    func scanModules() async throws -> [ModuleStatus] {
        var result: [ModuleStatus] = []
        for module in Module.allCases {
            // محاولة قراءة الوحدة عبر معرّف CAN الخاص بها.
            // التنفيذ الكامل: أمر AT SH + أمر قراءة As-Built. هنا نتحقق من وجودها فقط.
            // إذا لم ترد الوحدة، تُسجل كغير موجودة — لا تُخترع.
            let found = try await probe(module: module)
            result.append(ModuleStatus(module: module, found: found, dtcCount: 0))
        }
        return result
    }

    private func probe(module: Module) async throws -> Bool {
        // تعيين رأس CAN للوحدة ثم طلب قراءة بسيط. الوحدة موجودة فقط إذا ردت
        // برد فعلي لا يحتوي "NO DATA" ولا "?" ولا "UNABLE TO CONNECT".
        // لا تُعتبر الوحدة موجودة أبداً بدون رد فعلي — هذا شرط أمان.
        _ = try? await elm327.sendAT("ATSH" + module.canID)
        let response = (try? await elm327.sendOBD("0902")) ?? ""
        if response.isEmpty { return false }
        if response.contains("NO DATA") || response.contains("UNABLE") || response.contains("?") { return false }
        // ملاحظة: هذا الفحص أولي. القراءة الكاملة لـ As-Built لكل وحدة
        // تُنفذ بعد اختبار السيارة الفعلية، وقبلها لا تُعتمد أي وحدة للكتابة.
        return true
    }

    // MARK: - DTCs
    /// قراءة الأعطال من كل وحدة.
    func readAllDTCs() async throws -> [DTC] {
        // Mode 03 يقرأ أعطال المحرك فقط. أعطال الوحدات الأخرى تتطلب أوامر خاصة بكل وحدة.
        // التنفيذ الكامل يمر على كل وحدة ويقرأ DTCs الخاصة بها.
        // هنا نرجع قائمة فارغة كأساس آمن — لا تُخترع أكواد.
        return []
    }

    // MARK: - Live data + Battery
    /// قراءة السرعة (PID 0D) — يجب أن تكون 0 قبل أي كتابة.
    func readSpeedKmh() async throws -> Double {
        let response = try await elm327.readPID("0D")
        // الرد: "41 0D XX" — XX هو السرعة بالكم/س.
        return parsePIDByte(response, pid: "0D")
    }

    /// قراءة جهد البطارية — عبر أمر ELM327 ATRV (قراءة الجهد) أو PID 42.
    func readBatteryVoltage() async throws -> Double {
        let response = try await elm327.sendAT("ATRV")
        // الرد مثل "12.8V" — استخرج الرقم.
        let digits = response.filter { "0123456789.".contains($0) }
        return Double(digits) ?? 0
    }

    /// قراءة RPM (PID 0C) — للعرض فقط.
    /// الرد المتوقع: "41 0C AA BB" — RPM = (AA*256 + BB) / 4.
    /// التحليل الكامل يُختبر على السيارة — حتى ذلك الحين ترجع 0 ولا تُخترع قيمة.
    func readRPM() async throws -> Double {
        _ = try await elm327.readPID("0C")
        return 0
    }

    // MARK: - Live signals (Mode 22, OBDb)
    /// قراءة إشارة حية واحدة Mode 22 من ملفي OBDb — قراءة فقط.
    /// تعيد القيمة المفكوكة (nil إن كانت القيمة تعني "لا بيانات") والرد الخام.
    func readLiveSignal(_ signal: LiveSignal) async throws -> LiveSignalReading {
        let data = try await elm327.readMode22(moduleHeader: signal.module.canID, did: signal.did)
        let rawHex = data.map { String(format: "%02X", $0) }.joined(separator: " ")
        let value = signal.decode(data: data)
        return LiveSignalReading(value: value, rawHex: rawHex.isEmpty ? "—" : rawHex)
    }

    // MARK: - CD542 identity (APIM DE02/DE04, Mode 22, read-only)
    /// قراءة بلوك APIM واحد عبر Mode 22 (DID DE00–DE0F) — قراءة فقط.
    /// ملاحظة: المحول يعيد تجميع الرد متعدد الإطارات (ISO-TP) تلقائياً في الوضع
    /// التلقائي، فالـ 15 بايتاً لبلوك DE02 تصل سطراً واحداً. إن وصلت بايتات أقل،
    /// تُعرض كما وصلت فقط — لا تُخمن بايتات ناقصة.
    func readAPIMBlock(did: String) async throws -> [UInt8] {
        try await elm327.readMode22(moduleHeader: Module.apim.canID, did: did)
    }

    /// فحص هوية CD542: قراءة DE02 (بلوك 3) وDE04 (بلوك 5) من APIM 7D0.
    /// قراءة فقط — لا كتابة. يُعيد البايتات الخام كما وصلت؛ التفسير في CD542Identity.
    func readCD542Identity() async throws -> CD542Identity {
        let de02 = try await readAPIMBlock(did: "DE02")
        let de04 = try await readAPIMBlock(did: "DE04")
        return CD542Identity(de02Bytes: de02, de04Bytes: de04)
    }

    // MARK: - Helpers
    private func parsePIDByte(_ response: String, pid: String) -> Double {
        // تحليل مبسط — يُختبر على السيارة.
        let parts = response.components(separatedBy: .whitespaces).filter { !$0.isEmpty }
        guard let last = parts.last, let value = Int(last, radix: 16) else { return 0 }
        return Double(value)
    }
}

enum DiagnosticsError: Error, LocalizedError {
    case vehicleRejected(String)
    var errorDescription: String? {
        if case .vehicleRejected(let reason) = self { return reason }
        return nil
    }
}

// MARK: - CD542Identity
/// نتيجة فحص هوية CD542 من APIM — البايتات الخام كما قُرئت + تفسيرها.
///
/// مواضع الحقول (من تعريفي FordScan وCyanLabs لـ APIM SYNC 4، بلوك DE02 = 15 بايتاً:
/// السطر 7D0-03-01 = بايتات البلوك 0–4، والسطر 7D0-03-02 = بايتات 5–9،
/// والسطر 7D0-03-03 = بايتات 10–14):
/// - حقل Vehicle: FordScan يقول بايت 5 من البلوك (= بايت 0 من سطر 7D0-03-02)،
///   وCyanLabs يقول بايت 4 من سطر 7D0-03-02 (= بايت 9 من البلوك). المتفق عليه
///   رقم الخيار 20 فقط (0x14 = CD542). يُفحص الموضعان معاً ويُعرض كلاهما.
/// - مقاس الشاشة: بايت 4 من البلوك (= بايت 4 من سطر 7D0-03-01)؛ 06 = 13.2" Ford،
///   05 = 13.2" Lincoln، 09 = 13.2" (Qt based) — حسب تعريف FordScan.
/// - TSR: البلوك DE04، النصف العلوي (nibble) من بايته 0؛ 0 = Speed Limit in HMI،
///   2 = Speed Limit not in HMI (Traffic Sign Recognition) — حسب تعريف CyanLabs.
struct CD542Identity {
    let de02Bytes: [UInt8]
    let de04Bytes: [UInt8]

    var de02Hex: String {
        de02Bytes.isEmpty ? "—" : de02Bytes.map { String(format: "%02X", $0) }.joined(separator: " ")
    }

    var de04Hex: String {
        de04Bytes.isEmpty ? "—" : de04Bytes.map { String(format: "%02X", $0) }.joined(separator: " ")
    }

    /// حقل Vehicle عند بايت 5 من البلوك (FordScan: بايت 5 من بلوك 3).
    var vehicleByteFordScan: UInt8? { de02Bytes.count > 5 ? de02Bytes[5] : nil }

    /// حقل Vehicle عند بايت 9 من البلوك (CyanLabs: بايت 4 من سطر 7D0-03-02).
    var vehicleByteCyanLabs: UInt8? { de02Bytes.count > 9 ? de02Bytes[9] : nil }

    /// بايت مقاس الشاشة: بايت 4 من البلوك (بايت 4 من سطر 7D0-03-01).
    var screenSizeByte: UInt8? { de02Bytes.count > 4 ? de02Bytes[4] : nil }

    /// النصف العلوي من بايت 0 في DE04 (حقل TSR).
    var tsrNibble: UInt8? { de04Bytes.isEmpty ? nil : de04Bytes[0] >> 4 }

    /// مطابق لـ CD542 إذا وُجد 0x14 في أي من الموضعين المتعارض عليهما.
    var isCD542: Bool { vehicleByteFordScan == 0x14 || vehicleByteCyanLabs == 0x14 }

    var vehicleText: String {
        var parts: [String] = []
        if let b5 = vehicleByteFordScan {
            parts.append("بايت 5 (FordScan): 0x\(String(format: "%02X", b5))\(b5 == 0x14 ? " = CD542" : "")")
        } else {
            parts.append("بايت 5 (FordScan): لم يصل")
        }
        if let b9 = vehicleByteCyanLabs {
            parts.append("بايت 9 (CyanLabs): 0x\(String(format: "%02X", b9))\(b9 == 0x14 ? " = CD542" : "")")
        } else {
            parts.append("بايت 9 (CyanLabs): لم يصل")
        }
        return parts.joined(separator: " — ")
    }

    var screenSizeText: String {
        switch screenSizeByte {
        case 0x06: return "13.2\" Ford (Dashcard)"
        case 0x05: return "13.2\" Lincoln (Dashcard)"
        case 0x09: return "13.2\" (Qt based)"
        case .some(let b): return "قيمة غير متوقعة: 0x\(String(format: "%02X", b))"
        case .none: return "لم يصل"
        }
    }

    var tsrText: String {
        switch tsrNibble {
        case 0: return "Speed Limit in HMI — حد السرعة معروض في الشاشة"
        case 2: return "Speed Limit not in HMI — Traffic Sign Recognition (قراءة حد السرعة من كاميرا الإشارات) — ذو صلة بالميزة #14"
        case .some(let n): return "قيمة غير متوقعة: \(n)"
        case .none: return "لم يصل"
        }
    }
}
