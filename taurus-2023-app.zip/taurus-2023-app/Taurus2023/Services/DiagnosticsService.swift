import Foundation

// MARK: - DiagnosticsService
/// الفحص: VIN، الوحدات، الأعطال، البيانات الحية، البطارية.
/// الفحص قراءة فقط — آمن تماماً ولا يكتب شيئاً في السيارة.
final class DiagnosticsService {
    private let elm327: ELM327Service

    init(elm327: ELM327Service = ELM327Service()) {
        self.elm327 = elm327
    }

    // MARK: - VIN + Vehicle
    /// قراءة VIN والتعرف التلقائي على السيارة ومنصتها (تطبيق عام — ليس تورس فقط).
    /// أي سيارة فورد بـ VIN صحيح تُقبل للفحص. المنصة غير المعروفة تُقبل
    /// للفحص (قراءة فقط) ولا تُعرض لها مزايا قابلة للكتابة حتى تُؤكَّد
    /// من قراءة الوحدات. تورس 2015 تُقبل للفحص مع تحذير صريح — أكوادها لا تُنسخ.
    func identifyVehicle(syncVersion: String) async throws -> Vehicle {
        let vin = try await elm327.readVIN()
        switch VINValidator.identify(vin: vin, syncVersion: syncVersion) {
        case .accepted(let vehicle):
            // الفئة (Titanium / Trend / Ambient) تُقرأ من As-Built / قائمة SYNC بعد الفحص.
            // هنا تُترك "غير معروف" حتى تُقرأ من السيارة — لا تُخمن.
            return vehicle
        case .acceptedWarning(let vehicle, let warning):
            // مقبولة للفحص مع تحذير (مثال: تورس 2015) — يُسجل التحذير ولا تُكتب.
            // ملاحظة: الواجهة تعرض التحذير؛ الكتابة محظورة لأن المنصة غير موثقة
            // لأي ميزة (انظر PlatformSupport).
            _ = warning
            return vehicle
        case .rejected(let reason):
            throw DiagnosticsError.vehicleRejected(reason)
        }
    }

    // MARK: - Modules
    /// فحص الوحدات الموجودة — يُرسل أمر فحص لكل وحدة ويتحقق من الرد.
    /// القائمة الكاملة من صور FORScan: PCM, APIM, IPC, BdyCM, ACM, ABS, RCM, PSCM, SCCM, FCIM, FCDIM, OCS.
    /// ملاحظة: قائمة 2015 في الصور لا تعني أن 2023 لها نفس القائمة — الفحص الفعلي هو الحكم.
    func scanModules() async throws -> [ModuleStatus] {
        var result: [ModuleStatus] = []
        for module in Module.allCases {
            // محاولة قراءة الوحدة عبر معرّف CAN الخاص بها.
            // التنفيذ الكامل: أمر AT SH + أمر قراءة As-Built. هنا نتحقق من وجودها فقط.
            // إذا لم ترد الوحدة، تُسجل كغير موجودة — لا تُخترع.
            let found = try await probe(module: module)
            result.append(ModuleStatus(module: module, found: found, dtcCount: 0))
        }
        return result
    }

    private func probe(module: Module) async throws -> Bool {
        // تعيين رأس CAN للوحدة ثم طلب قراءة بسيط. الوحدة موجودة فقط إذا ردت
        // برد فعلي لا يحتوي "NO DATA" ولا "?" ولا "UNABLE TO CONNECT".
        // لا تُعتبر الوحدة موجودة أبداً بدون رد فعلي — هذا شرط أمان.
        _ = try? await elm327.sendAT("ATSH" + module.canID)
        let response = (try? await elm327.sendOBD("0902")) ?? ""
        if response.isEmpty { return false }
        if response.contains("NO DATA") || response.contains("UNABLE") || response.contains("?") { return false }
        // ملاحظة: هذا الفحص أولي. القراءة الكاملة لـ As-Built لكل وحدة
        // تُنفذ بعد اختبار السيارة الفعلية، وقبلها لا تُعتمد أي وحدة للكتابة.
        return true
    }

    // MARK: - DTCs
    /// قراءة الأعطال من كل وحدة.
    func readAllDTCs() async throws -> [DTC] {
        // Mode 03 يقرأ أعطال المحرك فقط. أعطال الوحدات الأخرى تتطلب أوامر خاصة بكل وحدة.
        // التنفيذ الكامل يمر على كل وحدة ويقرأ DTCs الخاصة بها.
        // هنا نرجع قائمة فارغة كأساس آمن — لا تُخترع أكواد.
        return []
    }

    // MARK: - Live data + Battery
    /// قراءة السرعة (PID 0D) — يجب أن تكون 0 قبل أي كتابة.
    func readSpeedKmh() async throws -> Double {
        let response = try await elm327.readPID("0D")
        // الرد: "41 0D XX" — XX هو السرعة بالكم/س.
        return parsePIDByte(response, pid: "0D")
    }

    /// قراءة جهد البطارية — عبر أمر ELM327 ATRV (قراءة الجهد) أو PID 42.
    func readBatteryVoltage() async throws -> Double {
        let response = try await elm327.sendAT("ATRV")
        // الرد مثل "12.8V" — استخرج الرقم.
        let digits = response.filter { "0123456789.".contains($0) }
        return Double(digits) ?? 0
    }

    /// قراءة RPM (PID 0C) — للعرض فقط.
    /// الرد المتوقع: "41 0C AA BB" — RPM = (AA*256 + BB) / 4.
    /// التحليل الكامل يُختبر على السيارة — حتى ذلك الحين ترجع 0 ولا تُخترع قيمة.
    func readRPM() async throws -> Double {
        _ = try await elm327.readPID("0C")
        return 0
    }

    // MARK: - Helpers
    private func parsePIDByte(_ response: String, pid: String) -> Double {
        // تحليل مبسط — يُختبر على السيارة.
        let parts = response.components(separatedBy: .whitespaces).filter { !$0.isEmpty }
        guard let last = parts.last, let value = Int(last, radix: 16) else { return 0 }
        return Double(value)
    }
}

enum DiagnosticsError: Error, LocalizedError {
    case vehicleRejected(String)
    var errorDescription: String? {
        if case .vehicleRejected(let reason) = self { return reason }
        return nil
    }
}
