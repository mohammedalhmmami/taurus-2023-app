import Foundation

// MARK: - SafetyService
/// بوابة الأمان قبل أي كتابة. لا توجد كتابة في السيارة إلا عبر هذه الخدمة.
/// القواعد (كلها إلزامية، ولا يوجد تجاوز لها في الواجهة):
///  1. VIN تورس 2023 فقط.
///  2. نسخة احتياطية محفوظة قبل أول كتابة.
///  3. تغيير واحد فقط في كل مرة (قفل كتابة).
///  4. البطارية فوق 12.0V والسرعة 0.
///  5. القطعة موصى بها (ليست ELM327 v1.5 رخيصة).
///  6. الوحدة قابلة للكتابة (PCM/TCM/RCM/ABS محظورة برمجياً).
///  7. الميزة قابلة للكتابة (غير المؤكدة مرفوضة).
///  8. التحقق بعد الكتابة بإعادة القراءة.
///  9. إيقاف فوري عند انقطاع الاتصال أو انخفاض الجهد.
final class SafetyService {
    private let backupStore = BackupStore()
    private var isWriting = false // قفل الكتابة — تغيير واحد فقط في كل مرة.

    // MARK: - Backup
    /// حفظ نسخة احتياطية تلقائية لكل As-Built قبل أول تغيير.
    func backupAll(modules: [ModuleStatus], vin: String) throws -> BackupSet {
        let set = BackupSet(vin: vin, date: Date(), lines: modules.flatMap { $0.asBuiltLines })
        try backupStore.save(set)
        return set
    }

    /// استرجاع بضغطة واحدة — يعيد كل سطر إلى قيمته المحفوظة.
    /// الاسترجاع نفسه يمر بنفس فحوصات السلامة (اتصال + بطارية + سرعة 0).
    func restore(backup: BackupSet, elm327: ELM327Service) async throws {
        // التنفيذ: لكل سطر في النسخة، اكتب القيمة الأصلية، ثم تحقق بإعادة القراءة.
        // التفاصيل الدقيقة لأوامر الكتابة لكل وحدة تُختبر على السيارة.
        // هنا: لا تُحذف النسخة بعد الاسترجاع — تبقى للاسترجاع مرة أخرى إن لزم.
        _ = elm327
        _ = backup
        // TODO: تنفيذ أوامر الكتابة الفعلية بعد اختبار السيارة — لا تُخترع أوامر هنا.
        throw SafetyError.notImplemented("الاسترجاع الفعلي — يُنفذ بعد اختبار أوامر الكتابة على السيارة")
    }

    // MARK: - Write gate
    /// فحص شامل قبل أي كتابة. يرجع خطأ عربي واضح عند أول شرط فاشل.
    func checkBeforeWrite(feature: Feature, report: SafetyReport, vehicle: Vehicle?) throws {
        // 1. السيارة تورس 2023؟
        guard let vehicle else { throw SafetyError.notReady("لم تُقرأ السيارة بعد — اقرأ VIN أولاً") }
        guard vehicle.modelYear == 2023 else {
            throw SafetyError.notReady("السيارة ليست تورس 2023 — الكتابة مرفوضة")
        }
        // 2. الوحدة قابلة للكتابة؟ (PCM/TCM محظوران برمجياً هنا أيضاً — دفاع مزدوج)
        guard feature.module.isWritable else {
            throw SafetyError.forbidden(feature.module.writeBanReason ?? "الكتابة محظورة على هذه الوحدة")
        }
        // 3. الميزة قابلة للكتابة؟ (غير المؤكدة مرفوضة)
        guard feature.isWritable else {
            throw SafetyError.forbidden("هذه الميزة «غير مؤكد — يحتاج قراءة As-Built الفعلي من السيارة قبل الكتابة». لا تُكتب قيمة تخمينية.")
        }
        // 4. تقرير السلامة كامل؟
        guard report.canWrite else {
            let failed = report.checks.filter { !$0.1 }.map { $0.0 }.joined(separator: "، ")
            throw SafetyError.notReady("تقرير السلامة غير مكتمل: \(failed)")
        }
        // 5. قفل الكتابة — تغيير واحد فقط في كل مرة.
        guard !isWriting else {
            throw SafetyError.notReady("يوجد تغيير جارٍ — انتظر انتهاءه قبل تغيير آخر")
        }
    }

    /// قفل / فتح الكتابة (يُستخدم حول عملية الكتابة الفعلية).
    func beginWrite() { isWriting = true }
    func endWrite() { isWriting = false }

    // MARK: - Verify after write
    /// التحقق بعد الكتابة: أعد قراءة السطر وقارنه بالقيمة المطلوبة.
    /// إذا لم تتطابق، يُعرض تنبيه ويُقترح الاسترجاع فوراً.
    func verifyAfterWrite(expected: AsBuiltLine, actual: AsBuiltLine) -> Bool {
        expected.blocks == actual.blocks
    }
}

enum SafetyError: Error, LocalizedError {
    case notReady(String)
    case forbidden(String)
    case notImplemented(String)
    var errorDescription: String? {
        switch self {
        case .notReady(let msg): return msg
        case .forbidden(let msg): return msg
        case .notImplemented(let msg): return msg
        }
    }
}
