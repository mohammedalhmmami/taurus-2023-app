import Foundation

// MARK: - CANBus
/// المساران الكاملان: HS-CAN و MS-CAN.
/// FORScan يحتاج المسارين معاً: بعض الوحدات على HS-CAN وبعضها على MS-CAN.
/// القطع الرخيصة ELM327 v1.5 تحتاج مفتاحاً يدوياً HS/MS — وهذا مصدر أخطاء.
/// vLinker FS و OBDLink MX+ يبدلان تلقائياً — لذلك هما الموصى بهما.
enum CANBus: String, Equatable {
    case highSpeed = "HS-CAN"   // 500 kbps — المحرك، الشاشة، العدادات
    case mediumSpeed = "MS-CAN" // 125 kbps — الجسم، التكييف، بعض وحدات الراحة

    /// أمر ELM327 لاختيار البروتوكول.
    /// ATSP6 = ISO 15765-4 CAN 11-bit 500k (HS-CAN).
    /// MS-CAN: لا يوجد أمر AT قياسي موثق للتبديل إليه. CANBusManager يرفض
    /// التبديل إلى MS-CAN أصلاً حتى يُوثق أمر القطعة الخاص — هذه الخاصية
    /// لا تُستخدم لـ MS-CAN أبداً، وقيمتها هنا مجرد عنصر نائب لا يُرسل.
    var elm327ProtocolCommand: String {
        switch self {
        case .highSpeed: return "ATSP6"
        case .mediumSpeed: return "" // لا يُرسل أبداً — انظر CANBusManager.switchToBus
        }
    }

    /// الوحدات التي تعيش عادة على كل مسار (تقريبي — يُتحقق بالفحص الفعلي).
    var typicalModules: [Module] {
        switch self {
        case .highSpeed: return [.pcm, .tcm, .apim, .ipc, .abs, .pscm]
        case .mediumSpeed: return [.bdyCM, .acm, .sccm, .fcim, .fcdim, .ocs, .rcm]
        }
    }
}

/// مدير التبديل التلقائي بين المسارين.
final class CANBusManager {
    private(set) var current: CANBus = .highSpeed
    var supportsAutoSwitch: Bool = false // true لـ vLinker FS / OBDLink MX+

    /// التبديل إلى مسار وحدة معينة قبل قراءتها أو الكتابة فيها.
    /// إذا كانت القطعة لا تدعم التبديل التلقائي والمسار المطلوب MS-CAN، يُرجع خطأ
    /// بدلاً من محاولة الكتابة من المسار الخاطئ.
    func switchToBus(for module: Module, elm327: ELM327Service) async throws {
        let needed: CANBus = CANBus.mediumSpeed.typicalModules.contains(module) ? .mediumSpeed : .highSpeed
        if needed == current { return }
        if needed == .mediumSpeed {
            // لا يوجد أمر AT قياسي موثق للتبديل إلى MS-CAN في ELM327.
            // أمر vLinker FS / OBDLink الخاص بالتبديل لم يُتحقق منه بعد على قطعة فعلية،
            // وإرسال ATSP6 هنا كان سيبقي الاتصال على HS-CAN ويكتب من المسار الخاطئ.
            // لذلك: الرفض الصريح بدلاً من محاولة خاطئة — حتى يُوثق أمر التبديل.
            throw CANBusError.manualSwitchRequired(
                "وحدة \(module.rawValue) على MS-CAN، وأمر التبديل إلى MS-CAN لقطعتك لم يُوثق بعد على قطعة فعلية. لا تُحاول الكتابة لها حتى يُوثق أمر التبديل من دليل vLinker FS / OBDLink MX+.")
        }
        try await elm327.sendAT(needed.elm327ProtocolCommand)
        current = needed
    }
}

enum CANBusError: Error, LocalizedError {
    case manualSwitchRequired(String)
    var errorDescription: String? {
        if case .manualSwitchRequired(let msg) = self { return msg }
        return nil
    }
}
