import SwiftUI

// MARK: - SidebarView
/// الشريط الجانبي — أيقونات لكل مسار/وحدة، مثل أيقونات FORScan الجانبية.
/// على الآيفون يظهر كقائمة تنقل؛ على الآيباد كشريط جانبي ثابت.
struct SidebarView: View {
    @Binding var selected: SidebarDestination
    @EnvironmentObject var appState: AppState

    var body: some View {
        List {
            // رأس الشريط: السيارة وحالة الاتصال.
            Section {
                VStack(alignment: .leading, spacing: 6) {
                    Text("برمجة فورد تورس 2023")
                        .font(.headline)
                        .foregroundColor(.gold)
                    if let vehicle = appState.vehicle {
                        Text("VIN: \(vehicle.vin)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text("SYNC 4 — 2.0 EcoBoost")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    } else {
                        Text("لم تُقرأ السيارة بعد")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    Text(appState.connection.isConnected ? "● متصل" : "○ غير متصل")
                        .font(.caption)
                        .foregroundColor(appState.connection.isConnected ? .green : .red)
                }
            }

            // مسارات التطبيق.
            Section("المسارات") {
                ForEach(SidebarDestination.allCases) { dest in
                    Button {
                        selected = dest
                    } label: {
                        Label(dest.rawValue, systemImage: dest.iconName)
                    }
                    .listRowBackground(selected == dest ? Color.gold.opacity(0.15) : Color.clear)
                }
            }

            // مسارات الوحدات — أيقونة لكل وحدة.
            Section("الوحدات") {
                ForEach(Module.allCases) { module in
                    Label {
                        Text("\(module.arabicName) (\(module.rawValue))")
                    } icon: {
                        Image(systemName: module.iconName)
                    }
                    .foregroundColor(module.isWritable ? .primary : .secondary)
                    .font(.caption)
                }
                Text("PCM و TCM محظوران من الكتابة نهائياً — لا يظهران في المزايا")
                    .font(.caption2)
                    .foregroundColor(.red)
            }
        }
        .listStyle(.sidebar)
        .navigationTitle("تورس 2023")
    }
}

// MARK: - Color.gold
extension Color {
    /// الذهبي المستخدم في التصميم الداكن الذهبي.
    static let gold = Color(red: 0.85, green: 0.65, blue: 0.25)
}
