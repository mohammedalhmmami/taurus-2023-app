import SwiftUI

// MARK: - FeaturesView
/// المزايا الـ18 — كل صف يفتح شاشة تفاصيل خاصة به (المسار الكامل + حالة
/// التحقق + زر إجراء). الضغط على الصف يفتح التفاصيل دائماً حتى لو كان
/// الزر معطلاً — لا صفوف ميتة.
/// القاعدة في الواجهة:
///  - غير مؤكدة (unverified): قراءة وعرض فقط، مع رسالة "غير مؤكد".
///  - مؤكدة جزئياً: زر يعمل لكن مع تنبيه تعارض + تأكيد إضافي قبل الكتابة.
///  - مؤكدة: زر يعمل بعد فحص SafetyService.
/// لا توجد كتابة فعلية في السيارة من هذه الشاشة مباشرة — الكتابة تمر عبر
/// SafetyService فقط، وبعد نسخة احتياطية. تنفيذ أوامر الكتابة الفعلية
/// يحتاج اختبار السيارة (انظر README_AR.md).
struct FeaturesView: View {
    @EnvironmentObject var appState: AppState
    @State private var features: [Feature] = FeatureDatabase.allFeatures()
    @State private var selectedFeature: Feature?
    @State private var showConflictAlert = false
    @State private var lockAlertMessage: String?
    @State private var showLockAlert = false

    var body: some View {
        List(features) { feature in
            HStack(alignment: .top) {
                // الصف نفسه يفتح التفاصيل دائماً — حتى لو كان الزر معطلاً.
                NavigationLink {
                    FeatureDetailView(feature: feature, isOn: feature.isEnabled) { newValue in
                        if let index = features.firstIndex(where: { $0.id == feature.id }) {
                            features[index].isEnabled = newValue
                        }
                    }
                } label: {
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text("\(feature.id). \(feature.titleAr)")
                                .font(.headline)
                                .foregroundColor(.primary)
                            Spacer()
                            statusBadge(for: feature.status)
                        }
                        Text(feature.descriptionAr)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.leading)
                        Text(feature.pathAr)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .monospaced()
                        Text("القيمة الحالية: لم تُقرأ بعد — تُقرأ من As-Built الفعلي للسيارة عند الفحص")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        if let condition = feature.conditionAr {
                            Text("الشرط: \(condition)").font(.caption).foregroundColor(.orange)
                        }
                        if let warning = feature.warningAr {
                            Text("⚠️ \(warning)").font(.caption).foregroundColor(.orange)
                        }
                        if let platform = appState.vehicle?.platform, !PlatformSupport.isFeatureWritable(feature: feature, platform: platform) {
                            Text(PlatformSupport.disabledReason(feature: feature, platform: platform))
                                .font(.caption).foregroundColor(.red)
                        }
                        Text("المصدر: \(feature.source)")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 4)
                }
                .buttonStyle(.plain)

                // زر الإجراء: Toggle يعمل فقط عند توفر كل شروط الكتابة،
                // وإلا صف مقفل يشرح السبب عند الضغط عليه.
                if featureCanToggle(feature: feature, appState: appState) {
                    Toggle("تفعيل", isOn: binding(for: feature))
                        .labelsHidden()
                } else {
                    Button {
                        lockAlertMessage = featureLockReason(feature: feature, appState: appState)
                            ?? "غير قابلة للكتابة حالياً."
                        showLockAlert = true
                    } label: {
                        VStack(spacing: 2) {
                            Image(systemName: "lock.fill")
                                .foregroundColor(.orange)
                            Text("مقفل")
                                .font(.caption2)
                                .foregroundColor(.orange)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .navigationTitle("المزايا (18)")
        .alert("لماذا هذا الخيار مقفل؟", isPresented: $showLockAlert) {
            Button("فهمت", role: .cancel) {}
        } message: {
            Text(lockAlertMessage ?? "")
        }
        .alert("تعارض مسجل", isPresented: $showConflictAlert) {
            Button("فهمت", role: .cancel) {}
        } message: {
            if let feature = selectedFeature, case .partiallyVerified(let conflict) = feature.status {
                Text(conflict + "\n\nهذه القيمة مؤكدة لموديل فورد آخر وليست مؤكدة مباشرة لمنصة هذه السيارة. اقرأ BdyCM / IPC الفعلي للسيارة أولاً وتأكد من مطابقة السطر الحالي للنمط المتوقع قبل أي كتابة.")
            }
        }
    }

    /// هل هذه الميزة قابلة للكتابة على منصة السيارة المتصلة؟
    /// بلا سيارة متصلة: لا كتابة إطلاقاً.
    private func isWritableOnCar(_ feature: Feature) -> Bool {
        guard let platform = appState.vehicle?.platform else { return false }
        return PlatformSupport.isFeatureWritable(feature: feature, platform: platform)
    }

    private func binding(for feature: Feature) -> Binding<Bool> {
        Binding(
            get: { feature.isEnabled },
            set: { newValue in
                // دفاع إضافي: لا تغيير في الوضع التجريبي أبداً.
                if appState.demoMode { return }
                // عرض تنبيه التعارض قبل التفعيل للميزات الجزئية.
                if case .partiallyVerified = feature.status, newValue {
                    selectedFeature = feature
                    showConflictAlert = true
                }
                // التفعيل الفعلي يتم فقط بعد موافقة المستخدم على التنبيه
                // ومرور SafetyService.checkBeforeWrite — لا يُنفذ هنا.
                // انظر SafetyService: الكتابة الفعلية تُنفذ بعد اختبار السيارة.
                if let index = features.firstIndex(where: { $0.id == feature.id }) {
                    features[index].isEnabled = newValue
                }
                appState.addLog("طلب تغيير الميزة \(feature.id): \(feature.titleAr) → \(newValue ? "تفعيل" : "إيقاف") (بانتظار فحص السلامة)", level: .info)
            }
        )
    }

    @ViewBuilder
    private func statusBadge(for status: VerificationStatus) -> some View {
        switch status {
        case .verified:
            Text("✅ مؤكد").font(.caption2).foregroundColor(.green)
        case .partiallyVerified:
            Text("⚠️ جزئي").font(.caption2).foregroundColor(.orange)
        case .unverified:
            Text("❌ غير مؤكد").font(.caption2).foregroundColor(.red)
        }
    }
}
