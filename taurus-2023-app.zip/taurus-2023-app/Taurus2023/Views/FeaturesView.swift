import SwiftUI

// MARK: - FeaturesView
/// المزايا الـ18 — كل ميزة زر تفعيل/إيقاف.
/// القاعدة في الواجهة:
///  - غير مؤكدة (unverified): الزر معطّل نهائياً، مع رسالة "غير مؤكد".
///  - مؤكدة جزئياً: الزر يعمل لكن مع تنبيه تعارض + تأكيد إضافي قبل الكتابة.
///  - مؤكدة: الزر يعمل بعد فحص SafetyService.
/// لا توجد كتابة فعلية في السيارة من هذه الشاشة مباشرة — الكتابة تمر عبر
/// SafetyService فقط، وبعد نسخة احتياطية. تنفيذ أوامر الكتابة الفعلية
/// يحتاج اختبار السيارة (انظر README_AR.md).
struct FeaturesView: View {
    @EnvironmentObject var appState: AppState
    @State private var features: [Feature] = FeatureDatabase.allFeatures()
    @State private var selectedFeature: Feature?
    @State private var showConflictAlert = false

    var body: some View {
        List(features) { feature in
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text("\(feature.id). \(feature.titleAr)")
                        .font(.headline)
                    Spacer()
                    statusBadge(for: feature.status)
                }
                Text(feature.descriptionAr)
                    .font(.caption)
                    .foregroundColor(.secondary)
                if let condition = feature.conditionAr {
                    Text("الشرط: \(condition)").font(.caption).foregroundColor(.orange)
                }
                if let warning = feature.warningAr {
                    Text("⚠️ \(warning)").font(.caption).foregroundColor(.orange)
                }
                switch feature.status {
                case .unverified(let reason):
                    Text("غير مؤكد — يحتاج قراءة As-Built الفعلي من السيارة قبل الكتابة")
                        .font(.caption).foregroundColor(.red)
                    Text(reason).font(.caption2).foregroundColor(.secondary)
                    Toggle("تفعيل", isOn: .constant(false))
                        .disabled(true)
                case .partiallyVerified(let conflict):
                    Text("⚠️ تعارض مسجل: \(conflict)")
                        .font(.caption).foregroundColor(.orange)
                    if case .plainEnglishSetting = feature.change {
                        Text("يُنفذ عبر مسار Configuration في FORScan — لا يكتب سطر As-Built مباشراً، ويحتاج تنفيذ مسار Configuration بعد اختبار السيارة.")
                            .font(.caption).foregroundColor(.secondary)
                    }
                    if !feature.isWritable {
                        Text("غير قابل للكتابة حالياً — لا يوجد عنوان As-Built موثوق ولا مسار Configuration موثق. قراءة وعرض فقط.")
                            .font(.caption).foregroundColor(.red)
                    }
                    Toggle("تفعيل", isOn: binding(for: feature))
                        .disabled(!appState.safety.canWrite || !feature.isWritable)
                case .verified:
                    Toggle("تفعيل", isOn: binding(for: feature))
                        .disabled(!appState.safety.canWrite)
                }
                Text("المصدر: \(feature.source)")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            .padding(.vertical, 4)
        }
        .navigationTitle("المزايا (18)")
        .alert("تعارض مسجل", isPresented: $showConflictAlert) {
            Button("فهمت", role: .cancel) {}
        } message: {
            if let feature = selectedFeature, case .partiallyVerified(let conflict) = feature.status {
                Text(conflict + "\n\nهذه القيمة مؤكدة لموديل فورد آخر وليست مؤكدة مباشرة لتورس 2023. اقرأ BdyCM / IPC الفعلي للسيارة أولاً وتأكد من مطابقة السطر الحالي للنمط المتوقع قبل أي كتابة.")
            }
        }
    }

    private func binding(for feature: Feature) -> Binding<Bool> {
        Binding(
            get: { feature.isEnabled },
            set: { newValue in
                // عرض تنبيه التعارض قبل التفعيل للميزات الجزئية.
                if case .partiallyVerified = feature.status, newValue {
                    selectedFeature = feature
                    showConflictAlert = true
                }
                // التفعيل الفعلي يتم فقط بعد موافقة المستخدم على التنبيه
                // ومرور SafetyService.checkBeforeWrite — لا يُنفذ هنا.
                // انظر SafetyService: الكتابة الفعلية تُنفذ بعد اختبار السيارة.
                if let index = features.firstIndex(where: { $0.id == feature.id }) {
                    features[index].isEnabled = newValue
                }
                appState.addLog("طلب تغيير الميزة \(feature.id): \(feature.titleAr) → \(newValue ? "تفعيل" : "إيقاف") (بانتظار فحص السلامة)", level: .info)
            }
        )
    }

    @ViewBuilder
    private func statusBadge(for status: VerificationStatus) -> some View {
        switch status {
        case .verified:
            Text("✅ مؤكد").font(.caption2).foregroundColor(.green)
        case .partiallyVerified:
            Text("⚠️ جزئي").font(.caption2).foregroundColor(.orange)
        case .unverified:
            Text("❌ غير مؤكد").font(.caption2).foregroundColor(.red)
        }
    }
}
