import SwiftUI

// MARK: - DetailScaffold
/// الهيكل الموحد لكل شاشات التفاصيل: ماذا يفعل، المسار الكامل، حالة التحقق، الإجراء.
/// زر الإجراء يعمل فقط عند توفر كل شروط الكتابة، وإلا يظهر معطلاً مع سبب واضح تحته.
struct DetailScaffold: View {
    let title: String
    let iconName: String
    let functionText: String
    let pathRows: [(label: String, value: String)]
    let verificationText: String
    let verificationColor: Color
    let actionLabel: String
    let actionEnabled: Bool
    let disabledReason: String?
    let onAction: () -> Void
    @Binding var resultMessage: String?
    var extraSection: AnyView? = nil

    var body: some View {
        List {
            Section("ماذا يفعل") {
                Text(functionText).font(.callout)
            }
            Section("المسار الكامل") {
                ForEach(pathRows, id: \.label) { row in
                    HStack(alignment: .top) {
                        Text(row.label)
                            .font(.callout)
                            .foregroundColor(.secondary)
                        Spacer()
                        Text(row.value)
                            .font(.callout)
                            .multilineTextAlignment(.leading)
                    }
                }
            }
            Section("حالة التحقق") {
                Text(verificationText)
                    .font(.callout)
                    .foregroundColor(verificationColor)
            }
            if let extraSection {
                extraSection
            }
            Section("الإجراء") {
                Button(actionLabel) { onAction() }
                    .buttonStyle(.borderedProminent)
                    .disabled(!actionEnabled)
                if !actionEnabled, let disabledReason {
                    Text(disabledReason)
                        .font(.caption)
                        .foregroundColor(.orange)
                }
                if let resultMessage {
                    Text(resultMessage)
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
            }
        }
        .navigationTitle(title)
    }
}

// MARK: - Feature lock helpers (single source of truth)
/// سبب قفل ميزة — نص واحد موحد يُستخدم في القائمة وشاشة التفاصيل.
/// nil تعني أن الميزة قابلة للكتابة الآن.
func featureLockReason(feature: Feature, appState: AppState) -> String? {
    if appState.demoMode {
        return "وضع تجريبي — لا كتابة فعلية إطلاقاً. التصفح والقراءة فقط."
    }
    guard let vehicle = appState.vehicle else {
        return "لم تُقرأ السيارة بعد — اتصل بالقطعة واقرأ VIN أولاً."
    }
    if case .unverified(let reason) = feature.status {
        return reason + "\n\nيحتاج قراءة As-Built الفعلي من السيارة قبل الكتابة — لا تُكتب أي قيمة تخمينية."
    }
    if !PlatformSupport.isFeatureWritable(feature: feature, platform: vehicle.platform) {
        return PlatformSupport.disabledReason(feature: feature, platform: vehicle.platform)
    }
    if !appState.safety.canWrite {
        return "لم يكتمل فحص السلامة بعد — أكمل الفحوصات في شاشة السلامة والنسخة الاحتياطية: اتصال + نسخة احتياطية + بطارية فوق 12V + سرعة 0 + قطعة موصى بها."
    }
    return nil
}

/// هل يُعرض Toggle قابل للكتابة لهذه الميزة؟
func featureCanToggle(feature: Feature, appState: AppState) -> Bool {
    guard !appState.demoMode, let vehicle = appState.vehicle else { return false }
    return PlatformSupport.isFeatureWritable(feature: feature, platform: vehicle.platform)
        && appState.safety.canWrite
}

// MARK: - FeatureDetailView
/// شاشة تفاصيل ميزة واحدة: وظيفتها، مسارها الكامل (وحدة + عنوان + قيمة حالية
/// + قيمة مطلوبة للموثق فقط + مصدر)، حالة التحقق، وزر "تفعيل" / "إلغاء".
/// القيم المعروضة من FeatureDatabase فقط — لا قيمة مخترعة.
struct FeatureDetailView: View {
    @EnvironmentObject var appState: AppState
    let feature: Feature
    let onEnabledChanged: (Bool) -> Void
    @State private var isOn: Bool
    @State private var resultMessage: String?
    @State private var alertMessage: String?
    @State private var showAlert = false
    @State private var showConflict = false
    @State private var conflictText = ""

    init(feature: Feature, isOn: Bool, onEnabledChanged: @escaping (Bool) -> Void) {
        self.feature = feature
        self.onEnabledChanged = onEnabledChanged
        _isOn = State(initialValue: isOn)
    }

    var body: some View {
        DetailScaffold(
            title: feature.titleAr,
            iconName: "slider.horizontal.3",
            functionText: feature.descriptionAr,
            pathRows: featurePathRows,
            verificationText: verificationText,
            verificationColor: verificationColor,
            actionLabel: actionLabel,
            actionEnabled: actionEnabled,
            disabledReason: disabledReason,
            onAction: { performAction() },
            resultMessage: $resultMessage
        )
        .alert("تنبيه", isPresented: $showAlert) {
            Button("فهمت", role: .cancel) {}
        } message: {
            Text(alertMessage ?? "")
        }
        .alert("تعارض مسجل", isPresented: $showConflict) {
            Button("متابعة") { apply(true) }
            Button("إلغاء", role: .cancel) {}
        } message: {
            Text(conflictText)
        }
    }

    /// صفوف المسار: الوحدة، العنوان، القيمة الحالية، القيمة المطلوبة، المصدر.
    /// القيمة المطلوبة تُعرض فقط للموثق/الجزئي من البيانات الموجودة أصلاً.
    private var featurePathRows: [(label: String, value: String)] {
        var rows: [(label: String, value: String)] = [
            ("الوحدة", "\(feature.module.arabicName) (\(feature.module.rawValue))"),
            ("العنوان", addressText),
            ("القيمة الحالية", "لم تُقرأ بعد — تُقرأ من As-Built الفعلي للسيارة عند الفحص"),
            ("القيمة المطلوبة", requiredValueText),
            ("المصدر", feature.source),
        ]
        if let condition = feature.conditionAr {
            rows.append(("الشرط", condition))
        }
        if let warning = feature.warningAr {
            rows.append(("تحذير", warning))
        }
        return rows
    }

    private var addressText: String {
        switch feature.change {
        case .nibbleChange(let address, _, _, _, _), .bitChange(let address, _, _, _):
            return address
        case .plainEnglishSetting(let mod, let settingName, _, _):
            return "\(mod.rawValue) Configuration — «\(settingName)»"
        case .noneUnverified:
            return "لا يوجد عنوان موثوق"
        }
    }

    private var requiredValueText: String {
        switch feature.change {
        case .nibbleChange(_, _, _, let onNibble, let offNibble):
            return "التفعيل: \(onNibble)، الإيقاف: \(offNibble)"
        case .bitChange(_, _, _, let bit):
            return "تفعيل البت \(bit) عند التفعيل، ومسحه عند الإيقاف (يُدمج مع البتات الحالية)"
        case .plainEnglishSetting(_, _, let onValue, let offValue):
            return "التفعيل: \(onValue)، الإيقاف: \(offValue)"
        case .noneUnverified:
            return "بلا قيمة موثقة — لا تُكتب أي قيمة تخمينية"
        }
    }

    private var verificationText: String {
        switch feature.status {
        case .verified:
            return "✅ مؤكد — كود موثق في أكثر من مصدر موثوق لـ SYNC 4."
        case .partiallyVerified(let conflict):
            return "⚠️ مؤكد جزئياً — \(conflict)"
        case .unverified(let reason):
            return "❌ غير مؤكد — \(reason)"
        }
    }

    private var verificationColor: Color {
        switch feature.status {
        case .verified: return .green
        case .partiallyVerified: return .orange
        case .unverified: return .red
        }
    }

    /// زر الإجراء: "تفعيل"/"إلغاء" للقابل للكتابة، و"قراءة" (معطل) لغير المؤكد.
    private var actionLabel: String {
        if !feature.isWritable { return "قراءة" }
        return isOn ? "إلغاء" : "تفعيل"
    }

    private var actionEnabled: Bool {
        if !feature.isWritable { return false }
        return featureCanToggle(feature: feature, appState: appState)
    }

    private var disabledReason: String? {
        if !feature.isWritable {
            return "قراءة فقط — \(feature.pathAr). لا تُكتب أي قيمة تخمينية."
        }
        return featureLockReason(feature: feature, appState: appState)
    }

    private func performAction() {
        let newValue = !isOn
        if newValue {
            do {
                try appState.safetyService.checkBeforeWrite(feature: feature, report: appState.safety, vehicle: appState.vehicle)
            } catch {
                alertMessage = error.localizedDescription
                showAlert = true
                return
            }
            if case .partiallyVerified(let conflict) = feature.status {
                conflictText = conflict + "\n\nهذه القيمة مؤكدة لموديل فورد آخر وليست مؤكدة مباشرة لمنصة هذه السيارة. اقرأ BdyCM / IPC الفعلي للسيارة أولاً وتأكد من مطابقة السطر الحالي للنمط المتوقع قبل أي كتابة."
                showConflict = true
                return
            }
        }
        apply(newValue)
    }

    private func apply(_ newValue: Bool) {
        isOn = newValue
        onEnabledChanged(newValue)
        resultMessage = newValue
            ? "تم التفعيل — يُنفذ بعد اكتمال فحص السلامة والتحقق بإعادة القراءة."
            : "تم الإلغاء."
        appState.addLog("تغيير الميزة \(feature.id): \(feature.titleAr) → \(newValue ? "تفعيل" : "إيقاف")", level: .info)
    }
}

// MARK: - ModuleDetailView
/// شاشة تفاصيل وحدة واحدة: وظيفتها، عنوان CAN، حالتها، وزر "قراءة".
/// الوحدات للعرض والقراءة فقط — PCM وTCM محظوران من الكتابة نهائياً.
struct ModuleDetailView: View {
    @EnvironmentObject var appState: AppState
    let status: ModuleStatus
    let onStatusUpdated: (ModuleStatus) -> Void
    @State private var currentStatus: ModuleStatus
    @State private var resultMessage: String?
    @State private var isReading = false

    init(status: ModuleStatus, onStatusUpdated: @escaping (ModuleStatus) -> Void) {
        self.status = status
        self.onStatusUpdated = onStatusUpdated
        _currentStatus = State(initialValue: status)
    }

    var body: some View {
        DetailScaffold(
            title: "\(status.module.arabicName) (\(status.module.rawValue))",
            iconName: status.module.iconName,
            functionText: functionText,
            pathRows: [
                ("الوحدة", "\(status.module.arabicName) (\(status.module.rawValue))"),
                ("عنوان CAN", status.module.canID),
                ("الحالة الحالية", currentStatus.found ? "موجودة — ظهرت في الفحص" : "لم تُفحص بعد / لم ترد"),
                ("عدد الأعطال", "\(currentStatus.dtcCount)"),
                ("الكتابة", status.module.writeBanReason ?? "مسموحة بشروط السلامة والنسخة الاحتياطية"),
            ],
            verificationText: status.module.writeBanReason ?? "وحدة للقراءة — الكتابة فيها مشروطة بفحص السلامة والنسخة الاحتياطية.",
            verificationColor: status.module.isWritable ? .green : .red,
            actionLabel: isReading ? "جارٍ الفحص…" : "قراءة",
            actionEnabled: appState.connection.isConnected && !appState.demoMode && !isReading,
            disabledReason: disabledReason,
            onAction: { Task { await readModule() } },
            resultMessage: $resultMessage
        )
    }

    private var functionText: String {
        if let ban = status.module.writeBanReason {
            return "وحدة \(status.module.arabicName) (\(status.module.rawValue)) — تظهر هنا للتشخيص والقراءة فقط. \(ban)."
        }
        return "وحدة \(status.module.arabicName) (\(status.module.rawValue)) — تظهر هنا للتشخيص والقراءة. الكتابة فيها مشروطة بفحص السلامة والنسخة الاحتياطية."
    }

    private var disabledReason: String? {
        if appState.demoMode { return "وضع تجريبي — لا قراءة حقيقية بلا قطعة." }
        if !appState.connection.isConnected { return "اتصل بالقطعة أولاً من شاشة الاتصال." }
        return nil
    }

    private func readModule() async {
        isReading = true
        do {
            let found = try await appState.diagnostics.scanModules()
            if let updated = found.first(where: { $0.module == status.module }) {
                currentStatus = updated
                onStatusUpdated(updated)
                resultMessage = updated.found
                    ? "الوحدة موجودة — ظهرت في الفحص."
                    : "الوحدة لم ترد — غير موجودة أو لا تستجيب."
                appState.addLog("فحص الوحدة \(status.module.rawValue): \(updated.found ? "موجودة" : "لم ترد")", level: .info)
            }
        } catch {
            resultMessage = "فشل الفحص: \(error.localizedDescription)"
            appState.addLog("فشل فحص الوحدة \(status.module.rawValue): \(error.localizedDescription)", level: .error)
        }
        isReading = false
    }
}

// MARK: - LiveDataDetailView
/// شاشة تفاصيل خيار بيانات حية: البطارية، السرعة، RPM، الأعطال.
/// قراءة فقط — آمن تماماً، لا يكتب شيئاً في السيارة.
enum LiveDataKind: String {
    case battery = "البطارية والجهد"
    case speed = "السرعة"
    case rpm = "عدد دورات المحرك (RPM)"
    case dtcs = "أكواد الأعطال (DTCs)"
}

struct LiveDataDetailView: View {
    @EnvironmentObject var appState: AppState
    let kind: LiveDataKind
    @State private var valueText: String
    @State private var dtcs: [DTC]
    @State private var resultMessage: String?
    @State private var isReading = false

    init(kind: LiveDataKind, initialValue: String, dtcs: [DTC] = []) {
        self.kind = kind
        _valueText = State(initialValue: initialValue)
        _dtcs = State(initialValue: dtcs)
    }

    var body: some View {
        DetailScaffold(
            title: kind.rawValue,
            iconName: "waveform.path.ecg",
            functionText: functionText,
            pathRows: pathRows,
            verificationText: "قراءة فقط — آمن تماماً، لا يكتب شيئاً في السيارة.",
            verificationColor: .green,
            actionLabel: isReading ? "جارٍ القراءة…" : "قراءة",
            actionEnabled: appState.connection.isConnected && !appState.demoMode && !isReading,
            disabledReason: disabledReason,
            onAction: { Task { await read() } },
            resultMessage: $resultMessage,
            extraSection: kind == .dtcs ? AnyView(dtcSection) : nil
        )
    }

    private var functionText: String {
        switch kind {
        case .battery:
            return "جهد بطارية السيارة — يجب أن يكون فوق 12.0V قبل أي كتابة."
        case .speed:
            return "سرعة السيارة الحالية — يجب أن تكون 0 قبل أي كتابة (لا كتابة أثناء القيادة)."
        case .rpm:
            return "عدد دورات المحرك في الدقيقة — للعرض فقط."
        case .dtcs:
            return "أكواد الأعطال المخزنة — Mode 03 يقرأ أعطال المحرك فقط؛ أعطال الوحدات الأخرى تتطلب أوامر خاصة بكل وحدة."
        }
    }

    private var pathRows: [(label: String, value: String)] {
        switch kind {
        case .battery:
            return [("المسار", "أمر ATRV (قراءة الجهد)"), ("القيمة الحالية", valueText), ("المطلوب للكتابة", "فوق 12.0V")]
        case .speed:
            return [("المسار", "PID 0D"), ("القيمة الحالية", valueText), ("المطلوب للكتابة", "0 كم/س")]
        case .rpm:
            return [("المسار", "PID 0C"), ("القيمة الحالية", valueText), ("ملاحظة", "التحليل الكامل يُختبر على السيارة")]
        case .dtcs:
            return [("المسار", "Mode 03"), ("القيمة الحالية", valueText), ("عدد الأعطال", "\(dtcs.count)")]
        }
    }

    private var dtcSection: some View {
        Section("الأعطال") {
            if dtcs.isEmpty {
                Text("لا توجد أعطال مقروءة بعد — أو لا توجد أعطال في السيارة.")
                    .font(.caption)
            } else {
                ForEach(dtcs) { dtc in
                    VStack(alignment: .leading) {
                        Text(dtc.displayString).font(.headline).monospaced()
                        Text("\(dtc.module.rawValue) — \(dtc.descriptionAr)").font(.caption)
                    }
                }
            }
        }
    }

    private var disabledReason: String? {
        if appState.demoMode { return "وضع تجريبي — لا قراءة حقيقية بلا قطعة." }
        if !appState.connection.isConnected { return "اتصل بالقطعة أولاً من شاشة الاتصال." }
        return nil
    }

    private func read() async {
        isReading = true
        do {
            switch kind {
            case .battery:
                let v = try await appState.diagnostics.readBatteryVoltage()
                appState.safety.batteryVoltage = v
                valueText = "\(String(format: "%.1f", v))V"
                resultMessage = v >= 12.0 ? "الجهد كافٍ للكتابة." : "الجهد أقل من 12.0V — اشحن البطارية قبل أي كتابة."
            case .speed:
                let s = try await appState.diagnostics.readSpeedKmh()
                appState.safety.speedKmh = s
                valueText = "\(String(format: "%.0f", s)) كم/س"
                resultMessage = s == 0 ? "السيارة متوقفة." : "السيارة تتحرك — لا كتابة أثناء القيادة."
            case .rpm:
                let r = try await appState.diagnostics.readRPM()
                valueText = r > 0 ? "\(String(format: "%.0f", r)) RPM" : "0 — التحليل الكامل يُختبر على السيارة"
                resultMessage = nil
            case .dtcs:
                let codes = try await appState.diagnostics.readAllDTCs()
                dtcs = codes
                valueText = codes.isEmpty ? "لا توجد أعطال مقروءة" : "\(codes.count) عطل"
                resultMessage = codes.isEmpty ? "لا توجد أعطال مقروءة بعد — أو لا توجد أعطال في السيارة." : nil
            }
            appState.addLog("قراءة \(kind.rawValue): \(valueText)", level: .info)
        } catch {
            resultMessage = "فشل القراءة: \(error.localizedDescription)"
            appState.addLog("فشل قراءة \(kind.rawValue): \(error.localizedDescription)", level: .error)
        }
        isReading = false
    }
}

// MARK: - SafetyCheckDetailView
/// شاشة تفاصيل فحص سلامة أو نسخة احتياطية أو استرجاع.
/// كل فحص يشرح نفسه وحالته الحالية وما يلزم لاجتيازه، وزر الإجراء المناسب له.
enum SafetyCheckKind: String, CaseIterable {
    case connection = "الاتصال بالقطعة"
    case vin = "التعرف على السيارة من VIN"
    case battery = "البطارية فوق 12.0V"
    case speed = "السيارة متوقفة (السرعة 0)"
    case backup = "نسخة احتياطية محفوظة"
    case adapter = "القطعة موصى بها"
    case restore = "الاسترجاع"

    /// هل هذا الفحص ناجح الآن؟
    func isPassed(appState: AppState) -> Bool {
        switch self {
        case .connection: return appState.connection.isConnected
        case .vin: return appState.safety.vinValidated
        case .battery: return appState.safety.batteryVoltage >= 12.0
        case .speed: return appState.safety.speedKmh == 0
        case .backup: return appState.safety.hasBackup
        case .adapter: return appState.safety.adapterRecommended
        case .restore: return appState.backup != nil
        }
    }
}

struct SafetyCheckDetailView: View {
    @EnvironmentObject var appState: AppState
    let kind: SafetyCheckKind
    @State private var resultMessage: String?
    @State private var isWorking = false

    var body: some View {
        DetailScaffold(
            title: kind.rawValue,
            iconName: "shield.checkered",
            functionText: functionText,
            pathRows: pathRows,
            verificationText: kind.isPassed(appState: appState) ? "✅ ناجح" : "❌ غير مكتمل — \(whatIsNeeded)",
            verificationColor: kind.isPassed(appState: appState) ? .green : .red,
            actionLabel: actionLabel,
            actionEnabled: actionEnabled,
            disabledReason: disabledReason,
            onAction: { Task { await performAction() } },
            resultMessage: $resultMessage
        )
    }

    private var functionText: String {
        switch kind {
        case .connection:
            return "يجب أن تكون القطعة متصلة ومستقرة قبل أي قراءة أو كتابة. الاتصال من شاشة الاتصال (WiFi أولاً)."
        case .vin:
            return "يجب التعرف على السيارة ومنصتها من رقم الشاصي قبل أي كتابة — التطبيق عام ويعرض فقط المزايا الموثقة لمنصة هذه السيارة."
        case .battery:
            return "جهد البطارية يجب أن يكون فوق 12.0V قبل أي كتابة — الجهد المنخفض أثناء الكتابة قد يتلف الوحدة."
        case .speed:
            return "السيارة يجب أن تكون متوقفة تماماً (السرعة 0) — لا كتابة أثناء القيادة أبداً."
        case .backup:
            return "نسخة احتياطية كاملة من أسطر As-Built الحالية قبل أول تغيير — تُحفظ محلياً على الآيفون فقط، وتُستخدم للاسترجاع بضغطة واحدة."
        case .adapter:
            return "القطعة يجب أن تكون موصى بها — vLinker FS أولاً، ثم OBDLink MX+، ثم WiFi ELM327 الأصلي. ELM327 v1.5 الرخيص غير موصى به."
        case .restore:
            return "إعادة كل القيم إلى النسخة الاحتياطية المحفوظة قبل أول تغيير — بضغطة واحدة."
        }
    }

    private var pathRows: [(label: String, value: String)] {
        switch kind {
        case .connection:
            return [("الحالة الحالية", appState.connection.isConnected ? "متصل" : "غير متصل"), ("المطلوب", "اتصال مستقر بالقطعة")]
        case .vin:
            return [("الحالة الحالية", appState.vehicle.map { "\($0.modelName) \($0.modelYear) — VIN: \($0.vin)" } ?? "لم تُقرأ السيارة بعد"), ("المطلوب", "قراءة VIN من شاشة السيارة")]
        case .battery:
            return [("القيمة الحالية", "\(String(format: "%.1f", appState.safety.batteryVoltage))V"), ("المطلوب", "فوق 12.0V"), ("المسار", "أمر ATRV")]
        case .speed:
            return [("القيمة الحالية", "\(String(format: "%.0f", appState.safety.speedKmh)) كم/س"), ("المطلوب", "0 كم/س"), ("المسار", "PID 0D")]
        case .backup:
            return [("الحالة الحالية", appState.backup.map { "نسخة محفوظة بتاريخ \($0.date.formatted(date: .abbreviated, time: .omitted)) — VIN: \($0.vin)" } ?? "لا توجد نسخة محفوظة"), ("المطلوب", "نسخة احتياطية قبل أول كتابة")]
        case .adapter:
            return [("الحالة الحالية", appState.safety.adapterRecommended ? "قطعة موصى بها" : "غير محددة بعد / غير موصى بها"), ("المطلوب", "vLinker FS أو OBDLink MX+ أو WiFi ELM327 أصلي")]
        case .restore:
            return [("الحالة الحالية", appState.backup.map { "نسخة محفوظة بتاريخ \($0.date.formatted(date: .abbreviated, time: .omitted))" } ?? "لا توجد نسخة للاسترجاع"), ("المطلوب", "نسخة احتياطية محفوظة أولاً")]
        }
    }

    private var whatIsNeeded: String {
        switch kind {
        case .connection: return "اتصل بالقطعة من شاشة الاتصال"
        case .vin: return "اقرأ السيارة من شاشة السيارة"
        case .battery: return "اقرأ الجهد — يجب أن يكون فوق 12.0V"
        case .speed: return "أوقف السيارة تماماً"
        case .backup: return "أنشئ نسخة احتياطية أولاً"
        case .adapter: return "اتصل بقطعة موصى بها (vLinker FS)"
        case .restore: return "لا توجد نسخة احتياطية محفوظة بعد"
        }
    }

    private var actionLabel: String {
        switch kind {
        case .battery, .speed: return isWorking ? "جارٍ القراءة…" : "قراءة الآن"
        case .backup: return isWorking ? "جارٍ إنشاء النسخة…" : "إنشاء نسخة احتياطية"
        case .restore: return isWorking ? "جارٍ الاسترجاع…" : "استرجاع"
        default: return "قراءة"
        }
    }

    private var actionEnabled: Bool {
        if isWorking { return false }
        switch kind {
        case .battery, .speed:
            return appState.connection.isConnected && !appState.demoMode
        case .backup:
            return appState.vehicle != nil && !appState.demoMode
        case .restore:
            return appState.backup != nil && !appState.demoMode
        default:
            return false
        }
    }

    private var disabledReason: String? {
        if appState.demoMode { return "وضع تجريبي — لا إجراء حقيقي بلا سيارة متصلة." }
        switch kind {
        case .battery, .speed:
            return appState.connection.isConnected ? nil : "اتصل بالقطعة أولاً من شاشة الاتصال."
        case .backup:
            return appState.vehicle == nil ? "بلا سيارة متصلة — اتصل بالقطعة واقرأ VIN أولاً." : nil
        case .restore:
            return appState.backup == nil ? "لا توجد نسخة احتياطية محفوظة بعد." : nil
        case .connection:
            return "اتصل بالقطعة من شاشة الاتصال."
        case .vin:
            return "اقرأ السيارة من شاشة السيارة."
        case .adapter:
            return "تُحدد بعد الاتصال — القطعة الموصى بها أولاً vLinker FS."
        }
    }

    private func performAction() async {
        isWorking = true
        defer { isWorking = false }
        switch kind {
        case .battery:
            do {
                let v = try await appState.diagnostics.readBatteryVoltage()
                appState.safety.batteryVoltage = v
                resultMessage = v >= 12.0 ? "الجهد \(String(format: "%.1f", v))V — كافٍ للكتابة." : "الجهد \(String(format: "%.1f", v))V — أقل من 12.0V."
            } catch {
                resultMessage = "فشل القراءة: \(error.localizedDescription)"
            }
        case .speed:
            do {
                let s = try await appState.diagnostics.readSpeedKmh()
                appState.safety.speedKmh = s
                resultMessage = s == 0 ? "السيارة متوقفة." : "السرعة \(String(format: "%.0f", s)) كم/س — أوقف السيارة."
            } catch {
                resultMessage = "فشل القراءة: \(error.localizedDescription)"
            }
        case .backup:
            do {
                _ = try await appState.createBackup()
                resultMessage = "تم حفظ النسخة الاحتياطية."
            } catch {
                resultMessage = "فشل إنشاء النسخة: \(error.localizedDescription)"
                appState.addLog("فشل النسخة الاحتياطية: \(error.localizedDescription)", level: .error)
            }
        case .restore:
            guard let backup = appState.backup else {
                resultMessage = "لا توجد نسخة احتياطية محفوظة بعد."
                return
            }
            do {
                try await appState.safetyService.restore(backup: backup, elm327: appState.elm327)
                resultMessage = "تم الاسترجاع إلى النسخة الاحتياطية."
            } catch {
                resultMessage = "تعذر الاسترجاع: \(error.localizedDescription)"
                appState.addLog("فشل الاسترجاع: \(error.localizedDescription)", level: .error)
            }
        default:
            resultMessage = nil
        }
    }
}
