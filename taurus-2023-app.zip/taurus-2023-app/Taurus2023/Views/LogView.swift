import SwiftUI

// MARK: - LogView
/// سجل العمليات — كل قراءة وكتابة وتنبيه، مع الوقت.
struct LogView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        List(appState.log) { entry in
            HStack {
                Text(icon(for: entry.level))
                VStack(alignment: .leading) {
                    Text(entry.message).font(.callout)
                    Text(entry.date, style: .time).font(.caption).foregroundColor(.secondary)
                }
            }
        }
        .navigationTitle("السجل")
        .toolbar {
            Button("مسح") { appState.log.removeAll() }
        }
    }

    private func icon(for level: LogLevel) -> String {
        switch level {
        case .info: return "ℹ️"
        case .warning: return "⚠️"
        case .error: return "❌"
        case .success: return "✅"
        }
    }
}
