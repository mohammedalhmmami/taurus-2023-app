import SwiftUI

// MARK: - DiagnosticsView
/// التشخيص: البطارية، السرعة، RPM، الأعطال — كل خيار بمساره الصحيح.
/// الضغط على أي خيار يفتح شاشة تفاصيله (القيمة + المسار + زر قراءة).
/// قراءة فقط — آمن تماماً.
struct DiagnosticsView: View {
    @EnvironmentObject var appState: AppState
    @State private var dtcs: [DTC] = []
    @State private var voltage: Double = 0
    @State private var speed: Double = 0
    @State private var rpm: Double = 0
    @State private var message: String?

    var body: some View {
        List {
            Section("البيانات الحية — قراءة فقط") {
                NavigationLink {
                    LiveDataDetailView(kind: .battery, initialValue: voltageText)
                } label: {
                    liveRow(title: "البطارية والجهد", value: voltageText, path: "أمر ATRV")
                }
                NavigationLink {
                    LiveDataDetailView(kind: .speed, initialValue: speedText)
                } label: {
                    liveRow(title: "السرعة", value: speedText, path: "PID 0D")
                }
                NavigationLink {
                    LiveDataDetailView(kind: .rpm, initialValue: rpmText)
                } label: {
                    liveRow(title: "عدد دورات المحرك (RPM)", value: rpmText, path: "PID 0C")
                }
            }

            Section("أكواد الأعطال (DTCs)") {
                NavigationLink {
                    LiveDataDetailView(kind: .dtcs, initialValue: dtcText, dtcs: dtcs)
                } label: {
                    liveRow(title: "أكواد الأعطال", value: dtcText, path: "Mode 03")
                }
                if dtcs.isEmpty {
                    Text("لا توجد أعطال مقروءة بعد — أو لا توجد أعطال في السيارة.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                } else {
                    ForEach(dtcs) { dtc in
                        VStack(alignment: .leading) {
                            Text(dtc.displayString).font(.headline).monospaced()
                            Text("\(dtc.module.rawValue) — \(dtc.descriptionAr)").font(.caption)
                        }
                    }
                }
            }

            Section("فحص كامل") {
                Button("تشغيل الفحص الكامل") {
                    Task { await runDiagnostics() }
                }
                .buttonStyle(.borderedProminent)
                .disabled(!appState.connection.isConnected || appState.demoMode)
                if appState.demoMode {
                    Text("وضع تجريبي — لا فحص حقيقي بلا قطعة.")
                        .font(.caption)
                        .foregroundColor(.red)
                } else if !appState.connection.isConnected {
                    Text("اتصل بالقطعة أولاً من شاشة الاتصال.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                if let message { Text(message).font(.caption).foregroundColor(.secondary) }
            }
        }
        .navigationTitle("التشخيص")
    }

    /// صف خيار بيانات حية: الاسم + القيمة + المسار.
    private func liveRow(title: String, value: String, path: String) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.headline).foregroundColor(.primary)
                Text("المسار: \(path)").font(.caption).foregroundColor(.secondary)
            }
            Spacer()
            Text(value).font(.callout).foregroundColor(.secondary)
        }
    }

    private var voltageText: String {
        voltage > 0 ? "\(String(format: "%.1f", voltage))V" : "لم تُقرأ بعد"
    }
    private var speedText: String {
        "\(String(format: "%.0f", speed)) كم/س"
    }
    private var rpmText: String {
        rpm > 0 ? "\(String(format: "%.0f", rpm)) RPM" : "لم تُقرأ بعد"
    }
    private var dtcText: String {
        dtcs.isEmpty ? "لا توجد أعطال مقروءة" : "\(dtcs.count) عطل"
    }

    private func runDiagnostics() async {
        do {
            let v = try await appState.diagnostics.readBatteryVoltage()
            let s = try await appState.diagnostics.readSpeedKmh()
            let r = try await appState.diagnostics.readRPM()
            let codes = try await appState.diagnostics.readAllDTCs()
            await MainActor.run {
                voltage = v; speed = s; rpm = r; dtcs = codes
                appState.safety.batteryVoltage = v
                appState.safety.speedKmh = s
                appState.addLog("فحص: جهد \(String(format: "%.1f", v))V، سرعة \(s) كم/س، أعطال \(codes.count)", level: .info)
            }
        } catch {
            await MainActor.run {
                message = error.localizedDescription
                appState.addLog("فشل الفحص: \(error.localizedDescription)", level: .error)
            }
        }
    }
}
