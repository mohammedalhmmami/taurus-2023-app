import SwiftUI

// MARK: - DiagnosticsView
/// التشخيص: VIN، الوحدات، الأعطال، البيانات الحية، البطارية.
/// قراءة فقط — آمن تماماً.
struct DiagnosticsView: View {
    @EnvironmentObject var appState: AppState
    @State private var dtcs: [DTC] = []
    @State private var voltage: Double = 0
    @State private var speed: Double = 0
    @State private var message: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                GroupBox("البطارية والجهد") {
                    Text(voltage > 0 ? "الجهد: \(String(format: "%.1f", voltage))V" : "لم تُقرأ بعد")
                    Text(voltage >= 12.0 ? "✅ الجهد كافٍ للكتابة" : "⚠️ الجهد يجب أن يكون فوق 12.0V قبل أي كتابة")
                        .font(.caption)
                        .foregroundColor(voltage >= 12.0 ? .green : .orange)
                }
                GroupBox("السرعة") {
                    Text("السرعة: \(String(format: "%.0f", speed)) كم/س")
                    Text(speed == 0 ? "✅ السيارة متوقفة" : "⛔ لا كتابة أثناء القيادة")
                        .font(.caption)
                        .foregroundColor(speed == 0 ? .green : .red)
                }
                GroupBox("أكواد الأعطال (DTCs)") {
                    if dtcs.isEmpty {
                        Text("لا توجد أعطال مقروءة بعد — أو لا توجد أعطال في السيارة.")
                            .font(.caption)
                    } else {
                        ForEach(dtcs) { dtc in
                            VStack(alignment: .leading) {
                                Text(dtc.displayString).font(.headline).monospaced()
                                Text("\(dtc.module.rawValue) — \(dtc.descriptionAr)").font(.caption)
                            }
                        }
                    }
                }
                Button("تشغيل الفحص الكامل") {
                    Task { await runDiagnostics() }
                }
                .buttonStyle(.borderedProminent)
                .disabled(!appState.connection.isConnected)
                if let message { Text(message).font(.caption).foregroundColor(.secondary) }
            }
            .padding()
        }
        .navigationTitle("التشخيص")
    }

    private func runDiagnostics() async {
        do {
            let v = try await appState.diagnostics.readBatteryVoltage()
            let s = try await appState.diagnostics.readSpeedKmh()
            let codes = try await appState.diagnostics.readAllDTCs()
            await MainActor.run {
                voltage = v; speed = s; dtcs = codes
                appState.safety.batteryVoltage = v
                appState.safety.speedKmh = s
                appState.addLog("فحص: جهد \(String(format: "%.1f", v))V، سرعة \(s) كم/س، أعطال \(codes.count)", level: .info)
            }
        } catch {
            await MainActor.run {
                message = error.localizedDescription
                appState.addLog("فشل الفحص: \(error.localizedDescription)", level: .error)
            }
        }
    }
}
