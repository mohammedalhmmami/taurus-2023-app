import SwiftUI

// MARK: - VehicleView
/// شاشة السيارة / التعرف — قراءة VIN والتعرف التلقائي على السيارة ومنصتها.
/// زر "قراءة السيارة" يعرض الخطأ في بطاقة واضحة (وليس سطراً صغيراً).
/// في الوضع التجريبي تُعرض بيانات السيارة التجريبية مع تنبيه صريح أنها ليست حقيقية.
struct VehicleView: View {
    @EnvironmentObject var appState: AppState
    @State private var syncVersion = "SYNC 4"
    @State private var errorMessage: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if appState.demoMode {
                    Text("هذه بيانات تجريبية — VIN تجريبي وليس سيارة حقيقية، ولا يُستخدم في أي كود.")
                        .font(.callout)
                        .foregroundColor(.orange)
                }

                // بطاقة السيارة.
                GroupBox("تم التعرف على السيارة") {
                    if let vehicle = appState.vehicle {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("\(vehicle.modelName) \(vehicle.modelYear)").font(.title2).bold()
                            Text("المنصة: \(vehicle.platform.arabicName)").font(.caption)
                            Text("رقم الشاصي: \(vehicle.vin)").font(.caption).monospaced()
                            Text("\(vehicle.syncVersion) — \(vehicle.engine)").font(.caption)
                            Text("الفئة: \(vehicle.trim.rawValue)").font(.caption)
                            Text(PlatformSupport.platformNote(for: vehicle.platform, confidence: vehicle.platformConfidence))
                                .font(.caption).foregroundColor(.orange)
                        }
                    } else {
                        Text("لم تُقرأ السيارة بعد — اتصل بالقطعة واقرأ VIN أولاً.")
                            .font(.callout)
                        TextField("إصدار SYNC (مثال: SYNC 4)", text: $syncVersion)
                            .textFieldStyle(.roundedBorder)
                        Button("قراءة السيارة (VIN)") {
                            Task { await readVehicle() }
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(!appState.connection.isConnected || appState.demoMode)
                        if appState.demoMode {
                            Text("وضع تجريبي — لا قراءة حقيقية بلا اتصال.")
                                .font(.caption).foregroundColor(.red)
                        } else if !appState.connection.isConnected {
                            Text("اتصل بالقطعة أولاً من شاشة الاتصال.")
                                .font(.caption).foregroundColor(.secondary)
                        }
                    }
                }

                // بطاقة الخطأ الواضحة — بدل سطر صغير.
                if let errorMessage {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("تعذر التعرف على السيارة").font(.headline).foregroundColor(.red)
                        Text(errorMessage).font(.callout)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.red.opacity(0.12))
                    .cornerRadius(12)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.red.opacity(0.5)))
                }
            }
            .padding()
        }
        .navigationTitle("السيارة")
    }

    private func readVehicle() async {
        do {
            let vehicle = try await appState.diagnostics.identifyVehicle(syncVersion: syncVersion)
            await MainActor.run {
                appState.vehicle = vehicle
                appState.safety.vinValidated = true
                errorMessage = nil
                appState.addLog("تم التعرف على السيارة: \(vehicle.modelName) \(vehicle.modelYear) — المنصة: \(vehicle.platform.arabicName) — VIN: \(vehicle.vin)", level: .success)
            }
        } catch {
            await MainActor.run {
                errorMessage = error.localizedDescription
                appState.addLog("فشل التعرف على السيارة: \(error.localizedDescription)", level: .error)
            }
        }
    }
}
