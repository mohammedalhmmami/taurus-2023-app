import SwiftUI

// MARK: - ConnectionView
/// شاشة الاتصال بالقطعة — الطريقة الوحيدة للاتصال في التطبيق.
///  - WiFi: حقلا host/port بقيم افتراضية قابلة للتعديل، وزر "اتصال" ينشئ
///    WiFiTransport ويستدعي connect ثم elm327.initialize، ويحدّث
///    appState.connection، ويعرض حالة الاتصال والخطأ بوضوح.
///  - Bluetooth LE: يعرض صراحة أنه يحتاج اختبار قطعة vLinker FS الفعلية
///    لمعرفة UUIDs الخدمة — لا تُخترع UUIDs هنا — وزر الفحص معطل مع السبب.
///  - الوضع التجريبي: تصفح بلا سيارة ولا قطعة.
struct ConnectionView: View {
    @EnvironmentObject var appState: AppState
    @State private var host = "192.168.0.10"
    @State private var portText = "35000"
    @State private var isConnecting = false
    @State private var errorMessage: String?

    var body: some View {
        List {
            // WiFi.
            Section("WiFi — ELM327") {
                TextField("العنوان (Host)", text: $host)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                TextField("المنفذ (Port)", text: $portText)
                    .keyboardType(.numberPad)
                Text("الافتراضي: 192.168.0.10:35000 — غيّرهما إن كانت قطعتك على عنوان آخر.")
                    .font(.caption)
                    .foregroundColor(.secondary)
                if appState.connection.isConnected {
                    if case .connected(let adapter) = appState.connection {
                        Text("متصل: \(adapter.name) — \(adapter.transport.rawValue)")
                            .font(.callout)
                            .foregroundColor(.green)
                        if let warning = adapter.warningAr {
                            Text(warning).font(.caption).foregroundColor(.orange)
                        }
                    }
                    Button("قطع الاتصال", role: .destructive) {
                        appState.disconnect()
                    }
                } else {
                    Button(isConnecting ? "جارٍ الاتصال…" : "اتصال") {
                        Task { await connect() }
                    }
                    .disabled(isConnecting || appState.demoMode)
                    if appState.demoMode {
                        Text("وضع تجريبي — اخرج منه أولاً للاتصال بقطعة حقيقية.")
                            .font(.caption)
                            .foregroundColor(.red)
                    }
                }
                if case .failed(let message) = appState.connection {
                    Text("فشل الاتصال: \(message)")
                        .font(.callout)
                        .foregroundColor(.red)
                }
                if case .connecting = appState.connection {
                    Text("جارٍ الاتصال بالقطعة…").font(.callout).foregroundColor(.secondary)
                }
                if let errorMessage {
                    Text(errorMessage).font(.callout).foregroundColor(.red)
                }
            }

            // Bluetooth LE.
            Section("Bluetooth LE") {
                Text("البلوتوث يحتاج اختبار قطعة vLinker FS الفعلية لمعرفة UUIDs الخدمة والخصائص — لا تُخترع UUIDs هنا. حتى يُختبر، الفحص عبر Bluetooth معطل.")
                    .font(.callout)
                Button("فحص أجهزة Bluetooth") {}
                    .disabled(true)
                Text("معطل: UUIDs الخدمة غير معروفة بعد — تُقرأ من القطعة الفعلية عند الاختبار.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            // الوضع التجريبي.
            Section("وضع تجريبي") {
                Text("تصفح التطبيق وقراءة المزايا بلا سيارة ولا قطعة. لا اتصال ولا كتابة فعلية إطلاقاً.")
                    .font(.callout)
                if appState.demoMode {
                    Button("خروج من الوضع التجريبي") {
                        appState.exitDemoMode()
                    }
                } else {
                    Button("تصفح تجريبي بلا سيارة") {
                        appState.enableDemoMode()
                    }
                    .disabled(appState.connection.isConnected)
                    if appState.connection.isConnected {
                        Text("متصل بقطعة — اقطع الاتصال أولاً للتصفح التجريبي.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }

            // القطع الموصى بها.
            Section("القطع الموصى بها") {
                Text("1. vLinker FS — 2. OBDLink MX+ — 3. WiFi ELM327 الأصلي. ELM327 v1.5 الرخيص غير موصى به (FORScan: NOT recommended).")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .navigationTitle("الاتصال بالقطعة")
    }

    private func connect() async {
        guard let port = UInt16(portText), !host.isEmpty else {
            errorMessage = "العنوان أو المنفذ غير صالح — مثال: 192.168.0.10:35000"
            return
        }
        errorMessage = nil
        isConnecting = true
        await appState.connectWiFi(host: host, port: port)
        isConnecting = false
    }
}
