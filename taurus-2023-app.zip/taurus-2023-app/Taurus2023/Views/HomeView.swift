import SwiftUI

// MARK: - HomeView
/// الشاشة الرئيسية — شبكة أيقونات كبيرة (Grid) بأسلوب اللقطة:
/// خلفية سوداء، عنوان ذهبي "فورد OBD"، بطاقة داكنة للحالة
/// ("برمجة فورد / لم تُقرأ السيارة بعد / غير متصل" بالأحمر،
/// وتتحول إلى "متصل" بالأخضر بعد الاتصال)، ثم شبكة أيقونات
/// ذهبية مع الاسم تحت كل أيقونة ونص حالة صغير تحت الاسم.
/// الضغط على أي أيقونة يفتح شاشتها (NavigationLink يعمل).
struct HomeView: View {
    @EnvironmentObject var appState: AppState
    private let columns = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16)
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // بطاقة الحالة — مثل اللقطة تماماً.
                VStack(alignment: .leading, spacing: 6) {
                    Text("برمجة فورد")
                        .font(.title3)
                        .bold()
                        .foregroundColor(.gold)
                    if let vehicle = appState.vehicle {
                        Text("\(vehicle.modelName) \(vehicle.modelYear)")
                            .font(.callout)
                            .foregroundColor(.secondary)
                        Text("VIN: \(vehicle.vin)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .monospaced()
                    } else {
                        Text("لم تُقرأ السيارة بعد")
                            .font(.callout)
                            .foregroundColor(.secondary)
                    }
                    connectionLine
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color(white: 0.12))
                .cornerRadius(20)

                // شبكة الأيقونات.
                LazyVGrid(columns: columns, spacing: 16) {
                    ForEach(HomeDestination.allCases) { dest in
                        NavigationLink(value: dest) {
                            gridCell(for: dest)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding()
        }
        .navigationTitle("فورد OBD")
        .navigationDestination(for: HomeDestination.self) { dest in
            switch dest {
            case .connection: ConnectionView()
            case .vehicle: VehicleView()
            case .features: FeaturesView()
            case .modules: ModulesView()
            case .diagnostics: DiagnosticsView()
            case .safety: SafetyReportView()
            case .log: LogView()
            case .programmerTools: ProgrammerToolsView()
            }
        }
    }

    /// سطر حالة الاتصال في البطاقة — أحمر "غير متصل"، أخضر "متصل".
    private var connectionLine: some View {
        Group {
            if appState.demoMode {
                Text("وضع تجريبي").font(.callout).foregroundColor(.orange)
            } else if appState.connection.isConnected {
                Text("● متصل").font(.callout).foregroundColor(.green)
            } else {
                Text("○ غير متصل").font(.callout).foregroundColor(.red)
            }
        }
    }

    /// خلية أيقونة واحدة: أيقونة ذهبية كبيرة + الاسم + نص حالة صغير بنقطة لون.
    private func gridCell(for dest: HomeDestination) -> some View {
        VStack(spacing: 10) {
            Image(systemName: dest.iconName)
                .font(.system(size: 38))
                .foregroundColor(.gold)
            Text(dest.rawValue)
                .font(.headline)
                .foregroundColor(.primary)
                .multilineTextAlignment(.center)
            Text(statusText(for: dest))
                .font(.caption)
                .foregroundColor(statusColor(for: dest))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, minHeight: 130)
        .padding(.vertical, 12)
        .background(Color(white: 0.10))
        .cornerRadius(18)
    }

    /// نص الحالة تحت كل أيقونة.
    private func statusText(for dest: HomeDestination) -> String {
        switch dest {
        case .connection:
            if appState.demoMode { return "وضع تجريبي" }
            return appState.connection.isConnected ? "● متصل" : "○ غير متصل"
        case .vehicle:
            if let vehicle = appState.vehicle { return "\(vehicle.modelName) \(vehicle.modelYear)" }
            return "لم تُقرأ بعد"
        case .features:
            return "18 ميزة"
        case .modules:
            return "13 وحدة — قراءة فقط"
        case .diagnostics:
            return "أعطال وبيانات حية"
        case .safety:
            return appState.safety.canWrite ? "الكتابة مسموحة" : "الكتابة مقفلة"
        case .log:
            return "\(appState.log.count) سطر"
        case .programmerTools:
            return "معلومات فقط"
        }
    }

    /// لون نص الحالة تحت كل أيقونة.
    private func statusColor(for dest: HomeDestination) -> Color {
        switch dest {
        case .connection:
            if appState.demoMode { return .orange }
            return appState.connection.isConnected ? .green : .red
        case .vehicle:
            return appState.vehicle == nil ? .secondary : .green
        case .safety:
            return appState.safety.canWrite ? .green : .orange
        default:
            return .secondary
        }
    }
}
