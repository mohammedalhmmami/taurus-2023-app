import SwiftUI

// MARK: - HomeView
/// الرئيسية: التعرف على السيارة، حالة OBD، زر النسخة الاحتياطية.
struct HomeView: View {
    @EnvironmentObject var appState: AppState
    @State private var syncVersion = "SYNC 4"
    @State private var message: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                // بطاقة السيارة.
                GroupBox("تم التعرف على السيارة") {
                    if let vehicle = appState.vehicle {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("فورد تورس 2023").font(.title2).bold()
                            Text("رقم الشاصي: \(vehicle.vin)").font(.caption).monospaced()
                            Text("SYNC 4 — شاشة 13.2 بوصة — 2.0 EcoBoost").font(.caption)
                            Text("الفئة: \(vehicle.trim.rawValue)").font(.caption)
                        }
                    } else {
                        Text("لم تُقرأ السيارة بعد — اتصل بالقطعة واقرأ VIN أولاً.")
                            .font(.callout)
                        TextField("إصدار SYNC (مثال: SYNC 4)", text: $syncVersion)
                            .textFieldStyle(.roundedBorder)
                        Button("قراءة السيارة (VIN)") {
                            Task { await readVehicle() }
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }

                // حالة الاتصال.
                GroupBox("حالة الاتصال بقطعة OBD") {
                    Text(appState.connection.isConnected ? "متصل • مستقر" : "غير متصل")
                    Text("القطعة الموصى بها أولاً: vLinker FS — ثم OBDLink MX+ — ثم WiFi ELM327 الأصلي. ELM327 v1.5 الرخيص غير موصى به.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    if case .connected(let adapter) = appState.connection, let warning = adapter.warningAr {
                        Text(warning).font(.caption).foregroundColor(.orange)
                    }
                }

                // نسخة احتياطية.
                GroupBox("نسخة احتياطية") {
                    Text("إنشاء نسخة احتياطية لإعدادات السيارة الحالية قبل أي تغيير.")
                        .font(.caption)
                    Button("نسخة احتياطية") {
                        // تُنفذ عبر SafetyService.backupAll بعد قراءة الوحدات.
                        message = "النسخة الاحتياطية تُنشأ بعد قراءة الوحدات — اقرأ السيارة أولاً."
                    }
                    .buttonStyle(.bordered)
                    .disabled(appState.vehicle == nil)
                }

                if let message {
                    Text(message).font(.caption).foregroundColor(.secondary)
                }
            }
            .padding()
        }
        .navigationTitle("الرئيسية")
    }

    private func readVehicle() async {
        do {
            let vehicle = try await appState.diagnostics.identifyVehicle(syncVersion: syncVersion)
            await MainActor.run {
                appState.vehicle = vehicle
                appState.addLog("تم التعرف على تورس 2023 — VIN: \(vehicle.vin)", level: .success)
            }
        } catch {
            await MainActor.run {
                message = error.localizedDescription
                appState.addLog("فشل التعرف على السيارة: \(error.localizedDescription)", level: .error)
            }
        }
    }
}
