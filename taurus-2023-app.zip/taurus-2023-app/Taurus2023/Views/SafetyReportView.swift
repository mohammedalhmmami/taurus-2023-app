import SwiftUI

// MARK: - SafetyReportView
/// تقرير السلامة قبل الكتابة — كل الفحوصات يجب أن تكون خضراء.
/// الضغط على أي فحص يفتح شاشة تفاصيله (ما هو، حالته، ما يلزم لاجتيازه، زر الإجراء).
/// زر النسخة الاحتياطية يبقى معطلاً بلا سيارة، مع نص يشرح السبب تحته.
/// زر الاسترجاع بضغطة واحدة.
struct SafetyReportView: View {
    @EnvironmentObject var appState: AppState
    @State private var backupMessage: String?
    @State private var isBackingUp = false

    /// فحوصات السلامة الستة — بنفس ترتيب SafetyReport.checks.
    private let checkKinds: [SafetyCheckKind] = [.connection, .vin, .battery, .speed, .backup, .adapter]

    var body: some View {
        List {
            Section("فحوصات السلامة") {
                ForEach(checkKinds, id: \.self) { kind in
                    NavigationLink {
                        SafetyCheckDetailView(kind: kind)
                    } label: {
                        HStack {
                            Text(kind.rawValue)
                                .foregroundColor(.primary)
                            Spacer()
                            Text(kind.isPassed(appState: appState) ? "✅" : "❌")
                        }
                    }
                }
            }
            Section("الكتابة") {
                Text(appState.safety.canWrite
                     ? "✅ الكتابة مسموحة الآن — كل الشروط متحققة"
                     : "⛔ الكتابة غير مسموحة — أكمل كل الفحوصات أعلاه أولاً")
                    .font(.callout)
            }
            Section("نسخة احتياطية") {
                Text("إنشاء نسخة احتياطية لإعدادات السيارة الحالية قبل أي تغيير.")
                    .font(.caption)
                Button("نسخة احتياطية") {
                    Task { await createBackup() }
                }
                .buttonStyle(.bordered)
                .disabled(appState.vehicle == nil || appState.demoMode || isBackingUp)
                if appState.demoMode {
                    Text("وضع تجريبي — لا نسخة احتياطية حقيقية بلا سيارة متصلة.")
                        .font(.caption)
                        .foregroundColor(.red)
                } else if appState.vehicle == nil {
                    Text("بلا سيارة متصلة — اتصل بالقطعة واقرأ VIN أولاً.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                if let backup = appState.backup {
                    Text("آخر نسخة: \(backup.date, style: .date) — VIN: \(backup.vin)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                if let backupMessage {
                    Text(backupMessage).font(.caption).foregroundColor(.secondary)
                }
                NavigationLink("تفاصيل النسخة الاحتياطية") {
                    SafetyCheckDetailView(kind: .backup)
                }
                .font(.callout)
            }
            Section("الاسترجاع") {
                Text("إعادة كل القيم إلى النسخة الاحتياطية المحفوظة قبل أول تغيير.")
                    .font(.caption)
                // الصف يفتح التفاصيل دائماً — زر "استرجاع" نفسه داخل التفاصيل
                // هو المعطل عند غياب النسخة، مع سبب واضح تحته.
                NavigationLink("تفاصيل الاسترجاع") {
                    SafetyCheckDetailView(kind: .restore)
                }
                .font(.callout)
                if appState.demoMode {
                    Text("وضع تجريبي — لا استرجاع حقيقي بلا سيارة متصلة.")
                        .font(.caption)
                        .foregroundColor(.red)
                } else if appState.backup == nil {
                    Text("لا توجد نسخة احتياطية محفوظة بعد").font(.caption).foregroundColor(.secondary)
                }
            }
            Section("قواعد ثابتة") {
                Text("• لا كتابة على PCM (المحرك) ولا TCM (القير) أبداً").font(.caption)
                Text("• لا كتابة أثناء القيادة — السرعة يجب أن تكون 0").font(.caption)
                Text("• تغيير واحد فقط في كل مرة، مع تحقق بإعادة القراءة").font(.caption)
                Text("• إيقاف فوري عند انقطاع الاتصال أو انخفاض الجهد").font(.caption)
            }
        }
        .navigationTitle("السلامة")
    }

    private func createBackup() async {
        isBackingUp = true
        do {
            _ = try await appState.createBackup()
            backupMessage = "تم حفظ النسخة الاحتياطية."
        } catch {
            backupMessage = "فشل إنشاء النسخة: \(error.localizedDescription)"
            appState.addLog("فشل النسخة الاحتياطية: \(error.localizedDescription)", level: .error)
        }
        isBackingUp = false
    }
}
