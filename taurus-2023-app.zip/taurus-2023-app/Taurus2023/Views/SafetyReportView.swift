import SwiftUI

// MARK: - SafetyReportView
/// تقرير السلامة قبل الكتابة — كل الفحوصات يجب أن تكون خضراء.
/// زر الاسترجاع بضغطة واحدة.
struct SafetyReportView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        List {
            Section("فحوصات السلامة") {
                ForEach(appState.safety.checks, id: \.0) { check in
                    HStack {
                        Text(check.0)
                        Spacer()
                        Text(check.1 ? "✅" : "❌")
                    }
                }
            }
            Section("الكتابة") {
                Text(appState.safety.canWrite
                     ? "✅ الكتابة مسموحة الآن — كل الشروط متحققة"
                     : "⛔ الكتابة غير مسموحة — أكمل كل الفحوصات أعلاه أولاً")
                    .font(.callout)
            }
            Section("الاسترجاع") {
                Text("إعادة كل القيم إلى النسخة الاحتياطية المحفوظة قبل أول تغيير.")
                    .font(.caption)
                Button("استرجاع بضغطة واحدة") {
                    // ينفذ عبر SafetyService.restore بعد اختبار أوامر الكتابة على السيارة.
                    appState.addLog("طلب استرجاع — يحتاج تنفيذ أوامر الكتابة بعد اختبار السيارة", level: .warning)
                }
                .disabled(appState.backup == nil)
                if appState.backup == nil {
                    Text("لا توجد نسخة احتياطية محفوظة بعد").font(.caption).foregroundColor(.secondary)
                }
            }
            Section("قواعد ثابتة") {
                Text("• لا كتابة على PCM (المحرك) ولا TCM (القير) أبداً").font(.caption)
                Text("• لا كتابة أثناء القيادة — السرعة يجب أن تكون 0").font(.caption)
                Text("• تغيير واحد فقط في كل مرة، مع تحقق بإعادة القراءة").font(.caption)
                Text("• إيقاف فوري عند انقطاع الاتصال أو انخفاض الجهد").font(.caption)
            }
        }
        .navigationTitle("السلامة")
    }
}
