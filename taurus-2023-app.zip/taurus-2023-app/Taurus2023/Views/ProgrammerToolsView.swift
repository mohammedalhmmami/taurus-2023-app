import SwiftUI

// MARK: - ProgrammerToolsView
/// شاشة «أدوات المبرمجين» — معلومات قراءة فقط عن برامج البرمجة الأخرى،
/// وأيها يصلح لتورس 2023 وأيها لا يصلح ولماذا.
/// لا يوجد في هذه الشاشة أي إجراء كتابة — معلومات فقط، والتطبيق لا يتصل بأي
/// برنامج منها ولا يرسل له شيئاً.
/// المصدر: بحث شامل في برامج المبرمجين لتورس 2023 (2026-11-16) — تقرير
/// ~/workspace/research_notes/ford-programming-tools-taurus-2023-20261116.md
struct ProgrammerToolsView: View {
    var body: some View {
        List {
            Section("الطريق المثبت للكتابة") {
                toolRow(
                    name: "FORScan",
                    status: "الخيار الوحيد المثبت للكتابة — ويندوز فقط",
                    statusColor: .green,
                    detail: "برنامج ويندوز برخصة موسعة (تجربة شهرين مجاناً؛ سعر السنة المدفوعة غير موثّق رسمياً، والمتداول 12–20 دولاراً). ثَبُت وصوله لتورس 2023 الشرق الأوسطية عبر Plugd على Mac (22+ وحدة، أكتوبر 2026) — لكن بلا أكواد منشورة. نسخة الجوال FORScan Lite (6.99$) قراءة فقط بأقوال المطور نفسه — لا تكتب As-Built أبداً."
                )
            }

            Section("برنامج الوكالة الرسمي") {
                toolRow(
                    name: "FDRS",
                    status: "رسمي من فورد — يغطي Mondeo CD542A موديل 2023 حسب قائمة موزع",
                    statusColor: .green,
                    detail: "برنامج الوكالة الرسمي: فلاش كامل وPMI من سيرفرات فورد، وتركيب وحدات جديدة، وبرمجة SYNC، وبرمجة مفاتيح PATS كاملة. الأسعار الأمريكية (أكتوبر 2026): يومان 120$، وشهر 300$، وسنة 1,200$؛ سعر السعودية غير موثّق، ولا يوجد اختبار حي سعودي وُجد. يتطلب محول J2534 (Mongoose-Plus 575–785$ أو CarDAQ-Plus 3 نحو 1,995$ + اشتراك فورد)."
                )
            }

            Section("لا يغطي 2023") {
                toolRow(
                    name: "IDS",
                    status: "حتى موديلات 2018 فقط — لا يغطي 2023",
                    statusColor: .red,
                    detail: "برنامج فورد التشخيصي السابق — توقف عند موديلات 2018، فلا يصلح لتورس 2023 إطلاقاً."
                )
                toolRow(
                    name: "UCDS وELMConfig وFoCCCus",
                    status: "جيل قديم — لا تصلح",
                    statusColor: .red,
                    detail: "أدوات الجيل السابق (فوكس/مونديو CD391 وما قبله). UCDS «Mondeo 5» فيها تعني CD391 (2012–2022) لا الجيل الخامس C2."
                )
            }

            Section("تطبيقات الجوال — قراءة فقط للكتابة") {
                toolRow(
                    name: "FORScan Lite وCar Scanner وOBDLink app",
                    status: "قراءة فقط — لا تكتب As-Built",
                    statusColor: .orange,
                    detail: "كل تطبيقات الجوال قراءة فقط للكتابة على فورد. من يَعِد بكتابة As-Built من الجوال بلا قطعة وحاسوب فهو وعد غير موثّق."
                )
            }

            Section("مستبعدة قطعاً") {
                toolRow(
                    name: "Panther OBD",
                    status: "مستبعد — سيارات Panther 2006–2012 فقط",
                    statusColor: .red,
                    detail: "مخصص لسيارات Panther (كراون فيكتوريا وما شابه) 2006–2012 فقط. لا يصلح لتورس 2023 بأي حال."
                )
                toolRow(
                    name: "OBDeleven",
                    status: "مستبعد — فورد فيه للسيارات المصنّعة في أمريكا فقط",
                    statusColor: .red,
                    detail: "مزايا فورد في OBDeleven للسيارات المصنّعة في أمريكا فقط — وتورس 2023 صينية الصنع (Changan Ford)."
                )
            }

            Section("ملاحظات مهمة لتورس 2023") {
                VStack(alignment: .leading, spacing: 8) {
                    Text("• تورس موديل 2023 بلا مودم حسب جدول فورد الرسمي (موديل 2024 فأحدث: نعم) — فحتى التشغيل عن بعد عبر FordPass غير متاح لها على ما يبدو. تحقق من VIN على fordconnected.com قبل الجزم.")
                    Text("• دليل سلبي: موضوع في منتدى FORScan (2023-10-29) عن إلغاء الأوتو ستارت ستوب لتورس 2023 — المستخدم لم يجد بلوك BCM 726-48-02 في سيارته إطلاقاً.")
                    Text("• الميزات ممكنة تقنياً (موثقة بالفيديو على سيارات حقيقية) لكن القيم يحتفظ بها الباعة سراً تجارياً، والأداة المرجحة عندهم FDRS الرسمي لا FORScan — وهذا يفسّر التعارض بين فيديوهات النجاح وتقارير فشل FORScan على CD542.")
                }
                .font(.callout)
            }
        }
        .navigationTitle("أدوات المبرمجين")
    }

    private func toolRow(name: String, status: String, statusColor: Color, detail: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(name).font(.headline)
            Text(status).font(.subheadline).foregroundColor(statusColor)
            Text(detail).font(.callout).foregroundColor(.secondary)
        }
        .padding(.vertical, 4)
    }
}
