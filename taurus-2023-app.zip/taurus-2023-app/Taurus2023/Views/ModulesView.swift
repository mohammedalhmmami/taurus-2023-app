import SwiftUI

// MARK: - ModulesView
/// قائمة الوحدات الـ13 — كل وحدة بأيقونتها وحالة الكتابة.
/// الضغط على أي وحدة يفتح شاشة تفاصيلها (عنوان CAN + الحالة + زر قراءة).
/// PCM و TCM يظهران هنا للتشخيص (قراءة فقط) لكنهما لا يظهران في المزايا أبداً.
struct ModulesView: View {
    @EnvironmentObject var appState: AppState
    @State private var statuses: [ModuleStatus] = Module.allCases.map { ModuleStatus(module: $0, found: false, dtcCount: 0) }

    var body: some View {
        List {
            Section {
                Text("القائمة للعرض والقراءة فقط — PCM (المحرك) و TCM (القير) محظوران من الكتابة نهائياً، ولا يظهران في المزايا أبداً.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Section("الوحدات (13)") {
                ForEach(statuses) { status in
                    NavigationLink {
                        ModuleDetailView(status: status) { updated in
                            if let index = statuses.firstIndex(where: { $0.module == updated.module }) {
                                statuses[index] = updated
                            }
                        }
                    } label: {
                        HStack {
                            Image(systemName: status.module.iconName)
                                .foregroundColor(status.module.isWritable ? .gold : .red)
                                .frame(width: 30)
                            VStack(alignment: .leading) {
                                Text("\(status.module.arabicName) (\(status.module.rawValue))")
                                    .font(.headline)
                                    .foregroundColor(.primary)
                                Text("CAN: \(status.module.canID) • \(status.found ? "موجودة" : "لم تُفحص بعد") • أعطال: \(status.dtcCount)")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                if let ban = status.module.writeBanReason {
                                    Text(ban).font(.caption).foregroundColor(.red)
                                }
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle("الوحدات")
        .toolbar {
            Button("فحص الوحدات") {
                Task { await scan() }
            }
            .disabled(!appState.connection.isConnected || appState.demoMode)
        }
    }

    private func scan() async {
        do {
            let found = try await appState.diagnostics.scanModules()
            await MainActor.run {
                statuses = found
                appState.addLog("فحص الوحدات: \(found.filter { $0.found }.count) وحدة موجودة", level: .info)
            }
        } catch {
            await MainActor.run { appState.addLog("فشل فحص الوحدات: \(error.localizedDescription)", level: .error) }
        }
    }
}
