import SwiftUI

// MARK: - ContentView
/// الواجهة الرئيسية — شبكة أيقونات (Grid) بدل الشريط الجانبي.
/// التصميم داكن ذهبي، والتنقل بالعربي RTL.
/// لافتة الوضع التجريبي الحمراء ثابتة أعلى كل شاشة (خارج NavigationStack
/// فتبقى ظاهرة حتى بعد التنقل داخل أي شاشة).
struct ContentView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        VStack(spacing: 0) {
            if appState.demoMode {
                Text("وضع تجريبي — لا اتصال ولا كتابة فعلية")
                    .font(.caption)
                    .bold()
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background(Color.red)
            }
            NavigationStack {
                HomeView()
            }
        }
        .environment(\.layoutDirection, .rightToLeft) // عربي RTL.
    }
}

// MARK: - HomeDestination
/// وجهات الشاشة الرئيسية — أيقونة لكل وجهة في الشبكة.
/// كل وجهة تفتح شاشتها المليئة بالخيارات (لا شاشة فارغة).
enum HomeDestination: String, CaseIterable, Identifiable, Hashable {
    case connection = "الاتصال بالقطعة"
    case vehicle = "السيارة"
    case features = "المزايا (18)"
    case modules = "الوحدات"
    case diagnostics = "التشخيص"
    case safety = "السلامة والنسخة الاحتياطية"
    case log = "السجل"
    case programmerTools = "أدوات المبرمجين"

    var id: String { rawValue }
    var iconName: String {
        switch self {
        case .connection: return "wifi"
        case .vehicle: return "car"
        case .features: return "slider.horizontal.3"
        case .modules: return "square.grid.2x2"
        case .diagnostics: return "stethoscope"
        case .safety: return "shield.checkered"
        case .log: return "list.clipboard"
        case .programmerTools: return "wrench.and.screwdriver"
        }
    }
}

// MARK: - Color.gold
extension Color {
    /// الذهبي المستخدم في التصميم الداكن الذهبي.
    static let gold = Color(red: 0.85, green: 0.65, blue: 0.25)
}
