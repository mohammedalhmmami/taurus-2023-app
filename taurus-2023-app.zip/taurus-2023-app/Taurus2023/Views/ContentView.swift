import SwiftUI

// MARK: - ContentView
/// الشاشة الرئيسية — شريط جانبي + محتوى.
/// التصميم داكن ذهبي، والتنقل بالعربي RTL.
struct ContentView: View {
    @EnvironmentObject var appState: AppState
    @State private var selected: SidebarDestination = .home

    var body: some View {
        NavigationSplitView {
            SidebarView(selected: $selected)
        } detail: {
            switch selected {
            case .home: HomeView()
            case .modules: ModulesView()
            case .features: FeaturesView()
            case .diagnostics: DiagnosticsView()
            case .safety: SafetyReportView()
            case .log: LogView()
            }
        }
        .environment(\.layoutDirection, .rightToLeft) // عربي RTL.
    }
}

// MARK: - SidebarDestination
/// مسارات التطبيق — كل مسار له أيقونة في الشريط الجانبي.
/// هذه هي "المسارات" المطلوبة: السيارة، الشاشة، العدادات، الجسم، الصوت، الفرامل، التشخيص، السجل.
enum SidebarDestination: String, CaseIterable, Identifiable {
    case home = "الرئيسية"
    case modules = "الوحدات"
    case features = "المزايا"
    case diagnostics = "التشخيص"
    case safety = "السلامة"
    case log = "السجل"

    var id: String { rawValue }
    var iconName: String {
        switch self {
        case .home: return "house"
        case .modules: return "square.grid.2x2"
        case .features: return "slider.horizontal.3"
        case .diagnostics: return "stethoscope"
        case .safety: return "shield.checkered"
        case .log: return "list.clipboard"
        }
    }
}
