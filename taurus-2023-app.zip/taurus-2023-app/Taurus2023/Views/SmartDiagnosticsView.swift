import SwiftUI

// MARK: - SmartDiagnosticsView
/// التشخيص الذكي: يقرأ كل الأعطال (DTCs) من كل الوحدات المكتشفة —
/// مؤكدة (Mode 03) ومعلّقة (Mode 07) ودائمة (Mode 0A) — ويفسر كل كود
/// بالعربية من قاعدة بيانات موثقة (Wal33D/dtc-database، MIT).
///
/// قواعد العرض الصارمة:
/// - الوحدة التي لا ترد تُعرض «لا ترد» — لا تُخترع لها أعطال أبداً.
/// - الكود غير الموجود في قاعدة البيانات يُعرض «غير موثّق — بنية الكود
///   معروفة فقط» — لا يُخترع له وصف.
/// - الأسباب المحتملة غير موثقة في المصدر إطلاقاً — فلا تُعرض أسباب لأي
///   كود؛ يُقال ذلك صراحة بدل التخمين.
/// - المسح (Mode 04) فقط بعد القراءة وبتأكيد صريح، ثم إعادة قراءة
///   للتحقق. المسح يمسح الكود المخزن فقط ولا يغير أي برمجة.
/// - الوضع التجريبي يعرض أمثلة موسومة بوضوح «أمثلة — ليست من سيارتك»
///   من صورة مبرمج 2015 (سيارة أمريكية مختلفة تماماً عن تورس 2023).
struct SmartDiagnosticsView: View {
    @EnvironmentObject var appState: AppState
    @State private var results: [SmartModuleDTCs] = []
    @State private var hasRead = false
    @State private var isReading = false
    @State private var readMessage: String?
    @State private var isClearing = false
    @State private var showClearConfirm = false
    @State private var clearMessage: String?
    @State private var testResults: [(name: String, passed: Bool, detail: String)] = []

    private var db: DTCDatabase { DTCDatabase.shared }

    var body: some View {
        List {
            demoBannerSection
            readSection
            testSection
            if hasRead || appState.demoMode { summarySection }
            ForEach(displayResults) { moduleResult in
                moduleSection(moduleResult)
            }
            if hasRead && !appState.demoMode { clearSection }
            databaseInfoSection
        }
        .navigationTitle("التشخيص الذكي")
        .onAppear {
            testResults = DTCDecoderTests.runAll()
            let failed = testResults.filter { !$0.passed }
            if !failed.isEmpty {
                for f in failed {
                    appState.addLog("اختبار فك DTC فشل: \(f.name) — \(f.detail)", level: .error)
                }
            }
            if appState.demoMode { loadDemoExamples() }
        }
        .alert("مسح كل الأعطال المقروءة؟", isPresented: $showClearConfirm) {
            Button("مسح", role: .destructive) { Task { await clearAll() } }
            Button("إلغاء", role: .cancel) { }
        } message: {
            Text("سيُمسح الكود المخزن فقط (Mode 04) من كل وحدة قرأنا منها أعطالاً. المسح لا يصلح العطل ولا يغير أي برمجة — والكود سيعود إن لم يُصلح السبب. الأعطال الدائمة (Mode 0A) لا تُمسح إلا بعد الإصلاح. ستُعاد القراءة بعد المسح للتحقق.")
        }
    }

    // MARK: - Data
    /// النتائج المعروضة: في الوضع التجريبي الأمثلة، وإلا نتائج القراءة الحقيقية.
    private var displayResults: [SmartModuleDTCs] { results }

    /// كل الأكواد المعروضة (للمُلخص).
    private var allCodes: [DecodedDTC] { results.flatMap { $0.all } }

    /// أمثلة الوضع التجريبي — من صورة مبرمج تورس 2015 الأمريكية.
    /// P1346 غير موثّق لفورد في المصدر (له معانٍ في ماركات أخرى فقط).
    private func loadDemoExamples() {
        var apim = SmartModuleDTCs(module: .apim, responded: true)
        var ipc = SmartModuleDTCs(module: .ipc, responded: true)
        if let d1 = DTCDecoder.parseFORScanStyle("U3000:04-28") { apim.confirmed = [d1] }
        if let d2 = DTCDecoder.parseFORScanStyle("P1346:13-8A"),
           let d3 = DTCDecoder.parseFORScanStyle("U0159:00-0A") {
            ipc.confirmed = [d2, d3]
        }
        results = [apim, ipc]
        hasRead = true
        readMessage = "أمثلة تجريبية من صورة مبرمج 2015 — ليست من سيارتك."
    }

    // MARK: - Sections
    @ViewBuilder
    private var demoBannerSection: some View {
        if appState.demoMode {
            Section {
                Text("أمثلة — ليست من سيارتك")
                    .font(.headline)
                    .foregroundColor(.red)
                Text("هذه الأكواد من صورة مبرمج لتورس 2015 أمريكية (3.5L) — سيارة مختلفة تماماً عن تورس 2023 السعودية (مونديو C2، 2.0 EcoBoost). لا تُنسخ أكوادها ولا تُستخدم كمرجع لسيارتك. الأكواد: U3000:04-28 في APIM، وP1346:13-8A وU0159:00-0A في IPC.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
    }

    private var readSection: some View {
        Section("قراءة الأعطال") {
            Text("تُقرأ الأعطال من كل وحدة (13 وحدة) — مؤكدة (Mode 03) ومعلّقة (Mode 07) ودائمة (Mode 0A) — عبر تغيير الهيدر لكل وحدة ثم إرسال Mode. الوحدة التي لا ترد تُعرض «لا ترد».")
                .font(.caption)
                .foregroundColor(.secondary)
            Button(isReading ? "جارٍ القراءة…" : "قراءة كل الأعطال") {
                Task { await readAll() }
            }
            .buttonStyle(.borderedProminent)
            .disabled(!appState.connection.isConnected || appState.demoMode || isReading)
            if appState.demoMode {
                Text("وضع تجريبي — تُعرض الأمثلة أعلاه بدل القراءة الحقيقية.")
                    .font(.caption)
                    .foregroundColor(.red)
            } else if !appState.connection.isConnected {
                Text("اتصل بالقطعة أولاً من شاشة الاتصال.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            if let readMessage { Text(readMessage).font(.caption).foregroundColor(.secondary) }
        }
    }

    private var testSection: some View {
        Section("اختبار فك الترميز") {
            let passed = testResults.filter { $0.passed }.count
            HStack {
                Text("أمثلة فك معروفة (Mode 03/07/0A + صيغة FORScan)")
                    .font(.caption)
                Spacer()
                Text("\(passed)/\(testResults.count) ناجحة")
                    .font(.caption)
                    .foregroundColor(passed == testResults.count ? .green : .red)
            }
            if testResults.contains(where: { !$0.passed }) {
                ForEach(testResults.filter { !$0.passed }, id: \.name) { t in
                    Text("\(t.name): \(t.detail)")
                        .font(.caption)
                        .foregroundColor(.red)
                }
            }
        }
    }

    private var summarySection: some View {
        Section("الملخص") {
            let total = allCodes.count
            let critical = results.reduce(0) { $0 + $1.criticalCount }
            let responded = results.filter { $0.responded }.count
            HStack {
                Text("العدد الكلي").font(.headline)
                Spacer()
                Text("\(total) عطل").font(.headline)
            }
            HStack {
                Text("وحدات ردت").font(.callout)
                Spacer()
                Text("\(responded) من \(results.count)").font(.callout)
            }
            HStack {
                Text("حرجة").font(.callout)
                Spacer()
                Text("\(critical)").font(.callout).foregroundColor(critical > 0 ? .red : .green)
            }
            ForEach(systemCounts, id: \.0) { pair in
                HStack {
                    Text(pair.0).font(.callout)
                    Spacer()
                    Text("\(pair.1)").font(.callout)
                }
            }
            if total == 0 && hasRead && !appState.demoMode {
                Text("لا توجد أعطال في أي وحدة ردت — أو الوحدات كلها لا ترد. تحقق من الاتصال والقطعة.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
    }

    /// عدد الأكواد حسب النظام (من قاعدة البيانات، أو من أول حرف للكود غير الموثق).
    private var systemCounts: [(String, Int)] {
        var counts: [String: Int] = [:]
        for code in allCodes {
            let system = db.entry(for: code.code)?.system ?? systemName(for: code.code)
            counts[system, default: 0] += 1
        }
        return counts.sorted { $0.key < $1.key }
    }

    private func systemName(for code: String) -> String {
        switch code.first {
        case "P": return "مجموعة القوة"
        case "B": return "الجسم"
        case "C": return "الشاصي"
        case "U": return "الشبكة"
        default: return "غير معروف"
        }
    }

    private func moduleSection(_ result: SmartModuleDTCs) -> some View {
        Section {
            if !result.responded {
                Text("لا ترد")
                    .font(.callout)
                    .foregroundColor(.orange)
                if let errorText = result.errorText {
                    Text(errorText).font(.caption).foregroundColor(.secondary)
                }
            } else if result.all.isEmpty {
                Text("ردت — لا توجد أعطال")
                    .font(.callout)
                    .foregroundColor(.green)
            } else {
                ForEach(result.confirmed) { dtc in dtcCard(dtc, module: result.module, kind: "مؤكدة") }
                ForEach(result.pending) { dtc in dtcCard(dtc, module: result.module, kind: "معلّقة") }
                ForEach(result.permanent) { dtc in dtcCard(dtc, module: result.module, kind: "دائمة") }
            }
        } header: {
            Text("\(result.module.rawValue) — \(result.module.arabicName) (\(result.module.canID))")
        }
    }

    /// بطاقة كود واحد: الكود، الوصف العربي، الوحدة، النظام، الخطورة، الأسباب، الإجراء، أمان المسح.
    private func dtcCard(_ dtc: DecodedDTC, module: Module, kind: String) -> some View {
        let entry = db.entry(for: dtc.code)
        return VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(dtc.displayString)
                    .font(.headline)
                    .monospaced()
                Spacer()
                Text(kind)
                    .font(.caption)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 2)
                    .background(Color(white: 0.18))
                    .cornerRadius(8)
            }
            Text(entry?.ar ?? db.arabicDescription(for: dtc.code))
                .font(.callout)
            if dtc.code == "P1346" && entry == nil {
                Text("تنبيه: P1346 غير موثّق لفورد في المصدر — له معانٍ في ماركات أخرى فقط (BMW/GM وغيرها)، ولا يُستخدم أي منها هنا. المعنى الصحيح لفورد يحتاج مصدر فورد موثق.")
                    .font(.caption)
                    .foregroundColor(.orange)
            }
            HStack {
                Text("النظام: \(entry?.system ?? systemName(for: dtc.code))")
                Spacer()
                Text("الخطورة: \(entry?.severity ?? "غير موثقة")")
                    .foregroundColor(severityColor(entry?.severity))
            }
            .font(.caption)
            if let ftbDesc = dtc.failureTypeDescription {
                Text("نوع العطل: \(ftbDesc)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            if !dtc.statusDescriptions.isEmpty {
                Text("الحالة: \(dtc.statusDescriptions.joined(separator: "، "))")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Text("الأسباب المحتملة: غير موثقة في المصدر — لا تُخمن؛ الفحص الفعلي هو الذي يحدد السبب.")
                .font(.caption)
                .foregroundColor(.secondary)
            if let action = entry?.action {
                Text("الإجراء المقترح: \(action)")
                    .font(.caption)
            }
            Text("أمان المسح: \(entry?.clearAdvice ?? "المسح يمسح الكود المخزن فقط ولا يغير أي برمجة — لكن الكود غير موثق فلا يُعرف إن كان حرجاً؛ راجع الورشة قبل المسح.")")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 4)
    }

    private func severityColor(_ severity: String?) -> Color {
        switch severity {
        case "حرج": return .red
        case "مهم": return .orange
        case "معلومة": return .blue
        default: return .secondary
        }
    }

    private var clearSection: some View {
        Section("مسح الأعطال") {
            Text("المسح يمسح الأكواد المخزنة فقط (Mode 04) — لا يصلح العطل ولا يغير أي برمجة. الأعطال الدائمة لا تُمسح إلا بعد الإصلاح. بعد المسح تُعاد القراءة للتحقق.")
                .font(.caption)
                .foregroundColor(.secondary)
            Button(isClearing ? "جارٍ المسح والتحقق…" : "مسح كل الأعطال المقروءة") {
                showClearConfirm = true
            }
            .buttonStyle(.borderedProminent)
            .disabled(!hasRead || allCodes.isEmpty || isClearing)
            if let clearMessage { Text(clearMessage).font(.caption).foregroundColor(.secondary) }
        }
    }

    private var databaseInfoSection: some View {
        Section("قاعدة بيانات الأعطال") {
            if let loadError = db.loadError {
                Text(loadError).font(.caption).foregroundColor(.red)
            } else {
                Text("المصدر: Wal33D/dtc-database — الترخيص MIT (Copyright © 2024 Wal33D).")
                    .font(.caption)
                Text("عدد الأكواد: \(db.count) كوداً — \(db.genericCount) عاماً (SAE J2012) + \(db.fordCount) خاصاً بفورد.")
                    .font(.caption)
                Text("الوصف الإنجليزي منسوخ حرفياً من المصدر وتُحقّق منه آلياً قبل الحزم؛ الوصف العربي ترجمة للوصف الموثق نفسه. الأسباب غير موثقة في المصدر فلا تُعرض.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
    }

    // MARK: - Actions
    private func readAll() async {
        isReading = true
        readMessage = nil
        clearMessage = nil
        let found = await appState.diagnostics.readSmartDTCs()
        await MainActor.run {
            results = found
            hasRead = true
            isReading = false
            let total = found.flatMap { $0.all }.count
            let responded = found.filter { $0.responded }.count
            readMessage = "اكتملت القراءة: \(responded) وحدة ردت من \(found.count)، و\(total) عطل."
            appState.addLog("التشخيص الذكي: قراءة \(responded)/\(found.count) وحدة، \(total) عطل", level: total > 0 ? .warning : .success)
        }
    }

    private func clearAll() async {
        isClearing = true
        clearMessage = nil
        var clearedModules = 0
        var failedModules: [String] = []
        for result in results where result.responded && !result.all.isEmpty {
            do {
                _ = try await appState.diagnostics.clearModuleDTCs(module: result.module)
                clearedModules += 1
            } catch {
                failedModules.append(result.module.rawValue)
            }
        }
        let after = await appState.diagnostics.readSmartDTCs()
        await MainActor.run {
            results = after
            isClearing = false
            let remaining = after.flatMap { $0.all }.count
            if failedModules.isEmpty {
                clearMessage = "تم المسح من \(clearedModules) وحدة وأُعيدت القراءة للتحقق: بقي \(remaining) عطل. إن بقيت أعطال دائمة فهي تحتاج إصلاحاً قبل أن تُمسح."
            } else {
                clearMessage = "فشل المسح في: \(failedModules.joined(separator: "، ")). أُعيدت القراءة: بقي \(remaining) عطل."
            }
            appState.addLog("التشخيص الذكي: مسح الأعطال — بقي \(remaining) عطل بعد إعادة القراءة", level: remaining == 0 ? .success : .warning)
        }
    }
}
