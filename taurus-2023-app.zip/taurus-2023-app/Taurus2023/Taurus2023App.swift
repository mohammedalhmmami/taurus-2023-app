import SwiftUI

// نقطة دخول التطبيق — تطبيق عام لسيارات فورد، يتعرف على السيارة تلقائياً من VIN.
// الواجهة عربية RTL بالكامل (انظر Info.plist: CFBundleDevelopmentRegion = ar).
// ملاحظة: اسم الهدف الداخلي (Taurus2023) وباقة com.taurus2023.app بقيت كما هي
// لاستمرارية المشروع — الاسم الظاهر للمستخدم صار "برمجة فورد".

@main
struct Taurus2023App: App {
    // حالة التطبيق المشتركة: الاتصال، السيارة، السلامة، السجل.
    @StateObject private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(appState)
                .preferredColorScheme(.dark) // تصميم داكن إجباري.
        }
    }
}

// MARK: - AppState
/// الحالة العامة للتطبيق. كل شاشة تقرأ منها ولا تكتب في السيارة مباشرة.
final class AppState: ObservableObject {
    @Published var connection: OBDConnection = .disconnected
    @Published var vehicle: Vehicle?
    @Published var safety: SafetyReport = SafetyReport()
    @Published var log: [LogEntry] = []
    @Published var backup: BackupSet?

    // خدمات OBD والسلامة — تُحقن هنا مرة واحدة.
    // مهم: DiagnosticsService يستخدم نفس ELM327Service (ونفس النقل) — لا نسختين
    // منفصلتين، وإلا قرأ التشخيص من قطعة بلا اتصال.
    let elm327 = ELM327Service()
    let diagnostics: DiagnosticsService
    let safetyService = SafetyService()

    init() {
        self.diagnostics = DiagnosticsService(elm327: elm327)
    }

    /// إضافة سطر إلى السجل مع الوقت.
    func addLog(_ message: String, level: LogLevel = .info) {
        log.append(LogEntry(message: message, level: level))
    }
}

// MARK: - Log
struct LogEntry: Identifiable {
    let id = UUID()
    let date = Date()
    let message: String
    let level: LogLevel
}

enum LogLevel: String {
    case info = "معلومة"
    case warning = "تنبيه"
    case error = "خطأ"
    case success = "نجاح"
}
