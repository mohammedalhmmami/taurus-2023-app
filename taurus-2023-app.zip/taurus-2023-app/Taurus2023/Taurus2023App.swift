import SwiftUI

// نقطة دخول التطبيق — تطبيق عام لسيارات فورد، يتعرف على السيارة تلقائياً من VIN.
// الواجهة عربية RTL بالكامل (انظر Info.plist: CFBundleDevelopmentRegion = ar).
// ملاحظة: اسم الهدف الداخلي (Taurus2023) وباقة com.taurus2023.app بقيت كما هي
// لاستمرارية المشروع — الاسم الظاهر للمستخدم صار "برمجة فورد".

@main
struct Taurus2023App: App {
    // حالة التطبيق المشتركة: الاتصال، السيارة، السلامة، السجل.
    @StateObject private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(appState)
                .preferredColorScheme(.dark) // تصميم داكن إجباري.
        }
    }
}

// MARK: - AppState
/// الحالة العامة للتطبيق. كل شاشة تقرأ منها ولا تكتب في السيارة مباشرة.
final class AppState: ObservableObject {
    @Published var connection: OBDConnection = .disconnected
    @Published var vehicle: Vehicle?
    @Published var safety: SafetyReport = SafetyReport()
    @Published var log: [LogEntry] = []
    @Published var backup: BackupSet?
    /// الوضع التجريبي: تصفح وقراءة بلا سيارة ولا قطعة — لا اتصال ولا كتابة فعلية إطلاقاً.
    @Published var demoMode = false

    // خدمات OBD والسلامة — تُحقن هنا مرة واحدة.
    // مهم: DiagnosticsService يستخدم نفس ELM327Service (ونفس النقل) — لا نسختين
    // منفصلتين، وإلا قرأ التشخيص من قطعة بلا اتصال.
    let elm327 = ELM327Service()
    let diagnostics: DiagnosticsService
    let safetyService = SafetyService()

    init() {
        self.diagnostics = DiagnosticsService(elm327: elm327)
    }

    /// إضافة سطر إلى السجل مع الوقت.
    func addLog(_ message: String, level: LogLevel = .info) {
        log.append(LogEntry(message: message, level: level))
    }

    // MARK: - WiFi connection
    /// الاتصال بقطعة ELM327 عبر WiFi ثم تهيئتها بأوامر AT القياسية.
    /// يحدّث حالة الاتصال وتقرير السلامة (متصل + القطعة موصى بها أم لا).
    @MainActor
    func connectWiFi(host: String, port: UInt16) async {
        connection = .connecting
        let transport = WiFiTransport(host: host, port: port)
        do {
            try await transport.connect()
            try await elm327.initialize(transport: transport, adapterName: "ELM327 WiFi", adapterTransport: .wifi)
            let info = AdapterInfo.info(for: "ELM327 WiFi", transport: .wifi)
            connection = .connected(adapter: info)
            safety.isConnected = true
            safety.adapterRecommended = info.isRecommended
            addLog("متصل بقطعة WiFi على \(host):\(port)", level: .success)
            if let warning = info.warningAr {
                addLog(warning, level: .warning)
            }
        } catch {
            transport.disconnect()
            connection = .failed(error.localizedDescription)
            addLog("فشل الاتصال WiFi: \(error.localizedDescription)", level: .error)
        }
    }

    /// قطع الاتصال — يمسح السيارة وتقرير السلامة (كانت مقروءة من تلك القطعة).
    /// في الوضع التجريبي يخرج منه فقط.
    func disconnect() {
        if demoMode { exitDemoMode(); return }
        elm327.transport?.disconnect()
        elm327.transport = nil
        connection = .disconnected
        vehicle = nil
        safety = SafetyReport()
        addLog("تم قطع الاتصال بالقطعة", level: .info)
    }

    // MARK: - Demo mode
    /// سيارة تجريبية للتصفح بلا سيارة ولا قطعة.
    /// الـ VIN تجريبي صريح وليس حقيقياً، ولا يُستخدم في أي كود ولا يُحفظ كسيارة حقيقية.
    /// الكتابة محظورة نهائياً في هذا الوضع: تقرير السلامة يبقى فارغاً (canWrite = false).
    func enableDemoMode() {
        demoMode = true
        vehicle = Vehicle(vin: "DEMO-VIN-00000000000", modelYear: 2023,
                          modelName: "Ford Taurus (تجريبي)",
                          platform: .taurus2023C2, platformConfidence: .probable,
                          market: "Saudi Arabia", engine: "2.0 EcoBoost",
                          syncVersion: "SYNC 4", trim: .unknown)
        addLog("وضع تجريبي: تصفح بلا سيارة — لا اتصال ولا كتابة فعلية", level: .warning)
    }

    /// الخروج من الوضع التجريبي — يمسح السيارة التجريبية.
    func exitDemoMode() {
        demoMode = false
        vehicle = nil
        safety = SafetyReport()
        addLog("خرجت من الوضع التجريبي", level: .info)
    }

    // MARK: - Backup
    /// إنشاء نسخة احتياطية: فحص الوحدات ثم حفظ أسطر As-Built الحالية.
    /// يتطلب سيارة مقروءة واتصالاً حقيقياً — لا يعمل في الوضع التجريبي.
    func createBackup() async throws -> BackupSet {
        guard !demoMode else {
            throw SafetyError.forbidden("وضع تجريبي — لا نسخة احتياطية حقيقية بلا سيارة متصلة")
        }
        guard let vehicle else {
            throw SafetyError.notReady("لم تُقرأ السيارة بعد — اقرأ VIN أولاً")
        }
        let modules = try await diagnostics.scanModules()
        let set = try safetyService.backupAll(modules: modules, vin: vehicle.vin)
        await MainActor.run {
            backup = set
            safety.hasBackup = true
            addLog("تم إنشاء نسخة احتياطية لـ VIN \(vehicle.vin) (\(modules.filter { $0.found }.count) وحدة موجودة)", level: .success)
        }
        return set
    }
}

// MARK: - Log
struct LogEntry: Identifiable {
    let id = UUID()
    let date = Date()
    let message: String
    let level: LogLevel
}

enum LogLevel: String {
    case info = "معلومة"
    case warning = "تنبيه"
    case error = "خطأ"
    case success = "نجاح"
}
