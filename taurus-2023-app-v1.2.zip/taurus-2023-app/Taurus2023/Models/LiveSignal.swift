import Foundation

// MARK: - LiveSignalFormat
/// صيغة إشارة Mode 22 من OBDb — منسوخة حرفياً من ملف JSON المصدر.
/// القاعدة الموثقة (مرجع OBDb): القيمة = خام × mul ÷ div + add، ثم تُقص إلى [min, max].
/// nullmax: قيمة مفكوكة تعني "لا توجد بيانات" (تُرجع nil بدلاً من قيمة وهمية).
struct LiveSignalFormat {
    let len: Int            // طول الإشارة بالبت
    let bix: Int            // موضع البت الأول (MSB-first، 0 = أول بت في أول بايت)
    let div: Double
    let mul: Double
    let add: Double
    let min: Double?
    let max: Double?
    let sign: Bool          // مكمل ثنائي (two's complement) للقيم السالبة
    let unit: String        // وحدة OBDb الأصلية كما في الملف
    let nullmax: Double?    // قيمة تعني "لا بيانات"
}

// MARK: - LiveSignalVerification
/// حالة تحقق الإشارة على تورس 2023.
/// موثقة 2022+: موسومة صراحة من 2022 في ملف OBDb Ford-Mondeo (الجيل الخامس، منصة C2).
/// تحتاج تحقق: من أجيال أقدم أو بلا سنة محددة — لا تُعرض أبداً كمؤكدة على 2023.
enum LiveSignalVerification {
    case documented2022Plus
    case needsVerification

    var badgeAr: String {
        switch self {
        case .documented2022Plus: return "موثقة لـ 2022+ (OBDb Ford-Mondeo)"
        case .needsVerification: return "تحتاج تحقق على السيارة"
        }
    }
}

// MARK: - LiveSignalReading
/// نتيجة قراءة إشارة واحدة: القيمة المفكوكة والرد الخام كما وصل من القطعة.
/// الرد الخام يُعرض دائماً بجانب القيمة حتى يكون أي خطأ في الفك ظاهراً.
struct LiveSignalReading {
    let value: Double?      // nil = الوحدة ردت لكن القيمة تعني "لا بيانات"
    let rawHex: String      // بايتات البيانات بعد "62 DID" بصيغة Hex
}

// MARK: - LiveSignal
/// إشارة بيانات حية Mode 22 (UDS ReadDataByIdentifier) — قراءة فقط.
/// كل القيم هنا من ملفي OBDb Ford-Mondeo و OBDb Ford-Taurus حرفياً — لا DID ولا
/// معامل تحويل مخترع. إن تعارض الملفان في نفس الـ DID، يُعرض التعارض في
/// conflictNote ولا يُختار أحدهما عشوائياً.
struct LiveSignal: Identifiable {
    let id: String              // معرّف OBDb (مثل MONDEO_FR_VSS)
    let nameAr: String
    let module: Module          // الوحدة (IPC 720 / BdyCM 726 / ABS 760)
    let did: String             // معرّف البيانات (أمر 22)
    let format: LiveSignalFormat
    let source: String          // المصدر حرفياً
    let verification: LiveSignalVerification
    let conflictNote: String?   // تعارض مسجل بين الملفين (إن وجد)
    let noteAr: String?         // ملاحظة إضافية من الملف (مثل علامة dbg)

    // MARK: - Decode
    /// فك بايتات البيانات (بعد "62 DID") حسب صيغة OBDb.
    /// استخراج البتات MSB-first، ثم خام × mul ÷ div + add، ثم قص إلى [min, max].
    /// ترتيب البايتات MSB-first حسب مرجع OBDb؛ يُتحقق على السيارة الفعلية.
    func decode(data: [UInt8]) -> Double? {
        guard format.len > 0, format.len <= 32,
              format.bix + format.len <= data.count * 8 else { return nil }
        var raw: UInt64 = 0
        for i in 0..<format.len {
            let bitIndex = format.bix + i
            let byteIndex = bitIndex / 8
            let bitInByte = 7 - (bitIndex % 8)
            raw = (raw << 1) | UInt64((data[byteIndex] >> bitInByte) & 1)
        }
        var value: Double
        if format.sign {
            let signBit: UInt64 = 1 << (format.len - 1)
            if raw & signBit != 0 {
                value = Double(Int64(raw) - Int64(1 << format.len))
            } else {
                value = Double(raw)
            }
        } else {
            value = Double(raw)
        }
        value = value * format.mul / format.div + format.add
        if let nullmax = format.nullmax, value >= nullmax { return nil }
        if let min = format.min { value = Swift.max(value, min) }
        if let max = format.max { value = Swift.min(value, max) }
        return value
    }

    // MARK: - Display
    /// الوحدة بالعربية.
    var unitAr: String {
        switch format.unit {
        case "kilometersPerHour": return "كم/س"
        case "kilometers": return "كم"
        case "percent": return "٪"
        case "psi": return "psi"
        case "volts": return "فولت"
        case "celsius": return "°م"
        case "offon": return ""
        case "scalar": return "قيمة خام"
        default: return format.unit
        }
    }

    /// نص معامل التحويل كما في الملف: "خام × 100 ÷ 255" أو "خام ÷ 10" أو "خام".
    var formulaText: String {
        var parts = ["خام"]
        if format.mul != 1 { parts.append("× \(trimNumber(format.mul))") }
        if format.div != 1 { parts.append("÷ \(trimNumber(format.div))") }
        if format.add != 0 {
            parts.append(format.add > 0 ? "+ \(trimNumber(format.add))" : "− \(trimNumber(-format.add))")
        }
        if format.bix != 0 { parts.append("(من البت \(format.bix))") }
        if format.sign { parts.append("(بإشارة سالبة)") }
        return parts.joined(separator: " ")
    }

    /// تنسيق القيمة المفكوكة مع وحدتها.
    func formattedValue(_ value: Double) -> String {
        if format.unit == "offon" {
            return value >= 1 ? "1 — تحذير مفعّل" : "0 — لا تحذير"
        }
        let num: String
        if format.div == 1 && format.mul == 1 && format.add == 0 {
            num = "\(Int(value))"
        } else {
            num = trimNumber(value, decimals: 2)
        }
        return unitAr.isEmpty ? num : "\(num) \(unitAr)"
    }

    private func trimNumber(_ value: Double, decimals: Int = 2) -> String {
        var s = String(format: "%.\(decimals)f", value)
        while s.contains(".") && s.hasSuffix("0") { s.removeLast() }
        if s.hasSuffix(".") { s.removeLast() }
        return s
    }
}

// MARK: - Signal catalogue (from OBDb JSON files, verbatim)
extension LiveSignal {

    /// الإشارات السبع الموسومة 2022+ في ملف OBDb Ford-Mondeo — كلها من ABS 760.
    /// filter في الملف: {"to": 2012, "from": 2022} — يُعرض كما هو في المصدر.
    static let documented2022Plus: [LiveSignal] = [
        LiveSignal(
            id: "MONDEO_FR_VSS", nameAr: "سرعة العجلة الأمامية اليمنى",
            module: .abs, did: "2B06",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 200, sign: false, unit: "kilometersPerHour", nullmax: nil),
            source: "OBDb Ford-Mondeo — موسومة 2022+",
            verification: .documented2022Plus, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_FL_VSS", nameAr: "سرعة العجلة الأمامية اليسرى",
            module: .abs, did: "2B07",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 200, sign: false, unit: "kilometersPerHour", nullmax: nil),
            source: "OBDb Ford-Mondeo — موسومة 2022+",
            verification: .documented2022Plus, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_RR_VSS", nameAr: "سرعة العجلة الخلفية اليمنى",
            module: .abs, did: "2B08",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 200, sign: false, unit: "kilometersPerHour", nullmax: nil),
            source: "OBDb Ford-Mondeo — موسومة 2022+",
            verification: .documented2022Plus, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_RL_VSS", nameAr: "سرعة العجلة الخلفية اليسرى",
            module: .abs, did: "2B09",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 200, sign: false, unit: "kilometersPerHour", nullmax: nil),
            source: "OBDb Ford-Mondeo — موسومة 2022+",
            verification: .documented2022Plus, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_LAT_ANG", nameAr: "زاوية الانحراف",
            module: .abs, did: "2B0C",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1, mul: 1, add: 0, min: -32768, max: 32767, sign: true, unit: "scalar", nullmax: nil),
            source: "OBDb Ford-Mondeo — موسومة 2022+",
            verification: .documented2022Plus, conflictNote: nil, noteAr: "الملف لا يسمي وحدة فيزيائية — القيمة عدد خام."
        ),
        LiveSignal(
            id: "MONDEO_BRK_FL_P", nameAr: "ضغط الفرامل الهيدروليكي",
            module: .abs, did: "2B0D",
            format: LiveSignalFormat(len: 16, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 65535, sign: false, unit: "scalar", nullmax: nil),
            source: "OBDb Ford-Mondeo — موسومة 2022+",
            verification: .documented2022Plus,
            conflictNote: "ملف OBDb Ford-Taurus يعطي لنفس الـ DID طول 8 بت ووحدة كيلوباسكال (حد أقصى 255)، بينما ملف المونديو يعطي 16 بت وقيمة خام. المعروض هنا من المونديو (الموسوم 2022+) — يُتحقق على السيارة الفعلية.",
            noteAr: "الملف لا يسمي وحدة فيزيائية — القيمة عدد خام."
        ),
        LiveSignal(
            id: "MONDEO_LAT_G", nameAr: "التسارع الجانبي",
            module: .abs, did: "2B11",
            format: LiveSignalFormat(len: 16, bix: 0, div: 50, mul: 1, add: 0, min: -1, max: 1, sign: true, unit: "scalar", nullmax: nil),
            source: "OBDb Ford-Mondeo — موسومة 2022+",
            verification: .documented2022Plus, conflictNote: nil, noteAr: "الملف لا يسمي وحدة فيزيائية — القيمة عدد خام."
        ),
    ]

    /// إشارات عامة من ملفي المونديو والتورس — تحتاج تحقق على السيارة.
    /// لا تُعرض أبداً كمؤكدة على 2023.
    static let general: [LiveSignal] = [
        LiveSignal(
            id: "MONDEO_ODO", nameAr: "العداد (المسافة المقطوعة)",
            module: .ipc, did: "404C",
            format: LiveSignalFormat(len: 24, bix: 0, div: 10, mul: 1, add: 0, min: nil, max: 1677721, sign: false, unit: "kilometers", nullmax: nil),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس الصيغة في الملفين",
            verification: .needsVerification, conflictNote: nil,
            noteAr: "موسومة تجريبية (dbg) في ملف المونديو."
        ),
        LiveSignal(
            id: "MONDEO_FLI", nameAr: "مستوى الوقود في الخزان",
            module: .ipc, did: "6185",
            format: LiveSignalFormat(len: 8, bix: 0, div: 255, mul: 100, add: 0, min: nil, max: 100, sign: false, unit: "percent", nullmax: nil),
            source: "OBDb Ford-Mondeo فقط",
            verification: .needsVerification, conflictNote: nil,
            noteAr: "موسومة تجريبية (dbg) في ملف المونديو، وغير موجودة في ملف التورس."
        ),
        LiveSignal(
            id: "MONDEO_TPMS_WARN", nameAr: "تحذير ضغط الإطارات",
            module: .ipc, did: "61A5",
            format: LiveSignalFormat(len: 1, bix: 2, div: 1, mul: 1, add: 0, min: nil, max: 1, sign: false, unit: "offon", nullmax: nil),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس الصيغة في الملفين",
            verification: .needsVerification, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_TP_FL", nameAr: "ضغط الإطار الأمامي الأيسر",
            module: .bdyCM, did: "2813",
            format: LiveSignalFormat(len: 16, bix: 0, div: 20, mul: 1, add: 0, min: nil, max: 150, sign: false, unit: "psi", nullmax: 150),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس القسمة والوحدة",
            verification: .needsVerification,
            conflictNote: "ملف OBDb Ford-Taurus يعطي لنفس الـ DID حداً أقصى 3276 بلا nullmax، بينما ملف المونديو يعطي 150 مع nullmax 150 (قيمة 150 تعني «لا بيانات»). المعروض هنا من المونديو (منصة السيارة) — يُتحقق على السيارة الفعلية.",
            noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_TP_FR", nameAr: "ضغط الإطار الأمامي الأيمن",
            module: .bdyCM, did: "2814",
            format: LiveSignalFormat(len: 16, bix: 0, div: 20, mul: 1, add: 0, min: nil, max: 150, sign: false, unit: "psi", nullmax: 150),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس القسمة والوحدة",
            verification: .needsVerification,
            conflictNote: "ملف OBDb Ford-Taurus يعطي لنفس الـ DID حداً أقصى 3276 بلا nullmax، بينما ملف المونديو يعطي 150 مع nullmax 150 (قيمة 150 تعني «لا بيانات»). المعروض هنا من المونديو (منصة السيارة) — يُتحقق على السيارة الفعلية.",
            noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_TP_RR", nameAr: "ضغط الإطار الخلفي الأيمن",
            module: .bdyCM, did: "2815",
            format: LiveSignalFormat(len: 16, bix: 0, div: 20, mul: 1, add: 0, min: nil, max: 150, sign: false, unit: "psi", nullmax: 150),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس القسمة والوحدة",
            verification: .needsVerification,
            conflictNote: "ملف OBDb Ford-Taurus يعطي لنفس الـ DID حداً أقصى 3276 بلا nullmax، بينما ملف المونديو يعطي 150 مع nullmax 150 (قيمة 150 تعني «لا بيانات»). المعروض هنا من المونديو (منصة السيارة) — يُتحقق على السيارة الفعلية.",
            noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_TP_RL", nameAr: "ضغط الإطار الخلفي الأيسر",
            module: .bdyCM, did: "2816",
            format: LiveSignalFormat(len: 16, bix: 0, div: 20, mul: 1, add: 0, min: nil, max: 150, sign: false, unit: "psi", nullmax: 150),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس القسمة والوحدة",
            verification: .needsVerification,
            conflictNote: "ملف OBDb Ford-Taurus يعطي لنفس الـ DID حداً أقصى 3276 بلا nullmax، بينما ملف المونديو يعطي 150 مع nullmax 150 (قيمة 150 تعني «لا بيانات»). المعروض هنا من المونديو (منصة السيارة) — يُتحقق على السيارة الفعلية.",
            noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_12V_SOC", nameAr: "شحن البطارية (12V)",
            module: .bdyCM, did: "4028",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: 0, min: nil, max: 100, sign: false, unit: "percent", nullmax: nil),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس الصيغة في الملفين",
            verification: .needsVerification, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_12V_T", nameAr: "حرارة البطارية (12V)",
            module: .bdyCM, did: "4029",
            format: LiveSignalFormat(len: 8, bix: 0, div: 1, mul: 1, add: -40, min: -40, max: 100, sign: false, unit: "celsius", nullmax: nil),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس الصيغة في الملفين",
            verification: .needsVerification, conflictNote: nil, noteAr: nil
        ),
        LiveSignal(
            id: "MONDEO_12V_V", nameAr: "جهد البطارية (12V)",
            module: .bdyCM, did: "402A",
            format: LiveSignalFormat(len: 8, bix: 0, div: 20, mul: 1, add: 6, min: nil, max: 18.75, sign: false, unit: "volts", nullmax: nil),
            source: "OBDb Ford-Mondeo + OBDb Ford-Taurus — نفس القسمة والإزاحة",
            verification: .needsVerification,
            conflictNote: "ملف OBDb Ford-Taurus يضيف حداً أدنى 6 للصيغة؛ النتيجة المفكوكة نفسها في الملفين لأن القيمة = خام ÷ 20 + 6 ولا تقل عن 6 أبداً.",
            noteAr: nil
        ),
    ]

    /// كل الإشارات: الموثقة 2022+ أولاً ثم العامة.
    static let all: [LiveSignal] = documented2022Plus + general
}
