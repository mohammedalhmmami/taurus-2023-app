import SwiftUI

// MARK: - DiagnosticsView
/// التشخيص: البطارية، السرعة، RPM، الأعطال — كل خيار بمساره الصحيح.
/// الضغط على أي خيار يفتح شاشة تفاصيله (القيمة + المسار + زر قراءة).
/// قراءة فقط — آمن تماماً.
struct DiagnosticsView: View {
    @EnvironmentObject var appState: AppState
    @State private var dtcs: [DTC] = []
    @State private var voltage: Double = 0
    @State private var speed: Double = 0
    @State private var rpm: Double = 0
    @State private var message: String?
    // إشارات Mode 22 (OBDb) — آخر قراءة لكل إشارة وآخر خطأ إن فشلت.
    @State private var signalValues: [String: LiveSignalReading] = [:]
    @State private var signalErrors: [String: String] = [:]
    @State private var isReadingAllSignals = false
    @State private var signalsMessage: String?

    var body: some View {
        List {
            Section("بيانات حية Mode 22 — موثقة لـ 2022+ (OBDb Ford-Mondeo)") {
                ForEach(LiveSignal.documented2022Plus) { signal in
                    NavigationLink {
                        LiveSignalDetailView(signal: signal, initialReading: signalValues[signal.id]) { reading in
                            signalValues[signal.id] = reading
                            signalErrors.removeValue(forKey: signal.id)
                        }
                    } label: {
                        signalRow(signal: signal)
                    }
                }
            }

            Section {
                ForEach(LiveSignal.general) { signal in
                    NavigationLink {
                        LiveSignalDetailView(signal: signal, initialReading: signalValues[signal.id]) { reading in
                            signalValues[signal.id] = reading
                            signalErrors.removeValue(forKey: signal.id)
                        }
                    } label: {
                        signalRow(signal: signal)
                    }
                }
            } header: {
                Text("بيانات حية Mode 22 — إشارات عامة")
            } footer: {
                Text("تحتاج تحقق على السيارة — من أجيال أقدم أو بلا سنة محددة في المصدر، ولا تُعرض أبداً كمؤكدة على 2023.")
            }

            Section("قراءة كل إشارات Mode 22") {
                Button(isReadingAllSignals ? "جارٍ القراءة…" : "قراءة الكل (\(LiveSignal.all.count) إشارة)") {
                    Task { await readAllSignals() }
                }
                .buttonStyle(.borderedProminent)
                .disabled(!appState.connection.isConnected || appState.demoMode || isReadingAllSignals)
                if appState.demoMode {
                    Text("وضع تجريبي — لا قراءة حقيقية بلا قطعة.")
                        .font(.caption)
                        .foregroundColor(.red)
                } else if !appState.connection.isConnected {
                    Text("اتصل بالقطعة أولاً من شاشة الاتصال.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                if let signalsMessage { Text(signalsMessage).font(.caption).foregroundColor(.secondary) }
            }

            Section("البيانات الحية — قراءة فقط") {
                NavigationLink {
                    LiveDataDetailView(kind: .battery, initialValue: voltageText)
                } label: {
                    liveRow(title: "البطارية والجهد", value: voltageText, path: "أمر ATRV")
                }
                NavigationLink {
                    LiveDataDetailView(kind: .speed, initialValue: speedText)
                } label: {
                    liveRow(title: "السرعة", value: speedText, path: "PID 0D")
                }
                NavigationLink {
                    LiveDataDetailView(kind: .rpm, initialValue: rpmText)
                } label: {
                    liveRow(title: "عدد دورات المحرك (RPM)", value: rpmText, path: "PID 0C")
                }
            }

            Section("أكواد الأعطال (DTCs)") {
                NavigationLink {
                    LiveDataDetailView(kind: .dtcs, initialValue: dtcText, dtcs: dtcs)
                } label: {
                    liveRow(title: "أكواد الأعطال", value: dtcText, path: "Mode 03")
                }
                if dtcs.isEmpty {
                    Text("لا توجد أعطال مقروءة بعد — أو لا توجد أعطال في السيارة.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                } else {
                    ForEach(dtcs) { dtc in
                        VStack(alignment: .leading) {
                            Text(dtc.displayString).font(.headline).monospaced()
                            Text("\(dtc.module.rawValue) — \(dtc.descriptionAr)").font(.caption)
                        }
                    }
                }
            }

            Section("فحص كامل") {
                Button("تشغيل الفحص الكامل") {
                    Task { await runDiagnostics() }
                }
                .buttonStyle(.borderedProminent)
                .disabled(!appState.connection.isConnected || appState.demoMode)
                if appState.demoMode {
                    Text("وضع تجريبي — لا فحص حقيقي بلا قطعة.")
                        .font(.caption)
                        .foregroundColor(.red)
                } else if !appState.connection.isConnected {
                    Text("اتصل بالقطعة أولاً من شاشة الاتصال.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                if let message { Text(message).font(.caption).foregroundColor(.secondary) }
            }
        }
        .navigationTitle("التشخيص")
    }

    /// صف خيار بيانات حية: الاسم + القيمة + المسار.
    private func liveRow(title: String, value: String, path: String) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.headline).foregroundColor(.primary)
                Text("المسار: \(path)").font(.caption).foregroundColor(.secondary)
            }
            Spacer()
            Text(value).font(.callout).foregroundColor(.secondary)
        }
    }

    private var voltageText: String {
        voltage > 0 ? "\(String(format: "%.1f", voltage))V" : "لم تُقرأ بعد"
    }
    private var speedText: String {
        "\(String(format: "%.0f", speed)) كم/س"
    }
    private var rpmText: String {
        rpm > 0 ? "\(String(format: "%.0f", rpm)) RPM" : "لم تُقرأ بعد"
    }
    private var dtcText: String {
        dtcs.isEmpty ? "لا توجد أعطال مقروءة" : "\(dtcs.count) عطل"
    }

    /// صف إشارة Mode 22: الاسم + الوحدة والـ DID + حالة التحقق + آخر قيمة.
    private func signalRow(signal: LiveSignal) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(signal.nameAr).font(.headline).foregroundColor(.primary)
                Text("\(signal.module.arabicName) \(signal.module.canID) — DID \(signal.did)")
                    .font(.caption).foregroundColor(.secondary)
                Text(signal.verification.badgeAr)
                    .font(.caption)
                    .foregroundColor(signal.verification == .documented2022Plus ? .green : .orange)
            }
            Spacer()
            Text(signalValueText(signal)).font(.callout).foregroundColor(.secondary)
        }
    }

    private func signalValueText(_ signal: LiveSignal) -> String {
        if signalErrors[signal.id] != nil { return "فشل القراءة" }
        guard let reading = signalValues[signal.id] else { return "لم تُقرأ بعد" }
        guard let value = reading.value else { return "لا بيانات" }
        return signal.formattedValue(value)
    }

    /// قراءة كل إشارات Mode 22 واحدة تلو الأخرى — الفشل في إشارة لا يوقف الباقي.
    private func readAllSignals() async {
        isReadingAllSignals = true
        var ok = 0
        var failed = 0
        for signal in LiveSignal.all {
            do {
                let reading = try await appState.diagnostics.readLiveSignal(signal)
                await MainActor.run {
                    signalValues[signal.id] = reading
                    signalErrors.removeValue(forKey: signal.id)
                }
                ok += 1
            } catch {
                await MainActor.run {
                    signalErrors[signal.id] = error.localizedDescription
                    appState.addLog("فشل قراءة \(signal.nameAr): \(error.localizedDescription)", level: .error)
                }
                failed += 1
            }
        }
        await MainActor.run {
            signalsMessage = "اكتملت القراءة: \(ok) ناجحة، \(failed) فاشلة."
            appState.addLog("قراءة كل إشارات Mode 22: \(ok) ناجحة، \(failed) فاشلة", level: .info)
            isReadingAllSignals = false
        }
    }

    private func runDiagnostics() async {
        do {
            let v = try await appState.diagnostics.readBatteryVoltage()
            let s = try await appState.diagnostics.readSpeedKmh()
            let r = try await appState.diagnostics.readRPM()
            let codes = try await appState.diagnostics.readAllDTCs()
            await MainActor.run {
                voltage = v; speed = s; rpm = r; dtcs = codes
                appState.safety.batteryVoltage = v
                appState.safety.speedKmh = s
                appState.addLog("فحص: جهد \(String(format: "%.1f", v))V، سرعة \(s) كم/س، أعطال \(codes.count)", level: .info)
            }
        } catch {
            await MainActor.run {
                message = error.localizedDescription
                appState.addLog("فشل الفحص: \(error.localizedDescription)", level: .error)
            }
        }
    }
}
