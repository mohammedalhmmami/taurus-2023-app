import SwiftUI

// MARK: - BackupExportView
/// شاشة «تصدير النسخة» — نسخة احتياطية كاملة مقروءة من السيارة (قراءة فقط)
/// تُحفظ في تطبيق الملفات وتُرسل للمطوّر لتحليل البرمجة.
/// في الوضع التجريبي تُحفظ عينة موثقة موسومة DEMO بدل بيانات حقيقية.
struct BackupExportView: View {
    @EnvironmentObject var appState: AppState
    @State private var isExporting = false
    @State private var progressText: String?
    @State private var result: BackupExportResult?
    @State private var errorMessage: String?
    @State private var savedFiles: [URL] = []
    @State private var showDeleteConfirm = false
    @State private var deleteMessage: String?

    private var service: BackupExportService {
        BackupExportService(elm327: appState.elm327, diagnostics: appState.diagnostics)
    }

    /// سبب تعطيل زر التصدير الحقيقي (nil = يعمل).
    private var realExportDisabledReason: String? {
        if isExporting { return "جارٍ التصدير…" }
        if !appState.connection.isConnected { return "غير متصل بالقطعة — اتصل أولاً من شاشة الاتصال." }
        if appState.vehicle == nil { return "لم تُقرأ السيارة بعد — اقرأ VIN أولاً." }
        return nil
    }

    var body: some View {
        List {
            Section("ماذا يحتوي الملف") {
                Text("نسخة قراءة كاملة من السيارة — قراءة فقط، لا تكتب شيئاً:")
                    .font(.callout)
                Text("• رقم الشاصي VIN + موديل السيارة ومنصتها").font(.callout)
                Text("• كل الوحدات التي ردّت والتي لم ترد (13 وحدة)").font(.callout)
                Text("• بلوكات As-Built الكاملة لكل وحدة (DID ‏DE00‏ فأعلى حتى NO DATA) — البايتات الخام كما قُرئت + الأسطر + التشيكسم").font(.callout)
                Text("• أرقام البرمجيات لكل وحدة: F190 رقم الشاصي، F188 الاستراتيجية، F113 التجميع، F124 المعايرة، F187 رقم القطعة، F18C التسلسلي").font(.callout)
                Text("• الأعطال الحالية من كل وحدة (مؤكدة/معلّقة/دائمة)").font(.callout)
                Text("• لقطة البيانات الحية وقت التصدير (البطارية والسرعة وRPM)").font(.callout)
                Text("يكفي الملف وحده لإعادة بناء خريطة برمجة السيارة كاملة وتحليلها.").font(.callout)
                Text("قد تستغرق القراءة الكاملة دقيقة أو أكثر — لا تفصل القطعة أثناءها.").font(.callout)
            }

            Section("تنبيه خصوصية") {
                Text("⚠️ الملف يحتوي رقم الشاصي الكامل وبيانات برمجة سيارتك. أرسله للمطوّر فقط (واتساب / إيميل / AirDrop) ولا تنشره في أي مكان عام.")
                    .font(.callout)
                    .foregroundColor(.orange)
            }

            Section("التصدير") {
                if appState.demoMode {
                    Text("وضع تجريبي — سيُحفظ ملف عينة موسوم DEMO (قيم موثقة من المحاكي وصورة 2015) لاختبار الحفظ والمشاركة بلا سيارة.")
                        .font(.callout)
                        .foregroundColor(.orange)
                    Button(isExporting ? "جارٍ الحفظ…" : "حفظ نسخة تجريبية (عينة)") {
                        Task { await runDemoExport() }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(isExporting)
                } else {
                    Button(isExporting ? "جارٍ التصدير…" : "قراءة وحفظ النسخة") {
                        Task { await runRealExport() }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(realExportDisabledReason != nil)
                    if let reason = realExportDisabledReason {
                        Text(reason).font(.caption).foregroundColor(.orange)
                    }
                }
                if isExporting {
                    HStack {
                        ProgressView()
                        Text(progressText ?? "جارٍ…").font(.callout)
                    }
                }
                if let errorMessage {
                    Text(errorMessage).font(.callout).foregroundColor(.red)
                }
                if let result {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("✅ تم الحفظ").font(.callout).bold().foregroundColor(.green)
                        Text(result.fileName).font(.callout).monospaced()
                        Text("في تطبيق الملفات ← On My iPhone ← برمجة فورد")
                            .font(.caption).foregroundColor(.secondary)
                        let summary = result.export.summary
                        Text("الوحدات: \(summary.modulesResponded) من \(summary.modulesTotal) ردّت — \(summary.totalBlocks) بلوكاً — \(summary.totalLines) سطراً — \(summary.totalDtcs) عطلاً")
                            .font(.caption).foregroundColor(.secondary)
                        if summary.checksumMismatches > 0 {
                            Text("⚠️ \(summary.checksumMismatches) سطر تشيكسيمه غير مطابق — راجع الملف")
                                .font(.caption).foregroundColor(.orange)
                        }
                        if summary.incompleteLines > 0 {
                            Text("⚠️ \(summary.incompleteLines) سطر غير مكتمل (بايتات متبقية)")
                                .font(.caption).foregroundColor(.orange)
                        }
                        if summary.disconnectedMidway {
                            Text("⚠️ انقطع الاتصال أثناء القراءة عند \(summary.stoppedAt ?? "؟") — الملف جزئي")
                                .font(.caption).foregroundColor(.red)
                        }
                        ShareLink(item: result.fileURL,
                                  preview: SharePreview(result.fileName))
                        {
                            Label("مشاركة النسخة (واتساب / إيميل / AirDrop)", systemImage: "square.and.arrow.up")
                        }
                        .buttonStyle(.bordered)
                    }
                }
            }

            Section("النسخ المحفوظة") {
                if savedFiles.isEmpty {
                    Text("لا توجد نسخ محفوظة بعد.").font(.callout).foregroundColor(.secondary)
                } else {
                    ForEach(savedFiles, id: \.self) { url in
                        HStack {
                            Text(url.lastPathComponent).font(.callout).monospaced()
                            Spacer()
                            ShareLink(item: url, preview: SharePreview(url.lastPathComponent)) {
                                Image(systemName: "square.and.arrow.up")
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    Button("حذف النسخ المحفوظة") { showDeleteConfirm = true }
                        .foregroundColor(.red)
                }
                if let deleteMessage {
                    Text(deleteMessage).font(.caption).foregroundColor(.secondary)
                }
            }
        }
        .navigationTitle("تصدير النسخة")
        .onAppear { refreshSavedFiles() }
        .alert("حذف كل النسخ المحفوظة؟", isPresented: $showDeleteConfirm) {
            Button("حذف", role: .destructive) { deleteAll() }
            Button("إلغاء", role: .cancel) { }
        } message: {
            Text("سيُحذف كل ملفات Taurus-Backup-*.json من تطبيق الملفات نهائياً.")
        }
    }

    private func runRealExport() async {
        guard let vehicle = appState.vehicle else { return }
        isExporting = true
        progressText = "بدء التصدير…"
        errorMessage = nil
        result = nil
        do {
            let res = try await service.export(vehicle: vehicle) { text in
                Task { @MainActor in progressText = text }
            }
            await MainActor.run {
                result = res
                refreshSavedFiles()
                appState.addLog("تم تصدير نسخة احتياطية كاملة: \(res.fileName)", level: .success)
            }
        } catch {
            await MainActor.run {
                errorMessage = "فشل التصدير: \(error.localizedDescription)"
                appState.addLog("فشل تصدير النسخة: \(error.localizedDescription)", level: .error)
            }
        }
        await MainActor.run { isExporting = false; progressText = nil }
    }

    private func runDemoExport() async {
        isExporting = true
        progressText = "توليد العينة…"
        errorMessage = nil
        result = nil
        do {
            let res = try service.generateDemo()
            await MainActor.run {
                result = res
                refreshSavedFiles()
                appState.addLog("تم حفظ نسخة تجريبية (عينة DEMO): \(res.fileName)", level: .success)
            }
        } catch {
            await MainActor.run {
                errorMessage = "فشل حفظ العينة: \(error.localizedDescription)"
            }
        }
        await MainActor.run { isExporting = false; progressText = nil }
    }

    private func refreshSavedFiles() {
        savedFiles = BackupExportService.savedExports()
    }

    private func deleteAll() {
        do {
            try BackupExportService.deleteSavedExports()
            deleteMessage = "حُذفت كل النسخ المحفوظة."
            appState.addLog("حُذفت كل النسخ الاحتياطية المصدَّرة", level: .warning)
        } catch {
            deleteMessage = "فشل الحذف: \(error.localizedDescription)"
        }
        refreshSavedFiles()
    }
}
