import SwiftUI

// MARK: - LogView
/// سجل العمليات — كل قراءة وكتابة وتنبيه، مع الوقت.
/// زر «تصدير» يحوّل السجل إلى ملف نصي في Documents ويفتح مشاركة iOS الأصلية.
struct LogView: View {
    @EnvironmentObject var appState: AppState
    @State private var exportedURL: URL?
    @State private var exportMessage: String?

    var body: some View {
        VStack(spacing: 0) {
            List(appState.log) { entry in
                HStack {
                    Text(icon(for: entry.level))
                    VStack(alignment: .leading) {
                        Text(entry.message).font(.callout)
                        Text(entry.date, style: .time).font(.caption).foregroundColor(.secondary)
                    }
                }
            }
            if appState.log.isEmpty {
                Text("السجل فارغ — لا يوجد ما يُصدَّر.")
                    .font(.callout)
                    .foregroundColor(.secondary)
                    .padding()
            }
            if let exportedURL {
                VStack(alignment: .leading, spacing: 6) {
                    Text("✅ تم حفظ ملف السجل: \(exportedURL.lastPathComponent)")
                        .font(.callout)
                        .foregroundColor(.green)
                    ShareLink(item: exportedURL,
                              preview: SharePreview(exportedURL.lastPathComponent)) {
                        Label("مشاركة ملف السجل", systemImage: "square.and.arrow.up")
                    }
                    .buttonStyle(.bordered)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
            }
            if let exportMessage {
                Text(exportMessage).font(.caption).foregroundColor(.secondary).padding(.horizontal)
            }
        }
        .navigationTitle("السجل")
        .toolbar {
            Button("تصدير") { exportLog() }
                .disabled(appState.log.isEmpty)
            Button("مسح") { appState.log.removeAll() }
        }
    }

    private func icon(for level: LogLevel) -> String {
        switch level {
        case .info: return "ℹ️"
        case .warning: return "⚠️"
        case .error: return "❌"
        case .success: return "✅"
        }
    }

    /// بناء نص السجل وحفظه في Documents ثم عرضه للمشاركة.
    /// سطر لكل مدخل: التاريخ والوقت + المستوى + الرسالة.
    private func exportLog() {
        let now = Date()
        let stamp = DateFormatter()
        stamp.locale = Locale(identifier: "en_US_POSIX")
        stamp.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let fileStamp = DateFormatter()
        fileStamp.locale = Locale(identifier: "en_US_POSIX")
        fileStamp.dateFormat = "yyyyMMdd-HHmm"

        var lines: [String] = []
        lines.append("سجل تطبيق برمجة فورد — Ford OBD Log")
        lines.append("تاريخ التصدير: \(stamp.string(from: now))")
        if let vin = appState.vehicle?.vin {
            lines.append("VIN: \(vin)")
        } else {
            lines.append("VIN: لم يُقرأ بعد")
        }
        if appState.demoMode {
            lines.append("وضع تجريبي — سجل تجريبي، ليست عمليات سيارة حقيقية")
        }
        lines.append("عدد المدخلات: \(appState.log.count)")
        lines.append(String(repeating: "-", count: 40))
        for entry in appState.log {
            lines.append("\(stamp.string(from: entry.date)) [\(entry.level.rawValue)] \(entry.message)")
        }

        let fileName = "Taurus-Log-\(fileStamp.string(from: now)).txt"
        let url = BackupExportService.documentsDirectory().appendingPathComponent(fileName)
        do {
            try lines.joined(separator: "\n").write(to: url, atomically: true, encoding: .utf8)
            exportedURL = url
            exportMessage = "حُفظ في تطبيق الملفات ← On My iPhone ← برمجة فورد."
            appState.addLog("تم تصدير السجل: \(fileName)", level: .success)
        } catch {
            exportedURL = nil
            exportMessage = "فشل حفظ ملف السجل: \(error.localizedDescription)"
            appState.addLog("فشل تصدير السجل: \(error.localizedDescription)", level: .error)
        }
    }
}
