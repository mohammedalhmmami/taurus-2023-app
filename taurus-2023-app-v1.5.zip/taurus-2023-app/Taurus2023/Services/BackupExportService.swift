import Foundation

// MARK: - Backup export models (JSON keys in English — for the developer)
// صيغة ملف النسخة الاحتياطية الكاملة (v1.5) — موثقة في FEATURES.md.
//
// الملف نسخة قراءة كاملة لغرض التحليل والتطوير: قائمة الوحدات + As-Built
// الكامل لكل وحدة + أرقام البرمجيات (F190/F188/F113/F124/F187/F18C)
// + الأعطال + لقطة البيانات الحية (بطارية/سرعة/RPM).
// قراءة فقط — لا يكتب شيئاً في السيارة إطلاقاً.

// MARK: - Top-level file
/// ملف النسخة الاحتياطية الكاملة كما يُحفظ JSON.
struct BackupExportFile: Codable {
    let format: String            // "Ford Taurus Backup Export"
    let formatVersion: Int        // 1
    let headerAr: String          // شرح الصيغة بالعربية
    let headerEn: String          // شرح الصيغة بالإنجليزية
    let appVersion: String        // مثل "1.5 (5)"
    let exportedAt: String        // ISO 8601
    let vin: String
    let vinSource: String         // "Mode 09 PID 02" أو "demo"
    let demo: Bool                // true = عينة تجريبية، ليست بيانات سيارة حقيقية
    let vehicle: ExportVehicleInfo?
    let snapshot: ExportSnapshot
    let modules: [ExportModule]
    let summary: ExportSummary
    let notes: [String]           // ملاحظات منهجية (افتراضات القراءة والتحقق)
}

/// معلومات السيارة كما عرفها التطبيق من VIN.
struct ExportVehicleInfo: Codable {
    let modelName: String
    let modelYear: Int
    let platform: String
    let trim: String
}

/// لقطة البيانات الحية وقت التصدير — nil تعني لم تُقرأ (لا تُخترع قيمة).
struct ExportSnapshot: Codable {
    let batteryVoltage: Double?
    let speedKmh: Double?
    let rpm: Double?
}

// MARK: - Module
/// وحدة واحدة في النسخة: معرّفاتها + بلوكات As-Built + أعطالها.
struct ExportModule: Codable {
    let address: String           // مثل "7D0"
    let name: String              // مثل "APIM"
    let arabicName: String
    let responded: Bool           // ردت على أي طلب على الأقل؟
    let error: String?            // سبب عدم الرد إن لم ترد
    let identifiers: [ExportIdentifier]
    let asBuiltSupported: Bool    // هل ردت على DID DE00 أصلاً؟
    let asBuiltBlocks: [ExportBlock]
    let dtcs: ExportDTCs
    let dtcCount: Int
}

/// رقم تعريف واحد عبر Mode 22 (F190/F188/F113/F124/F187/F18C).
struct ExportIdentifier: Codable {
    let did: String               // مثل "F190"
    let name: String              // مثل "VIN" / "strategy"
    let responded: Bool
    let hex: String?              // البايتات كما قُرئت (Hex)
    let ascii: String?            // فك ASCII إن كانت كل البايتات قابلة للطباعة
}

/// بلوك As-Built واحد (DID DE00+N-1) — البايتات الخام كما قُرئت + الأسطر المشتقة.
struct ExportBlock: Codable {
    let did: String               // مثل "DE02"
    let block: Int                // رقم البلوك (1...)
    let byteCount: Int
    let rawHex: String            // كل بايتات البلوك كما قُرئت، بلا أي تعديل
    let lines: [ExportLine]
}

/// سطر As-Built واحد مشتق من بايتات البلوك.
///
/// التشيكسم: بايتات DID التي ترسلها الوحدة هي بايتات البيانات فقط —
/// بايت التشيكسم الظاهر في FORScan محسوب بالصيغة الموثقة (FordScan
/// AsBuiltChecksum: البايت المنخفض لمجموع بايتي العنوان + رقم البلوك +
/// رقم السطر + مجموع بايتات البيانات)، وليس بايتاً مقروءاً من الوحدة.
/// لذلك checksumSource = "computed" للأسطر المشتقة من قراءة حية، و
/// checksumValid تعني: السطر مكتمل بالعرض المفترض (5 بايتات) وأُعيد حساب
/// تشيكسيمه بالصيغة الموثقة. السطر الجزئي (بايتات متبقية لا تكمل سطراً)
/// يُسجَّل checksumValid = false مع ملاحظة.
/// أما أسطر العينة التجريبية من صورة 2015 فتشيكسيمها "displayed" (كما ظهر
/// في الصورة) وchecksumValid = (المحسوب == المعروض).
struct ExportLine: Codable {
    let address: String           // مثل "7D0-03-02"
    let block: Int
    let line: Int
    let dataHex: String           // بايتات البيانات فقط (بلا تشيكسم)
    let dataByteCount: Int
    let checksum: String          // بايتان Hex — محسوب أو معروض
    let checksumSource: String    // "computed" أو "displayed"
    let checksumValid: Bool
    let note: String?             // ملاحظة عند عدم التطابق أو السطر الجزئي
}

/// أعطال الوحدة — نصوص بأسلوب FORScan (مثل "U3000:04-28").
struct ExportDTCs: Codable {
    let confirmed: [String]
    let pending: [String]
    let permanent: [String]
}

/// ملخص النسخة.
struct ExportSummary: Codable {
    let modulesTotal: Int
    let modulesResponded: Int
    let totalBlocks: Int
    let totalLines: Int
    let totalDtcs: Int
    let checksumMismatches: Int   // أسطر تشيكسمها غير مطابق (معروض ≠ محسوب)
    let incompleteLines: Int      // أسطر جزئية (بايتات متبقية)
    let disconnectedMidway: Bool  // هل انقطع الاتصال أثناء القراءة؟
    let stoppedAt: String?        // اسم الوحدة التي توقفت عندها القراءة
}

// MARK: - Result
/// نتيجة التصدير — تُعاد حتى عند الانقطاع أثناء القراءة (ملف جزئي موثق).
struct BackupExportResult {
    let fileURL: URL
    let fileName: String
    let export: BackupExportFile
}

// MARK: - Errors
enum BackupExportError: Error, LocalizedError {
    case notConnected
    case noVehicle
    case writeFailed(String)
    case disconnectedMidway(module: String)
    var errorDescription: String? {
        switch self {
        case .notConnected: return "غير متصل بالقطعة — اتصل أولاً"
        case .noVehicle: return "لم تُقرأ السيارة بعد — اقرأ VIN أولاً"
        case .writeFailed(let msg): return "فشل حفظ الملف: \(msg)"
        case .disconnectedMidway(let module): return "انقطع الاتصال أثناء قراءة وحدة \(module)"
        }
    }
}

// MARK: - BackupExportService
/// تصدير نسخة احتياطية كاملة من السيارة — قراءة فقط، لا كتابة إطلاقاً.
///
/// يقرأ لكل وحدة: أرقام التعريف الستة (Mode 22: F190/F188/F113/F124/
/// F187/F18C)، ثم بلوكات As-Built سطراً سطراً (DID DE00+N-1) حتى يجيب
/// الموديول NO DATA — بلا حد أقصى موثق مسبقاً (حد الأمان الداخلي 64 بلوكاً
/// يمنع حلقة لا نهائية فقط، وليس عدد بلوكات متوقعاً)، ثم الأعطال
/// (Mode 03/07/0A). الوحدة التي لا ترد تُسجَّل «لا ترد» ولا تُخترع لها بيانات.
/// عند أي انقطاع اتصال تتوقف القراءة فوراً ويُحفظ ما جُمع حتى لحظة الانقطاع
/// مع تسجيل ذلك في الملف.
final class BackupExportService {
    private let elm327: ELM327Service
    private let diagnostics: DiagnosticsService

    /// حد أمان داخلي لمنع حلقة لا نهائية فقط — ليس عدد بلوكات متوقعاً.
    /// الوحدات الحقيقية ترد عادة بـ 11 بلوكاً أو أقل؛ يُسجَّل بلوغ الحد في الملاحظات.
    static let maxBlocksPerModule = 64
    /// عرض السطر المفترض عند تقسيم بايتات البلوك (APIM موثق 5 بايتات؛
    /// BCM ‏3–4 وSCCM ‏4 في منصات قديمة، وغير معروف لتورس 2023 — لذلك
    /// البايتات الخام هي المرجع، والأسطر تقسيم بأفضل جهد موثق).
    static let lineWidthAssumed = 5

    /// أرقام التعريف (Ford ID DIDs — من FordScan/FordDiag الموثق):
    /// F190 رقم الشاصي، F188 رقم الاستراتيجية، F113 رقم التجميع،
    /// F124 رقم المعايرة، F187 رقم القطعة، F18C الرقم التسلسلي.
    static let idDIDs: [(did: String, name: String)] = [
        ("F190", "VIN"),
        ("F188", "strategy"),
        ("F113", "assembly"),
        ("F124", "calibration"),
        ("F187", "partNumber"),
        ("F18C", "serialNumber"),
    ]

    init(elm327: ELM327Service, diagnostics: DiagnosticsService) {
        self.elm327 = elm327
        self.diagnostics = diagnostics
    }

    // MARK: - Paths
    /// مجلد Documents — يظهر في تطبيق الملفات (On My iPhone ← برمجة فورد).
    static func documentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    /// اسم الملف: Taurus-Backup-<آخر 6 من VIN>-<YYYYMMDD-HHMM>.json
    static func exportFileName(vin: String, date: Date) -> String {
        let last6 = vin.count >= 6 ? String(vin.suffix(6)) : vin
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyyMMdd-HHmm"
        return "Taurus-Backup-\(last6)-\(f.string(from: date)).json"
    }

    /// النسخ المحفوظة في Documents — الأحدث أولاً.
    static func savedExports() -> [URL] {
        let dir = documentsDirectory()
        let files = (try? FileManager.default.contentsOfDirectory(
            at: dir, includingPropertiesForKeys: [.creationDateKey],
            options: [.skipsHiddenFiles])) ?? []
        return files
            .filter { $0.lastPathComponent.hasPrefix("Taurus-Backup-") && $0.pathExtension == "json" }
            .sorted { a, b in
                let da = (try? a.resourceValues(forKeys: [.creationDateKey]).creationDate) ?? Date.distantPast
                let db = (try? b.resourceValues(forKeys: [.creationDateKey]).creationDate) ?? Date.distantPast
                return da > db
            }
    }

    /// حذف كل النسخ المحفوظة.
    static func deleteSavedExports() throws {
        for url in savedExports() {
            try FileManager.default.removeItem(at: url)
        }
    }

    // MARK: - Checksum (الصيغة الموثقة — نفسها في AsBuiltLine.checksum)
    /// البايت المنخفض لمجموع: بايتي العنوان + رقم البلوك + رقم السطر
    /// + مجموع بايتات البيانات. موثقة من FordScan/FordDiag (AsBuilt.cs)
    /// ومطابقة لصيغة consp/apim-asbuilt-decode؛ مثبوتة في الاختبارات على
    /// 12 سطراً (لا 34 كما يدّعي توثيق FordScan).
    static func checksum(moduleID: String, block: Int, line: Int, data: [UInt8]) -> UInt8 {
        let moduleValue = Int(moduleID, radix: 16) ?? 0
        let sum = ((moduleValue >> 8) & 0xFF) + (moduleValue & 0xFF)
            + block + line + data.reduce(0) { $0 + Int($1) }
        return UInt8(sum & 0xFF)
    }

    /// تقسيم بايتات بلوك إلى أسطر بالعرض المفترض (5) مع تشيكسم محسوب لكل سطر.
    /// الباقي الجزئي (أقل من 5 بايتات) يُسجَّل سطراً غير مكتمل.
    static func lines(fromBlockBytes bytes: [UInt8], moduleID: String, block: Int) -> [ExportLine] {
        var out: [ExportLine] = []
        var offset = 0
        var lineNo = 1
        while offset < bytes.count {
            let remaining = bytes.count - offset
            if remaining >= lineWidthAssumed {
                let data = Array(bytes[offset..<(offset + lineWidthAssumed)])
                let cs = checksum(moduleID: moduleID, block: block, line: lineNo, data: data)
                out.append(ExportLine(
                    address: "\(moduleID)-\(String(format: "%02X", block))-\(String(format: "%02X", lineNo))",
                    block: block, line: lineNo,
                    dataHex: hexString(data), dataByteCount: data.count,
                    checksum: String(format: "%02X", cs),
                    checksumSource: "computed", checksumValid: true, note: nil))
                offset += lineWidthAssumed
            } else {
                let data = Array(bytes[offset...])
                let cs = checksum(moduleID: moduleID, block: block, line: lineNo, data: data)
                out.append(ExportLine(
                    address: "\(moduleID)-\(String(format: "%02X", block))-\(String(format: "%02X", lineNo))",
                    block: block, line: lineNo,
                    dataHex: hexString(data), dataByteCount: data.count,
                    checksum: String(format: "%02X", cs),
                    checksumSource: "computed", checksumValid: false,
                    note: "سطر غير مكتمل — \(data.count) بايتات متبقية لا تكمل سطراً بالعرض المفترض (5)؛ قد يكون عرض السطر لهذه الوحدة مختلفاً. البايتات الخام أعلاه هي المرجع."))
                offset = bytes.count
            }
            lineNo += 1
        }
        return out
    }

    /// سطر من بيانات موثقة معروضة (صورة 2015) — التشيكسم معروض ويُتحقق منه.
    static func lineFromDisplayed(moduleID: String, block: Int, line: Int,
                                 data: [UInt8], displayedChecksum: UInt8) -> ExportLine {
        let computed = checksum(moduleID: moduleID, block: block, line: line, data: data)
        let valid = computed == displayedChecksum
        return ExportLine(
            address: "\(moduleID)-\(String(format: "%02X", block))-\(String(format: "%02X", line))",
            block: block, line: line,
            dataHex: hexString(data), dataByteCount: data.count,
            checksum: String(format: "%02X", displayedChecksum),
            checksumSource: "displayed", checksumValid: valid,
            note: valid ? nil : "التشيكسم المعروض (\(String(format: "%02X", displayedChecksum))) لا يطابق المحسوب بالصيغة الموثقة (\(String(format: "%02X", computed))) — المرجح خطأ نسخ من الصورة.")
    }

    static func hexString(_ bytes: [UInt8]) -> String {
        bytes.map { String(format: "%02X", $0) }.joined(separator: " ")
    }

    static func asciiString(_ bytes: [UInt8]) -> String? {
        guard !bytes.isEmpty, bytes.allSatisfy({ $0 >= 32 && $0 < 127 }) else { return nil }
        return String(bytes: bytes, encoding: .ascii)
    }

    // MARK: - Live export
    /// تصدير نسخة كاملة من السيارة المتصلة. يُعيد النتيجة حتى عند الانقطاع
    /// أثناء القراءة (ملف جزئي موثق). يرمي فقط عند غياب الاتصال/السيارة
    /// من البداية أو فشل كتابة الملف.
    func export(vehicle: Vehicle, onProgress: @escaping (String) -> Void) async throws -> BackupExportResult {
        guard elm327.transport?.isConnected == true else { throw BackupExportError.notConnected }
        let startedAt = Date()

        // لقطة البيانات الحية وقت التصدير — أي قراءة تفشل تُسجَّل nil، لا تُخترع.
        onProgress("قراءة البطارية والسرعة وRPM…")
        let battery = try? await diagnostics.readBatteryVoltage()
        let speed = try? await diagnostics.readSpeedKmh()
        let rpm = await readRPMValue()
        let snapshot = ExportSnapshot(batteryVoltage: battery, speedKmh: speed, rpm: rpm)

        var modules: [ExportModule] = []
        var disconnectedMidway = false
        var stoppedAt: String?

        for module in Module.allCases {
            // توقف فوري عند انقطاع الاتصال — يُحفظ ما جُمع حتى الآن.
            guard elm327.transport?.isConnected == true else {
                disconnectedMidway = true
                stoppedAt = module.rawValue
                break
            }
            onProgress("قراءة وحدة \(module.rawValue) (\(module.arabicName))…")
            do {
                let entry = try await readModule(module)
                modules.append(entry)
            } catch let error as BackupExportError {
                if case .disconnectedMidway(let name) = error {
                    disconnectedMidway = true
                    stoppedAt = name
                    break
                }
                throw error
            }
        }

        let totalBlocks = modules.reduce(0) { $0 + $1.asBuiltBlocks.count }
        let allLines = modules.flatMap { $0.asBuiltBlocks.flatMap { $0.lines } }
        let totalDtcs = modules.reduce(0) { $0 + $1.dtcCount }
        let summary = ExportSummary(
            modulesTotal: Module.allCases.count,
            modulesResponded: modules.filter { $0.responded }.count,
            totalBlocks: totalBlocks,
            totalLines: allLines.count,
            totalDtcs: totalDtcs,
            checksumMismatches: allLines.filter { !$0.checksumValid && $0.checksumSource == "displayed" }.count,
            incompleteLines: allLines.filter { !$0.checksumValid && $0.checksumSource == "computed" }.count,
            disconnectedMidway: disconnectedMidway,
            stoppedAt: stoppedAt)

        var notes: [String] = [
            "نسخة قراءة كاملة لغرض التحليل والتطوير — تُستخدم لإعادة بناء خريطة برمجة السيارة وفحصها وإصلاحها.",
            "القراءة فقط: لم يُكتب أي بايت في السيارة أثناء التصدير.",
            "تعيين البلوكات: بلوك N = DID DE00+N-1 (موثق لـ APIM في FordScan/FordDiag، ومفترض لباقي الوحدات — انظر FEATURES.md).",
            "بايتات DID هي بايتات البيانات فقط؛ بايت التشيكسم الظاهر في FORScan محسوب بالصيغة الموثقة (البايت المنخفض لمجموع بايتي العنوان + رقم البلوك + رقم السطر + مجموع بايتات البيانات)، وليس بايتاً مقروءاً من الوحدة.",
            "عرض السطر المفترض عند التقسيم 5 بايتات (APIM موثق)؛ BCM ‏3–4 وSCCM ‏4 في منصات قديمة وغير معروف لتورس 2023 — البايتات الخام (rawHex) هي المرجع دائماً.",
            "قراءة البلوكات تستمر حتى يجيب الموديول NO DATA؛ حد الأمان الداخلي 64 بلوكاً يمنع حلقة لا نهائية فقط وليس عدد بلوكات متوقعاً.",
        ]
        if disconnectedMidway {
            notes.append("انقطع الاتصال أثناء القراءة عند وحدة \(stoppedAt ?? "؟") — الملف جزئي: الوحدات بعدها لم تُقرأ.")
        }

        let file = BackupExportFile(
            format: "Ford Taurus Backup Export",
            formatVersion: 1,
            headerAr: "نسخة احتياطية كاملة مقروءة من السيارة — لغرض تحليل البرمجة والتطوير. تحتوي رقم الشاصي الكامل: تُرسل للمطوّر فقط ولا تُنشر.",
            headerEn: "Full read-only backup export of the vehicle, for programming analysis and development. Contains the full VIN: send to the developer only, do not publish.",
            appVersion: "1.5 (5)",
            exportedAt: ISO8601DateFormatter().string(from: startedAt),
            vin: vehicle.vin,
            vinSource: "Mode 09 PID 02",
            demo: false,
            vehicle: ExportVehicleInfo(
                modelName: vehicle.modelName, modelYear: vehicle.modelYear,
                platform: String(describing: vehicle.platform), trim: String(describing: vehicle.trim)),
            snapshot: snapshot,
            modules: modules,
            summary: summary,
            notes: notes)

        let fileName = Self.exportFileName(vin: vehicle.vin, date: startedAt)
        let url = Self.documentsDirectory().appendingPathComponent(fileName)
        do {
            let data = try makeEncoder().encode(file)
            try data.write(to: url, options: [.atomic])
        } catch {
            throw BackupExportError.writeFailed(error.localizedDescription)
        }
        return BackupExportResult(fileURL: url, fileName: fileName, export: file)
    }

    /// قراءة وحدة واحدة كاملة: معرّفات + بلوكات As-Built + أعطال.
    private func readModule(_ module: Module) async throws -> ExportModule {
        // 1. أرقام التعريف الستة.
        var identifiers: [ExportIdentifier] = []
        for (did, name) in Self.idDIDs {
            do {
                let bytes = try await elm327.readMode22(moduleHeader: module.canID, did: did)
                identifiers.append(ExportIdentifier(
                    did: did, name: name, responded: true,
                    hex: Self.hexString(bytes), ascii: Self.asciiString(bytes)))
            } catch {
                try checkStillConnected(module: module)
                identifiers.append(ExportIdentifier(
                    did: did, name: name, responded: false, hex: nil, ascii: nil))
            }
        }

        // 2. بلوكات As-Built حتى NO DATA.
        var blocks: [ExportBlock] = []
        var asBuiltSupported = false
        var hitBlockCap = false
        for block in 1...Self.maxBlocksPerModule {
            let did = String(format: "DE%02X", block - 1)
            do {
                let bytes = try await elm327.readMode22(moduleHeader: module.canID, did: did)
                guard !bytes.isEmpty else {
                    // رد فارغ = نهاية قائمة البلوكات (مثل NO DATA).
                    if blocks.isEmpty { asBuiltSupported = false }
                    break
                }
                asBuiltSupported = true
                blocks.append(ExportBlock(
                    did: did, block: block, byteCount: bytes.count,
                    rawHex: Self.hexString(bytes),
                    lines: Self.lines(fromBlockBytes: bytes, moduleID: module.canID, block: block)))
            } catch {
                try checkStillConnected(module: module)
                // NO DATA / عدم دعم الـ DID = نهاية قائمة البلوكات.
                if blocks.isEmpty { asBuiltSupported = false }
                break
            }
            if block == Self.maxBlocksPerModule { hitBlockCap = true }
        }

        // 3. الأعطال (مؤكدة/معلّقة/دائمة) — الفشل في وحدة لا يوقف الباقي.
        let dtcEntry = await diagnostics.readSmartDTCs(modules: [module]).first
        let dtcs = ExportDTCs(
            confirmed: dtcEntry?.confirmed.map { $0.displayString } ?? [],
            pending: dtcEntry?.pending.map { $0.displayString } ?? [],
            permanent: dtcEntry?.permanent.map { $0.displayString } ?? [])
        let dtcCount = dtcs.confirmed.count + dtcs.pending.count + dtcs.permanent.count

        let responded = identifiers.contains { $0.responded } || !blocks.isEmpty
            || (dtcEntry?.responded == true)
        var errorText: String?
        if !responded {
            errorText = "لا ترد — لم تجب على أي طلب (معرّفات / بلوكات / أعطال)"
        } else if hitBlockCap {
            errorText = "بلغ حد الأمان الداخلي (64 بلوكاً) — قد توجد بلوكات أخرى لم تُقرأ"
        }

        return ExportModule(
            address: module.canID, name: module.rawValue, arabicName: module.arabicName,
            responded: responded, error: errorText,
            identifiers: identifiers, asBuiltSupported: asBuiltSupported,
            asBuiltBlocks: blocks, dtcs: dtcs, dtcCount: dtcCount)
    }

    /// إن انقطع الاتصال أثناء قراءة وحدة، أوقف التصدير كاملاً فوراً.
    private func checkStillConnected(module: Module) throws {
        if elm327.transport?.isConnected != true {
            throw BackupExportError.disconnectedMidway(module: module.rawValue)
        }
    }

    /// قراءة RPM بالصيغة القياسية: الرد "41 0C AA BB" → RPM = (AA*256 + BB) / 4.
    /// الفشل يُرجع nil — لا تُخترع قيمة.
    private func readRPMValue() async -> Double? {
        guard let response = try? await elm327.readPID("0C") else { return nil }
        let tokens = response.components(separatedBy: .whitespaces).filter { !$0.isEmpty }
        var bytes: [UInt8] = []
        for token in tokens where token.count == 2 {
            if let b = UInt8(token, radix: 16) { bytes.append(b) }
        }
        guard let i = bytes.firstIndex(of: 0x41), i + 3 < bytes.count, bytes[i + 1] == 0x0C else { return nil }
        return Double(Int(bytes[i + 2]) * 256 + Int(bytes[i + 3])) / 4.0
    }

    private func makeEncoder() -> JSONEncoder {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        return encoder
    }

    // MARK: - Demo export (عينة موثقة — بلا سيارة)
    /// ملف عينة للتجربة بلا سيارة — موسوم DEMO بوضوح.
    /// كل القيم فيه من مصادر موثقة فقط:
    /// - بلوك APIM ‏DE00‏ من محاكي FordScan (FordSimulator.cs:70): 10 بايتات.
    /// - بلوك BCM ‏DE00‏ من محاكي FordScan (FordSimulator.cs:59): 3 بايتات.
    /// - أسطر IPC من صورة مبرمج تورس 2015 (موثقة في المشروع — سيارة مختلفة).
    /// - أعطال APIM/IPC من نفس الصورة (U3000:04-28، P1346:13-8A، U0159:00-0A).
    /// لا قيم مخترعة: باقي الوحدات «لا ترد» واللقطة الحية nil.
    func generateDemo() throws -> BackupExportResult {
        let now = Date()
        let demoVIN = "DEMO-VIN-00000000000"

        // APIM: بلوك DE00 من المحاكي (10 بايتات = سطران).
        let apimBlockBytes: [UInt8] = [0x0A, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
        let apimBlock = ExportBlock(
            did: "DE00", block: 1, byteCount: apimBlockBytes.count,
            rawHex: Self.hexString(apimBlockBytes),
            lines: Self.lines(fromBlockBytes: apimBlockBytes, moduleID: "7D0", block: 1))
        let apimIDs = Self.idDIDs.map { (did, name) in
            ExportIdentifier(did: did, name: name,
                             responded: did == "F190",
                             hex: did == "F190" ? Self.hexString(Array(demoVIN.utf8)) : nil,
                             ascii: did == "F190" ? demoVIN : nil)
        }
        let apim = ExportModule(
            address: "7D0", name: "APIM", arabicName: "الشاشة",
            responded: true, error: nil,
            identifiers: apimIDs, asBuiltSupported: true, asBuiltBlocks: [apimBlock],
            dtcs: ExportDTCs(confirmed: ["U3000:04-28"], pending: [], permanent: []),
            dtcCount: 1)

        // BCM: بلوك DE00 من المحاكي (3 بايتات = سطر غير مكتمل — يوضح التعامل معه).
        let bcmBlockBytes: [UInt8] = [0x01, 0x01, 0x01]
        let bcmBlock = ExportBlock(
            did: "DE00", block: 1, byteCount: bcmBlockBytes.count,
            rawHex: Self.hexString(bcmBlockBytes),
            lines: Self.lines(fromBlockBytes: bcmBlockBytes, moduleID: "726", block: 1))
        let bcm = ExportModule(
            address: "726", name: "BdyCM", arabicName: "الجسم",
            responded: true, error: nil,
            identifiers: Self.idDIDs.map { ExportIdentifier(did: $0.did, name: $0.name, responded: false, hex: nil, ascii: nil) },
            asBuiltSupported: true, asBuiltBlocks: [bcmBlock],
            dtcs: ExportDTCs(confirmed: [], pending: [], permanent: []),
            dtcCount: 0)

        // IPC: أسطر صورة تورس 2015 (بتشيكسيمها المعروض — يُتحقق منها).
        let ipcLines: [ExportLine] = [
            Self.lineFromDisplayed(moduleID: "720", block: 1, line: 1, data: [0x2A, 0x0A, 0x14, 0xA3, 0x09], displayedChecksum: 0x1D),
            Self.lineFromDisplayed(moduleID: "720", block: 1, line: 2, data: [0x88, 0xF4, 0x40, 0xF0, 0x3D], displayedChecksum: 0x13),
            Self.lineFromDisplayed(moduleID: "720", block: 1, line: 3, data: [0x90, 0xEB, 0x00, 0xFA], displayedChecksum: 0x9D),
            Self.lineFromDisplayed(moduleID: "720", block: 2, line: 1, data: [0x4D, 0x56], displayedChecksum: 0xCD),
            Self.lineFromDisplayed(moduleID: "720", block: 3, line: 1, data: [0x00, 0x00, 0x00, 0x00, 0x00], displayedChecksum: 0x2B),
            Self.lineFromDisplayed(moduleID: "720", block: 3, line: 2, data: [0x00, 0x00, 0x00, 0x00, 0x00], displayedChecksum: 0x2C),
        ]
        // البلوك 1 = 14 بايت بيانات (5+5+4 — السطر الثالث 4 بايتات كما في الصورة).
        let ipcBlocks = [
            ExportBlock(did: "DE00", block: 1, byteCount: 14,
                        rawHex: "2A 0A 14 A3 09 88 F4 40 F0 3D 90 EB 00 FA",
                        lines: Array(ipcLines[0...2])),
            ExportBlock(did: "DE01", block: 2, byteCount: 2,
                        rawHex: "4D 56", lines: [ipcLines[3]]),
            ExportBlock(did: "DE02", block: 3, byteCount: 10,
                        rawHex: "00 00 00 00 00 00 00 00 00 00",
                        lines: Array(ipcLines[4...5])),
        ]
        let ipc = ExportModule(
            address: "720", name: "IPC", arabicName: "العدادات",
            responded: true, error: nil,
            identifiers: Self.idDIDs.map { ExportIdentifier(did: $0.did, name: $0.name, responded: false, hex: nil, ascii: nil) },
            asBuiltSupported: true, asBuiltBlocks: ipcBlocks,
            dtcs: ExportDTCs(confirmed: ["P1346:13-8A", "U0159:00-0A"], pending: [], permanent: []),
            dtcCount: 2)

        // باقي الوحدات: لا ترد في العينة — لا تُخترع لها بيانات.
        let silentModules = Module.allCases.filter { $0 != .apim && $0 != .bdyCM && $0 != .ipc }
        let silent = silentModules.map { module in
            ExportModule(
                address: module.canID, name: module.rawValue, arabicName: module.arabicName,
                responded: false, error: "لا ترد — عينة تجريبية، ليست بيانات سيارة حقيقية",
                identifiers: Self.idDIDs.map { ExportIdentifier(did: $0.did, name: $0.name, responded: false, hex: nil, ascii: nil) },
                asBuiltSupported: false, asBuiltBlocks: [],
                dtcs: ExportDTCs(confirmed: [], pending: [], permanent: []),
                dtcCount: 0)
        }

        let modules = [apim, bcm, ipc] + silent
        let allLines = modules.flatMap { $0.asBuiltBlocks.flatMap { $0.lines } }
        let summary = ExportSummary(
            modulesTotal: Module.allCases.count,
            modulesResponded: 3,
            totalBlocks: 5,
            totalLines: allLines.count,
            totalDtcs: 3,
            checksumMismatches: allLines.filter { !$0.checksumValid && $0.checksumSource == "displayed" }.count,
            incompleteLines: allLines.filter { !$0.checksumValid && $0.checksumSource == "computed" }.count,
            disconnectedMidway: false,
            stoppedAt: nil)

        let file = BackupExportFile(
            format: "Ford Taurus Backup Export",
            formatVersion: 1,
            headerAr: "DEMO — عينة تجريبية، ليست بيانات سيارة حقيقية. قيمها من مصادر موثقة فقط (محاكي FordScan + صورة تورس 2015) لاختبار تدفق الحفظ والمشاركة.",
            headerEn: "DEMO — sample export, not real vehicle data. Values come only from documented sources (FordScan simulator + 2015 Taurus photo) to test the save/share flow.",
            appVersion: "1.5 (5)",
            exportedAt: ISO8601DateFormatter().string(from: now),
            vin: demoVIN,
            vinSource: "demo",
            demo: true,
            vehicle: ExportVehicleInfo(modelName: "Ford Taurus (تجريبي)", modelYear: 2023,
                                       platform: "taurus2023C2", trim: "unknown"),
            snapshot: ExportSnapshot(batteryVoltage: nil, speedKmh: nil, rpm: nil),
            modules: modules,
            summary: summary,
            notes: [
                "DEMO — ليست بيانات سيارة حقيقية.",
                "بلوك APIM ‏DE00‏ من محاكي FordScan (FordSimulator.cs:70).",
                "بلوك BCM ‏DE00‏ من محاكي FordScan (FordSimulator.cs:59) — 3 بايتات فقط، سطر غير مكتمل عمداً.",
                "أسطر IPC من صورة مبرمج تورس 2015 الأمريكية (سيارة مختلفة تماماً عن تورس 2023) — للتوضيح فقط؛ سطر 720-01-03 تشيكسيمه المعروض (9D) لا يطابق المحسوب (A0).",
                "أعطال APIM/IPC من نفس الصورة (U3000:04-28، P1346:13-8A، U0159:00-0A).",
            ])

        let fileName = "Taurus-Backup-DEMOVIN-\(Self.fileDateString(now)).json"
        let url = Self.documentsDirectory().appendingPathComponent(fileName)
        do {
            let data = try makeEncoder().encode(file)
            try data.write(to: url, options: [.atomic])
        } catch {
            throw BackupExportError.writeFailed(error.localizedDescription)
        }
        return BackupExportResult(fileURL: url, fileName: fileName, export: file)
    }

    private static func fileDateString(_ date: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyyMMdd-HHmm"
        return f.string(from: date)
    }
}
